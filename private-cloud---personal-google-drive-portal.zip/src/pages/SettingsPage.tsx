import React, { useState, useEffect } from 'react';
import {
  Settings,
  HardDrive,
  KeyRound,
  Shield,
  Folder,
  LogOut,
  CheckCircle2,
  AlertTriangle,
  Loader2,
  Trash2,
  RefreshCw,
  ExternalLink,
  Database,
  History,
  Info,
} from 'lucide-react';
import { DriveStatus, SessionInfo, AuditLog } from '../types';
import { api } from '../services/api';
import { authorizeAdminGoogleDrive } from '../services/googleAuth';
import { FolderSelectorModal } from '../components/FolderSelectorModal';
import { DisconnectDriveModal } from '../components/DisconnectDriveModal';

interface SettingsPageProps {
  driveStatus: DriveStatus | null;
  onRefreshDriveStatus: () => void;
  onLogout: () => void;
  theme: 'dark' | 'light';
  onToggleTheme: () => void;
}

export const SettingsPage: React.FC<SettingsPageProps> = ({
  driveStatus,
  onRefreshDriveStatus,
  onLogout,
  theme,
  onToggleTheme,
}) => {
  // Folder selector state
  const [isFolderModalOpen, setIsFolderModalOpen] = useState(false);
  const [isDisconnectModalOpen, setIsDisconnectModalOpen] = useState(false);

  // Connecting Drive state
  const [connectingDrive, setConnectingDrive] = useState(false);
  const [driveActionMessage, setDriveActionMessage] = useState<{ text: string; isError?: boolean } | null>(null);

  // Password change state
  const [currentPassword, setCurrentPassword] = useState('');
  const [newPassword, setNewPassword] = useState('');
  const [confirmNewPassword, setConfirmNewPassword] = useState('');
  const [passLoading, setPassLoading] = useState(false);
  const [passMessage, setPassMessage] = useState<{ text: string; isError?: boolean } | null>(null);

  // Sessions state
  const [sessions, setSessions] = useState<SessionInfo[]>([]);
  const [currentSessionId, setCurrentSessionId] = useState<string>('');
  const [sessionsLoading, setSessionsLoading] = useState(false);

  // Audit logs state
  const [auditLogs, setAuditLogs] = useState<AuditLog[]>([]);
  const [logsLoading, setLogsLoading] = useState(false);

  // System info
  const [systemInfo, setSystemInfo] = useState<any>(null);

  // Active sub-tab
  const [activeTab, setActiveTab] = useState<'drive' | 'security' | 'audit' | 'database'>('drive');

  useEffect(() => {
    loadSessions();
    loadAuditLogs();
    loadSystemInfo();
  }, []);

  const loadSessions = async () => {
    setSessionsLoading(true);
    try {
      const data = await api.settings.getSessions();
      setSessions(data.sessions);
      setCurrentSessionId(data.currentSessionId);
    } catch {}
    setSessionsLoading(false);
  };

  const loadAuditLogs = async () => {
    setLogsLoading(true);
    try {
      const data = await api.settings.getAuditLogs(50);
      setAuditLogs(data.logs);
    } catch {}
    setLogsLoading(false);
  };

  const loadSystemInfo = async () => {
    try {
      const data = await api.settings.getSystemInfo();
      setSystemInfo(data);
    } catch {}
  };

  const handleConnectDrive = async () => {
    setConnectingDrive(true);
    setDriveActionMessage(null);
    try {
      // 1. Authorize via official Google OAuth 2.0 with Firebase client
      const authResult = await authorizeAdminGoogleDrive();

      // 2. Transmit access token to server backend (server verifies with Google tokeninfo)
      await api.google.connect(authResult.accessToken);

      setDriveActionMessage({ text: 'Google Drive connected successfully ✓' });
      onRefreshDriveStatus();
    } catch (err: any) {
      setDriveActionMessage({
        text: err.message || 'Failed to authorize Google Drive. Please try again.',
        isError: true,
      });
    } finally {
      setConnectingDrive(false);
    }
  };

  const handleDisconnectDrive = () => {
    setIsDisconnectModalOpen(true);
  };

  const handleChangePassword = async (e: React.FormEvent) => {
    e.preventDefault();
    if (newPassword.length < 8) {
      setPassMessage({ text: 'New password must be at least 8 characters long', isError: true });
      return;
    }
    if (newPassword !== confirmNewPassword) {
      setPassMessage({ text: 'New passwords do not match', isError: true });
      return;
    }

    setPassLoading(true);
    setPassMessage(null);

    try {
      await api.settings.changePassword(currentPassword, newPassword);
      setPassMessage({ text: 'Master password updated successfully!' });
      setCurrentPassword('');
      setNewPassword('');
      setConfirmNewPassword('');
    } catch (err: any) {
      setPassMessage({ text: err.message || 'Failed to update password', isError: true });
    } finally {
      setPassLoading(false);
    }
  };

  const handleRevokeSession = async (sessionId: string) => {
    try {
      await api.settings.revokeSession(sessionId);
      setSessions((prev) => prev.filter((s) => s.id !== sessionId));
    } catch {}
  };

  return (
    <div className="space-y-6 animate-in fade-in duration-300">
      {/* Header */}
      <div className="flex items-center justify-between pb-4 border-b border-slate-200 dark:border-slate-800">
        <div>
          <div className="flex items-center gap-2">
            <div className="p-2 rounded-xl bg-blue-50 dark:bg-blue-950/60 text-blue-600 dark:text-blue-400">
              <Settings className="w-5 h-5" />
            </div>
            <h1 className="text-xl sm:text-2xl font-bold text-slate-900 dark:text-white">
              Administrator Settings
            </h1>
          </div>
          <p className="text-xs text-slate-500 mt-1">
            Manage your Google Drive integration, master password, active sessions, and database
          </p>
        </div>
      </div>

      {/* Settings Navigation Tabs */}
      <div className="flex items-center gap-2 border-b border-slate-200 dark:border-slate-800 pb-2 text-xs overflow-x-auto">
        {[
          { id: 'drive', label: 'Google Drive', icon: HardDrive },
          { id: 'security', label: 'Security & Sessions', icon: KeyRound },
          { id: 'audit', label: 'Audit Logs', icon: History },
          { id: 'database', label: 'Database & Cloud', icon: Database },
        ].map((tab) => {
          const Icon = tab.icon;
          const isActive = activeTab === tab.id;
          return (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id as any)}
              className={`flex items-center gap-2 px-3.5 py-2 rounded-xl font-medium transition-colors shrink-0 ${
                isActive
                  ? 'bg-blue-600 text-white shadow-sm'
                  : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white hover:bg-slate-100 dark:hover:bg-slate-800'
              }`}
            >
              <Icon className="w-4 h-4" />
              <span>{tab.label}</span>
            </button>
          );
        })}
      </div>

      {/* 1. GOOGLE DRIVE TAB */}
      {activeTab === 'drive' && (
        <div className="space-y-6">
          {driveActionMessage && (
            <div
              className={`p-4 rounded-2xl text-xs flex items-center gap-3 border ${
                driveActionMessage.isError
                  ? 'bg-rose-50 dark:bg-rose-950/40 text-rose-600 border-rose-200 dark:border-rose-900'
                  : 'bg-emerald-50 dark:bg-emerald-950/40 text-emerald-600 border-emerald-200 dark:border-emerald-900'
              }`}
            >
              {driveActionMessage.isError ? (
                <AlertTriangle className="w-4 h-4 shrink-0" />
              ) : (
                <CheckCircle2 className="w-4 h-4 shrink-0" />
              )}
              <span>{driveActionMessage.text}</span>
            </div>
          )}

          {/* Connection Card */}
          <div className="p-6 rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-sm space-y-6">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-6 border-b border-slate-100 dark:border-slate-800">
              <div className="flex items-start gap-4">
                <div className="w-14 h-14 rounded-2xl bg-gradient-to-tr from-blue-600 to-indigo-600 text-white flex items-center justify-center shadow-lg shadow-blue-500/20 shrink-0">
                  <HardDrive className="w-7 h-7" />
                </div>
                <div>
                  <h3 className="text-base font-bold text-slate-900 dark:text-white">
                    Google Drive Integration
                  </h3>
                  <p className="text-xs text-slate-500 mt-1 max-w-md">
                    Connect your Google account using official OAuth 2.0. Once connected, your private cloud
                    portal streams files for you without requiring users to log into Gmail.
                  </p>
                </div>
              </div>

              {/* Status Badge */}
              <div className="shrink-0">
                {driveStatus?.connected ? (
                  <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full bg-emerald-50 dark:bg-emerald-950/60 border border-emerald-200 dark:border-emerald-800 text-emerald-600 dark:text-emerald-400 text-xs font-semibold">
                    <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
                    <span>Google Drive Connected ✓</span>
                  </div>
                ) : (
                  <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full bg-amber-50 dark:bg-amber-950/60 border border-amber-200 dark:border-amber-800 text-amber-600 dark:text-amber-400 text-xs font-semibold">
                    <span className="w-2 h-2 rounded-full bg-amber-500" />
                    <span>Not Connected</span>
                  </div>
                )}
              </div>
            </div>

            {/* Connection Details or Action */}
            {driveStatus?.connected ? (
              <div className="space-y-6">
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div className="p-4 rounded-2xl bg-slate-50 dark:bg-slate-800/50 border border-slate-200/80 dark:border-slate-700/80">
                    <span className="text-[11px] font-bold uppercase tracking-wider text-slate-400 block mb-1">
                      Authorized Account
                    </span>
                    <span className="text-sm font-semibold text-slate-900 dark:text-white">
                      {driveStatus.email || 'Google User'}
                    </span>
                    {driveStatus.connectedAt && (
                      <span className="block text-xs text-slate-400 mt-1 font-mono">
                        Connected on {new Date(driveStatus.connectedAt).toLocaleDateString()}
                      </span>
                    )}
                  </div>

                  <div className="p-4 rounded-2xl bg-slate-50 dark:bg-slate-800/50 border border-slate-200/80 dark:border-slate-700/80">
                    <span className="text-[11px] font-bold uppercase tracking-wider text-slate-400 block mb-1">
                      Visible Folders Filter
                    </span>
                    <div className="flex items-center justify-between">
                      <span className="text-sm font-semibold text-slate-900 dark:text-white">
                        {driveStatus.allowedFolderCount > 0
                          ? `${driveStatus.allowedFolderCount} Selected Folder(s)`
                          : 'All Folders Accessible'}
                      </span>
                      <button
                        onClick={() => setIsFolderModalOpen(true)}
                        className="text-xs font-semibold text-blue-600 dark:text-blue-400 hover:underline"
                      >
                        Change
                      </button>
                    </div>
                  </div>
                </div>

                {/* Selected folders list chips */}
                {driveStatus.allowedFolders && driveStatus.allowedFolders.length > 0 && (
                  <div>
                    <span className="text-xs font-semibold text-slate-500 block mb-2">
                      Permitted Folders:
                    </span>
                    <div className="flex flex-wrap gap-2">
                      {driveStatus.allowedFolders.map((f) => (
                        <div
                          key={f.id}
                          className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-blue-50 dark:bg-blue-950/40 border border-blue-200 dark:border-blue-900 text-blue-700 dark:text-blue-300 text-xs font-medium"
                        >
                          <Folder className="w-3.5 h-3.5" />
                          <span>{f.name}</span>
                        </div>
                      ))}
                    </div>
                  </div>
                )}

                {/* Action buttons */}
                <div className="flex flex-wrap items-center gap-3 pt-2">
                  <button
                    onClick={() => setIsFolderModalOpen(true)}
                    className="flex items-center gap-2 px-4 py-2.5 rounded-xl bg-blue-600 hover:bg-blue-700 text-white font-semibold text-xs shadow-md shadow-blue-500/20"
                  >
                    <Folder className="w-4 h-4" />
                    <span>Choose Visible Folders</span>
                  </button>

                  <button
                    onClick={handleDisconnectDrive}
                    className="flex items-center gap-2 px-4 py-2.5 rounded-xl bg-rose-50 dark:bg-rose-950/40 hover:bg-rose-100 dark:hover:bg-rose-900/60 text-rose-600 dark:text-rose-400 border border-rose-200 dark:border-rose-900 font-semibold text-xs transition-colors"
                  >
                    <Trash2 className="w-4 h-4" />
                    <span>Disconnect Google Drive</span>
                  </button>
                </div>
              </div>
            ) : (
              <div className="flex flex-col sm:flex-row items-center justify-between gap-4 p-6 rounded-2xl bg-blue-50/60 dark:bg-blue-950/30 border border-blue-200 dark:border-blue-900">
                <div className="space-y-1 text-center sm:text-left">
                  <h4 className="font-bold text-slate-900 dark:text-white text-sm">
                    Connect Your Google Drive Account
                  </h4>
                  <p className="text-xs text-slate-500 max-w-md">
                    Click the button below to authorize with Google OAuth 2.0. The access token is securely
                    stored on your private server only.
                  </p>
                </div>

                <button
                  onClick={handleConnectDrive}
                  disabled={connectingDrive}
                  className="flex items-center gap-2.5 px-6 py-3 rounded-2xl bg-blue-600 hover:bg-blue-700 text-white font-semibold text-xs sm:text-sm shadow-lg shadow-blue-600/30 transition-all shrink-0 disabled:opacity-50"
                >
                  {connectingDrive ? (
                    <Loader2 className="w-4 h-4 animate-spin" />
                  ) : (
                    <HardDrive className="w-4 h-4" />
                  )}
                  <span>Connect Google Drive</span>
                </button>
              </div>
            )}
          </div>
        </div>
      )}

      {/* 2. SECURITY & SESSIONS TAB */}
      {activeTab === 'security' && (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Password Change Card */}
          <div className="p-6 rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-sm space-y-4">
            <div className="flex items-center gap-3 pb-4 border-b border-slate-100 dark:border-slate-800">
              <div className="p-2.5 rounded-xl bg-blue-50 dark:bg-blue-950/60 text-blue-600 dark:text-blue-400">
                <KeyRound className="w-5 h-5" />
              </div>
              <div>
                <h3 className="font-bold text-slate-900 dark:text-white text-base">
                  Change Master Password
                </h3>
                <p className="text-xs text-slate-500">
                  Update the password required to open this private website
                </p>
              </div>
            </div>

            {passMessage && (
              <div
                className={`p-3 rounded-xl text-xs flex items-center gap-2 ${
                  passMessage.isError
                    ? 'bg-rose-50 text-rose-600 dark:bg-rose-950/40'
                    : 'bg-emerald-50 text-emerald-600 dark:bg-emerald-950/40'
                }`}
              >
                <span>{passMessage.text}</span>
              </div>
            )}

            <form onSubmit={handleChangePassword} className="space-y-4">
              <div>
                <label className="block text-xs font-semibold uppercase tracking-wider text-slate-400 mb-1.5">
                  Current Password
                </label>
                <input
                  type="password"
                  value={currentPassword}
                  onChange={(e) => setCurrentPassword(e.target.value)}
                  placeholder="••••••••••••"
                  required
                  className="w-full h-10 px-3.5 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-xs text-slate-900 dark:text-white focus:outline-none focus:border-blue-500"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold uppercase tracking-wider text-slate-400 mb-1.5">
                  New Password
                </label>
                <input
                  type="password"
                  value={newPassword}
                  onChange={(e) => setNewPassword(e.target.value)}
                  placeholder="Minimum 8 characters"
                  required
                  className="w-full h-10 px-3.5 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-xs text-slate-900 dark:text-white focus:outline-none focus:border-blue-500"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold uppercase tracking-wider text-slate-400 mb-1.5">
                  Confirm New Password
                </label>
                <input
                  type="password"
                  value={confirmNewPassword}
                  onChange={(e) => setConfirmNewPassword(e.target.value)}
                  placeholder="Re-enter new password"
                  required
                  className="w-full h-10 px-3.5 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-xs text-slate-900 dark:text-white focus:outline-none focus:border-blue-500"
                />
              </div>

              <button
                type="submit"
                disabled={passLoading}
                className="w-full py-2.5 rounded-xl bg-blue-600 hover:bg-blue-700 text-white font-semibold text-xs flex items-center justify-center gap-2 shadow-md shadow-blue-500/20 transition-all disabled:opacity-50"
              >
                {passLoading ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : null}
                <span>Update Master Password</span>
              </button>
            </form>
          </div>

          {/* Active Sessions Card */}
          <div className="p-6 rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-sm space-y-4">
            <div className="flex items-center justify-between pb-4 border-b border-slate-100 dark:border-slate-800">
              <div className="flex items-center gap-3">
                <div className="p-2.5 rounded-xl bg-emerald-50 dark:bg-emerald-950/60 text-emerald-600 dark:text-emerald-400">
                  <Shield className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="font-bold text-slate-900 dark:text-white text-base">Active Sessions</h3>
                  <p className="text-xs text-slate-500">Devices currently logged into this cloud portal</p>
                </div>
              </div>
              <button
                onClick={loadSessions}
                className="p-1.5 text-slate-400 hover:text-slate-600 dark:hover:text-slate-200"
              >
                <RefreshCw className={`w-4 h-4 ${sessionsLoading ? 'animate-spin' : ''}`} />
              </button>
            </div>

            <div className="space-y-3 max-h-72 overflow-y-auto pr-1">
              {sessions.map((sess) => {
                const isCurrent = sess.id === currentSessionId;
                return (
                  <div
                    key={sess.id}
                    className="p-3.5 rounded-2xl bg-slate-50 dark:bg-slate-800/50 border border-slate-200/80 dark:border-slate-700/80 flex items-center justify-between text-xs"
                  >
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="font-semibold text-slate-800 dark:text-slate-200 font-mono">
                          IP: {sess.ip}
                        </span>
                        {isCurrent && (
                          <span className="px-2 py-0.5 rounded-full bg-blue-100 dark:bg-blue-950 text-blue-700 dark:text-blue-300 text-[10px] font-bold">
                            Current Device
                          </span>
                        )}
                      </div>
                      <p className="text-[11px] text-slate-400 truncate max-w-xs mt-0.5">
                        {sess.user_agent}
                      </p>
                      <span className="text-[10px] text-slate-400 mt-1 block">
                        Logged in: {new Date(sess.created_at).toLocaleString()}
                      </span>
                    </div>

                    {!isCurrent && (
                      <button
                        onClick={() => handleRevokeSession(sess.id)}
                        className="px-2.5 py-1 rounded-lg text-rose-600 hover:bg-rose-50 dark:hover:bg-rose-950/50 text-[11px] font-semibold transition-colors"
                      >
                        Revoke
                      </button>
                    )}
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      )}

      {/* 3. AUDIT LOGS TAB */}
      {activeTab === 'audit' && (
        <div className="p-6 rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-sm space-y-4">
          <div className="flex items-center justify-between pb-4 border-b border-slate-100 dark:border-slate-800">
            <div>
              <h3 className="font-bold text-slate-900 dark:text-white text-base">Security Audit Logs</h3>
              <p className="text-xs text-slate-500">
                Tamper-resistant audit history of logins, downloads, and configuration updates
              </p>
            </div>
            <button
              onClick={loadAuditLogs}
              className="p-2 rounded-xl bg-slate-50 dark:bg-slate-800 text-slate-500 hover:text-blue-500"
            >
              <RefreshCw className={`w-4 h-4 ${logsLoading ? 'animate-spin' : ''}`} />
            </button>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead>
                <tr className="border-b border-slate-200 dark:border-slate-800 text-[11px] font-bold uppercase tracking-wider text-slate-400">
                  <th className="pb-3">Timestamp</th>
                  <th className="pb-3">Event</th>
                  <th className="pb-3">IP Address</th>
                  <th className="pb-3">Details</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 dark:divide-slate-800/60 font-mono">
                {auditLogs.map((log) => (
                  <tr key={log.id} className="hover:bg-slate-50/50 dark:hover:bg-slate-800/30">
                    <td className="py-2.5 text-slate-400 whitespace-nowrap">
                      {new Date(log.created_at).toLocaleString()}
                    </td>
                    <td className="py-2.5 font-bold">
                      <span
                        className={`px-2 py-0.5 rounded-full text-[10px] ${
                          log.event.includes('FAILED')
                            ? 'bg-rose-100 dark:bg-rose-950 text-rose-600'
                            : log.event.includes('SUCCESS')
                            ? 'bg-emerald-100 dark:bg-emerald-950 text-emerald-600'
                            : 'bg-blue-100 dark:bg-blue-950 text-blue-600'
                        }`}
                      >
                        {log.event}
                      </span>
                    </td>
                    <td className="py-2.5 text-slate-500">{log.ip}</td>
                    <td className="py-2.5 text-slate-700 dark:text-slate-300">{log.details}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* 4. DATABASE & CLOUD TAB */}
      {activeTab === 'database' && (
        <div className="space-y-6">
          <div className="p-6 rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-sm space-y-4">
            <div className="flex items-center gap-3 pb-4 border-b border-slate-100 dark:border-slate-800">
              <div className="p-2.5 rounded-xl bg-purple-50 dark:bg-purple-950/60 text-purple-600 dark:text-purple-400">
                <Database className="w-5 h-5" />
              </div>
              <div>
                <h3 className="font-bold text-slate-900 dark:text-white text-base">
                  Database & Cloud Architecture
                </h3>
                <p className="text-xs text-slate-500">
                  Current database status, Supabase / PostgreSQL configuration, and environment setup
                </p>
              </div>
            </div>

            {systemInfo && (
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div className="p-4 rounded-2xl bg-slate-50 dark:bg-slate-800/50 border border-slate-200/80 dark:border-slate-700/80">
                  <span className="text-[11px] font-bold uppercase tracking-wider text-slate-400 block mb-1">
                    Database Engine
                  </span>
                  <span className="text-sm font-semibold text-slate-900 dark:text-white">
                    {systemInfo.database?.type}
                  </span>
                  <span className="block text-xs text-emerald-600 mt-1">
                    ● Storage is persistent and active
                  </span>
                </div>

                <div className="p-4 rounded-2xl bg-slate-50 dark:bg-slate-800/50 border border-slate-200/80 dark:border-slate-700/80">
                  <span className="text-[11px] font-bold uppercase tracking-wider text-slate-400 block mb-1">
                    Node.js Runtime
                  </span>
                  <span className="text-sm font-semibold text-slate-900 dark:text-white font-mono">
                    {systemInfo.environment?.nodeVersion}
                  </span>
                  <span className="block text-xs text-slate-400 mt-1">
                    Express 4 + Scrypt Hashing
                  </span>
                </div>
              </div>
            )}

            <div className="pt-4 border-t border-slate-100 dark:border-slate-800">
              <h4 className="text-xs font-bold uppercase tracking-wider text-slate-700 dark:text-slate-300 mb-2">
                Supabase / PostgreSQL Quick Setup
              </h4>
              <p className="text-xs text-slate-500 leading-relaxed mb-3">
                To connect your own external Supabase or PostgreSQL database, simply provide{' '}
                <code className="bg-slate-100 dark:bg-slate-800 px-1 py-0.5 rounded text-blue-500">
                  DATABASE_URL
                </code>{' '}
                in your environment. The system will automatically create all tables using the included{' '}
                <code className="text-blue-500">schema.sql</code>.
              </p>
            </div>
          </div>
        </div>
      )}

      {/* Modal for selecting permitted folders */}
      <FolderSelectorModal
        isOpen={isFolderModalOpen}
        onClose={() => setIsFolderModalOpen(false)}
        onSaved={onRefreshDriveStatus}
      />

      {/* Modal for disconnecting Google Drive */}
      <DisconnectDriveModal
        isOpen={isDisconnectModalOpen}
        onClose={() => setIsDisconnectModalOpen(false)}
        onDisconnected={() => {
          setDriveActionMessage({ text: 'Google Drive disconnected successfully' });
          onRefreshDriveStatus();
        }}
        accountEmail={driveStatus?.email}
      />
    </div>
  );
};
