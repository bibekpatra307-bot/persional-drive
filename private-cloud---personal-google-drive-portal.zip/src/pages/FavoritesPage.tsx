import React, { useState, useEffect } from 'react';
import { Star, RefreshCw, AlertCircle, Loader2 } from 'lucide-react';
import { DriveFileItem } from '../types';
import { api } from '../services/api';
import { FileCard } from '../components/FileCard';

interface FavoritesPageProps {
  onOpenFile: (file: DriveFileItem) => void;
  onToggleFavorite: (file: DriveFileItem) => void;
  onDownload: (file: DriveFileItem) => void;
}

export const FavoritesPage: React.FC<FavoritesPageProps> = ({
  onOpenFile,
  onToggleFavorite,
  onDownload,
}) => {
  const [favorites, setFavorites] = useState<DriveFileItem[]>([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const loadFavorites = async () => {
    setLoading(true);
    setError(null);
    try {
      const res = await api.favorites.getAll();
      setFavorites(res.favorites.map((f) => ({ ...f, isFavorite: true })));
    } catch (err: any) {
      setError(err.message || 'Failed to load favorites');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadFavorites();
  }, []);

  const handleToggle = async (file: DriveFileItem) => {
    await onToggleFavorite(file);
    // Remove locally
    setFavorites((prev) => prev.filter((f) => f.id !== file.id));
  };

  return (
    <div className="space-y-6 animate-in fade-in duration-300">
      <div className="flex items-center justify-between pb-4 border-b border-slate-200 dark:border-slate-800">
        <div>
          <div className="flex items-center gap-2">
            <div className="p-2 rounded-xl bg-amber-50 dark:bg-amber-950/60 text-amber-500">
              <Star className="w-5 h-5 fill-amber-500" />
            </div>
            <h1 className="text-xl sm:text-2xl font-bold text-slate-900 dark:text-white">
              Starred & Favorites
            </h1>
          </div>
          <p className="text-xs text-slate-500 mt-1">
            Quickly access your pinned files, photos, videos, and documents
          </p>
        </div>

        <button
          onClick={loadFavorites}
          disabled={loading}
          className="p-2 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 text-slate-600 dark:text-slate-300 hover:text-amber-500"
        >
          <RefreshCw className={`w-4 h-4 ${loading ? 'animate-spin text-amber-500' : ''}`} />
        </button>
      </div>

      {error && (
        <div className="flex items-center gap-3 p-4 rounded-2xl bg-rose-50 dark:bg-rose-950/40 text-rose-600 dark:text-rose-400 border border-rose-200 dark:border-rose-900 text-xs">
          <AlertCircle className="w-5 h-5 shrink-0" />
          <div className="flex-1 font-medium">{error}</div>
        </div>
      )}

      {loading && favorites.length === 0 && (
        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-4">
          {Array.from({ length: 5 }).map((_, i) => (
            <div
              key={i}
              className="aspect-square rounded-2xl bg-slate-200 dark:bg-slate-800/60 animate-pulse"
            />
          ))}
        </div>
      )}

      {!loading && favorites.length === 0 && !error && (
        <div className="text-center py-20 rounded-3xl border border-dashed border-slate-300 dark:border-slate-800 bg-white/50 dark:bg-slate-900/50">
          <div className="w-16 h-16 rounded-2xl bg-amber-50 dark:bg-amber-950 text-amber-500 mx-auto flex items-center justify-center mb-4">
            <Star className="w-8 h-8" />
          </div>
          <h3 className="font-bold text-slate-900 dark:text-white text-base mb-1">
            No Favorites Yet
          </h3>
          <p className="text-xs text-slate-500 max-w-sm mx-auto mb-4">
            Click the star icon on any photo, video, or document to add it to your private favorites
            list for instant access.
          </p>
        </div>
      )}

      {favorites.length > 0 && (
        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-4">
          {favorites.map((file) => (
            <FileCard
              key={file.id}
              file={file}
              onClick={onOpenFile}
              onToggleFavorite={handleToggle}
              onDownload={onDownload}
            />
          ))}
        </div>
      )}
    </div>
  );
};
