import React, { useState, useEffect } from 'react';
import {
  Folder,
  FolderOpen,
  ChevronRight,
  Home,
  RefreshCw,
  Search,
  List,
  LayoutGrid,
  AlertCircle,
  Loader2,
  ArrowLeft,
} from 'lucide-react';
import { DriveFileItem } from '../types';
import { api } from '../services/api';
import { FileCard } from '../components/FileCard';
import { FileRow } from '../components/FileRow';

interface BreadcrumbItem {
  id?: string;
  name: string;
}

interface FileManagerPageProps {
  onOpenFile: (file: DriveFileItem) => void;
  onToggleFavorite?: (file: DriveFileItem) => void;
  onDownload: (file: DriveFileItem) => void;
}

export const FileManagerPage: React.FC<FileManagerPageProps> = ({
  onOpenFile,
  onToggleFavorite,
  onDownload,
}) => {
  const [breadcrumbs, setBreadcrumbs] = useState<BreadcrumbItem[]>([
    { name: 'Home' },
  ]);
  const [items, setItems] = useState<DriveFileItem[]>([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [nextPageToken, setNextPageToken] = useState<string | undefined>();
  const [viewMode, setViewMode] = useState<'table' | 'grid'>('table');
  const [localSearch, setLocalSearch] = useState('');

  const currentFolderId = breadcrumbs[breadcrumbs.length - 1].id;

  const loadFolderContents = async (folderId?: string, pageToken?: string, append = false) => {
    setLoading(true);
    setError(null);
    try {
      const res = await api.drive.listFiles({
        category: 'files',
        folderId,
        pageSize: 50,
        pageToken,
        sortBy: 'name',
        sortOrder: 'asc',
      });

      if (append) {
        setItems((prev) => [...prev, ...res.files]);
      } else {
        setItems(res.files);
      }
      setNextPageToken(res.nextPageToken);
    } catch (err: any) {
      setError(err.message || 'Unable to open folder');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadFolderContents(currentFolderId);
  }, [currentFolderId]);

  const handleItemClick = (item: DriveFileItem) => {
    if (item.isFolder) {
      setBreadcrumbs((prev) => [...prev, { id: item.id, name: item.name }]);
    } else {
      onOpenFile(item);
    }
  };

  const handleBreadcrumbClick = (index: number) => {
    setBreadcrumbs((prev) => prev.slice(0, index + 1));
  };

  const handleGoUp = () => {
    if (breadcrumbs.length > 1) {
      setBreadcrumbs((prev) => prev.slice(0, prev.length - 1));
    }
  };

  const filteredItems = items.filter((item) =>
    !localSearch.trim() || item.name.toLowerCase().includes(localSearch.toLowerCase())
  );

  const folders = filteredItems.filter((i) => i.isFolder);
  const files = filteredItems.filter((i) => !i.isFolder);

  return (
    <div className="space-y-6 animate-in fade-in duration-300">
      {/* Header & Controls */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 pb-4 border-b border-slate-200 dark:border-slate-800">
        <div>
          <div className="flex items-center gap-2">
            <div className="p-2 rounded-xl bg-amber-50 dark:bg-amber-950/60 text-amber-600 dark:text-amber-400">
              <Folder className="w-5 h-5" />
            </div>
            <h1 className="text-xl sm:text-2xl font-bold text-slate-900 dark:text-white">
              File Explorer
            </h1>
          </div>
          <p className="text-xs text-slate-500 mt-1">
            Browse directory structures, open folders, and manage files
          </p>
        </div>

        {/* Search, View Mode, Refresh */}
        <div className="flex items-center gap-2 w-full sm:w-auto">
          <div className="relative flex-1 sm:w-64">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
            <input
              type="text"
              value={localSearch}
              onChange={(e) => setLocalSearch(e.target.value)}
              placeholder="Filter current view..."
              className="w-full h-9 pl-9 pr-3 text-xs rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 text-slate-900 dark:text-white placeholder-slate-400 focus:outline-none focus:border-blue-500"
            />
          </div>

          <div className="flex items-center bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-0.5">
            <button
              onClick={() => setViewMode('table')}
              className={`p-1.5 rounded-lg transition-colors ${
                viewMode === 'table' ? 'bg-blue-600 text-white' : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              <List className="w-4 h-4" />
            </button>
            <button
              onClick={() => setViewMode('grid')}
              className={`p-1.5 rounded-lg transition-colors ${
                viewMode === 'grid' ? 'bg-blue-600 text-white' : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              <LayoutGrid className="w-4 h-4" />
            </button>
          </div>

          <button
            onClick={() => loadFolderContents(currentFolderId)}
            disabled={loading}
            className="p-2 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 text-slate-600 dark:text-slate-300 hover:text-blue-500"
          >
            <RefreshCw className={`w-4 h-4 ${loading ? 'animate-spin text-blue-500' : ''}`} />
          </button>
        </div>
      </div>

      {/* Breadcrumb Navigation Bar */}
      <div className="flex items-center justify-between p-3 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 text-xs">
        <div className="flex items-center gap-1.5 flex-wrap overflow-x-auto">
          {breadcrumbs.length > 1 && (
            <button
              onClick={handleGoUp}
              className="p-1 rounded-lg text-slate-500 hover:bg-slate-100 dark:hover:bg-slate-800 mr-1"
              title="Go up one folder"
            >
              <ArrowLeft className="w-4 h-4" />
            </button>
          )}

          {breadcrumbs.map((crumb, idx) => {
            const isLast = idx === breadcrumbs.length - 1;
            return (
              <React.Fragment key={crumb.id || idx}>
                {idx > 0 && <ChevronRight className="w-3.5 h-3.5 text-slate-400 shrink-0" />}
                <button
                  onClick={() => handleBreadcrumbClick(idx)}
                  className={`flex items-center gap-1.5 px-2.5 py-1 rounded-lg font-medium transition-colors ${
                    isLast
                      ? 'bg-blue-50 dark:bg-blue-950/60 text-blue-600 dark:text-blue-400 font-bold'
                      : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white hover:bg-slate-100 dark:hover:bg-slate-800'
                  }`}
                >
                  {idx === 0 && <Home className="w-3.5 h-3.5" />}
                  <span>{crumb.name}</span>
                </button>
              </React.Fragment>
            );
          })}
        </div>

        <div className="text-[11px] text-slate-400 font-mono hidden sm:block shrink-0">
          {folders.length} Folders • {files.length} Files
        </div>
      </div>

      {/* Error state */}
      {error && (
        <div className="flex items-center gap-3 p-4 rounded-2xl bg-rose-50 dark:bg-rose-950/40 text-rose-600 dark:text-rose-400 border border-rose-200 dark:border-rose-900 text-xs">
          <AlertCircle className="w-4 h-4 shrink-0" />
          <div className="flex-1 font-medium">{error}</div>
          <button
            onClick={() => loadFolderContents(currentFolderId)}
            className="px-3 py-1 rounded-lg bg-rose-600 text-white font-semibold hover:bg-rose-700"
          >
            Retry
          </button>
        </div>
      )}

      {/* Loading Skeleton */}
      {loading && items.length === 0 && (
        <div className="space-y-2">
          {Array.from({ length: 8 }).map((_, i) => (
            <div key={i} className="h-12 rounded-xl bg-slate-200 dark:bg-slate-800/60 animate-pulse" />
          ))}
        </div>
      )}

      {/* Empty Folder State */}
      {!loading && filteredItems.length === 0 && !error && (
        <div className="text-center py-20 rounded-3xl border border-dashed border-slate-300 dark:border-slate-800 bg-white/50 dark:bg-slate-900/50">
          <div className="w-16 h-16 rounded-2xl bg-amber-50 dark:bg-amber-950 text-amber-500 mx-auto flex items-center justify-center mb-4">
            <FolderOpen className="w-8 h-8" />
          </div>
          <h3 className="font-bold text-slate-900 dark:text-white text-base mb-1">
            This Folder is Empty
          </h3>
          <p className="text-xs text-slate-500 max-w-sm mx-auto mb-4">
            No files or subfolders found inside {breadcrumbs[breadcrumbs.length - 1].name}.
          </p>
          {breadcrumbs.length > 1 && (
            <button
              onClick={handleGoUp}
              className="px-4 py-2 rounded-xl bg-blue-600 hover:bg-blue-700 text-white text-xs font-semibold shadow-md shadow-blue-500/20"
            >
              Go Back to Parent
            </button>
          )}
        </div>
      )}

      {/* Items View: Table or Grid */}
      {filteredItems.length > 0 &&
        (viewMode === 'table' ? (
          <div className="rounded-2xl border border-slate-200 dark:border-slate-800 overflow-hidden shadow-sm bg-white dark:bg-slate-900">
            <div className="flex items-center justify-between px-4 py-3 bg-slate-50 dark:bg-slate-950/60 border-b border-slate-200 dark:border-slate-800 text-[11px] font-bold uppercase tracking-wider text-slate-400">
              <span className="flex-1">Name</span>
              <span className="hidden md:block w-32">Type</span>
              <span className="hidden sm:block w-24 text-right pr-4">Size</span>
              <span className="hidden lg:block w-32 text-right pr-4">Modified</span>
              <span className="w-20 text-right">Actions</span>
            </div>

            <div className="divide-y divide-slate-100 dark:divide-slate-800/60">
              {filteredItems.map((item) => (
                <FileRow
                  key={item.id}
                  file={item}
                  onClick={handleItemClick}
                  onToggleFavorite={onToggleFavorite}
                  onDownload={onDownload}
                />
              ))}
            </div>
          </div>
        ) : (
          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-4">
            {filteredItems.map((item) => (
              <FileCard
                key={item.id}
                file={item}
                onClick={handleItemClick}
                onToggleFavorite={onToggleFavorite}
                onDownload={onDownload}
              />
            ))}
          </div>
        ))}

      {/* Pagination Load More */}
      {nextPageToken && (
        <div className="flex justify-center pt-6">
          <button
            onClick={() => loadFolderContents(currentFolderId, nextPageToken, true)}
            disabled={loading}
            className="flex items-center gap-2 px-6 py-2.5 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 hover:bg-slate-50 dark:hover:bg-slate-800 text-xs font-semibold text-slate-800 dark:text-slate-200 shadow-sm transition-all"
          >
            {loading ? <Loader2 className="w-4 h-4 animate-spin text-blue-500" /> : null}
            <span>Load More Files</span>
          </button>
        </div>
      )}
    </div>
  );
};
