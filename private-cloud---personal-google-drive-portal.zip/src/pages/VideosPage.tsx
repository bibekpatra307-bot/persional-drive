import React, { useState, useEffect, useMemo } from 'react';
import {
  Film,
  Search,
  RefreshCw,
  AlertCircle,
  Loader2,
  Play,
  Clock,
  HardDrive,
} from 'lucide-react';
import { DriveFileItem } from '../types';
import { api } from '../services/api';
import { FileCard } from '../components/FileCard';

interface VideosPageProps {
  onPlayVideo: (video: DriveFileItem) => void;
  onToggleFavorite?: (file: DriveFileItem) => void;
  onDownload: (file: DriveFileItem) => void;
}

export const VideosPage: React.FC<VideosPageProps> = ({
  onPlayVideo,
  onToggleFavorite,
  onDownload,
}) => {
  const [videos, setVideos] = useState<DriveFileItem[]>([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [nextPageToken, setNextPageToken] = useState<string | undefined>();
  const [localSearch, setLocalSearch] = useState('');

  const loadVideos = async (pageToken?: string, append = false) => {
    setLoading(true);
    setError(null);
    try {
      const res = await api.drive.listFiles({
        category: 'videos',
        pageSize: 30,
        pageToken,
        sortBy: 'modifiedTime',
        sortOrder: 'desc',
      });

      if (append) {
        setVideos((prev) => [...prev, ...res.files]);
      } else {
        setVideos(res.files);
      }
      setNextPageToken(res.nextPageToken);
    } catch (err: any) {
      setError(err.message || 'Failed to load videos from Google Drive');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadVideos();
  }, []);

  const filteredVideos = useMemo(() => {
    if (!localSearch.trim()) return videos;
    const q = localSearch.toLowerCase();
    return videos.filter((v) => v.name.toLowerCase().includes(q));
  }, [videos, localSearch]);

  return (
    <div className="space-y-6 animate-in fade-in duration-300">
      {/* Header & Filter */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 pb-4 border-b border-slate-200 dark:border-slate-800">
        <div>
          <div className="flex items-center gap-2">
            <div className="p-2 rounded-xl bg-purple-50 dark:bg-purple-950/60 text-purple-600 dark:text-purple-400">
              <Film className="w-5 h-5" />
            </div>
            <h1 className="text-xl sm:text-2xl font-bold text-slate-900 dark:text-white">
              Video Gallery
            </h1>
          </div>
          <p className="text-xs text-slate-500 mt-1">
            Stream your personal video recordings directly with instant seeking and fullscreen support
          </p>
        </div>

        <div className="flex items-center gap-2 w-full sm:w-auto">
          <div className="relative flex-1 sm:w-64">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
            <input
              type="text"
              value={localSearch}
              onChange={(e) => setLocalSearch(e.target.value)}
              placeholder="Search videos..."
              className="w-full h-9 pl-9 pr-3 text-xs rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 text-slate-900 dark:text-white placeholder-slate-400 focus:outline-none focus:border-blue-500"
            />
          </div>

          <button
            onClick={() => loadVideos()}
            title="Reload videos"
            disabled={loading}
            className="p-2 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 text-slate-600 dark:text-slate-300 hover:text-blue-500 hover:bg-slate-50 dark:hover:bg-slate-800"
          >
            <RefreshCw className={`w-4 h-4 ${loading ? 'animate-spin text-blue-500' : ''}`} />
          </button>
        </div>
      </div>

      {/* Error State */}
      {error && (
        <div className="flex items-center gap-3 p-4 rounded-2xl bg-rose-50 dark:bg-rose-950/40 text-rose-600 dark:text-rose-400 border border-rose-200 dark:border-rose-900 text-xs">
          <AlertCircle className="w-4 h-4 shrink-0" />
          <div className="flex-1 font-medium">{error}</div>
          <button
            onClick={() => loadVideos()}
            className="px-3 py-1 rounded-lg bg-rose-600 text-white font-semibold hover:bg-rose-700"
          >
            Retry
          </button>
        </div>
      )}

      {/* Skeleton Loading */}
      {loading && videos.length === 0 && (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
          {Array.from({ length: 8 }).map((_, i) => (
            <div
              key={i}
              className="aspect-video rounded-2xl bg-slate-200 dark:bg-slate-800/60 animate-pulse"
            />
          ))}
        </div>
      )}

      {/* Empty State */}
      {!loading && filteredVideos.length === 0 && !error && (
        <div className="text-center py-20 rounded-3xl border border-dashed border-slate-300 dark:border-slate-800 bg-white/50 dark:bg-slate-900/50">
          <div className="w-16 h-16 rounded-2xl bg-purple-50 dark:bg-purple-950 text-purple-500 mx-auto flex items-center justify-center mb-4">
            <Film className="w-8 h-8" />
          </div>
          <h3 className="font-bold text-slate-900 dark:text-white text-base mb-1">No Videos Found</h3>
          <p className="text-xs text-slate-500 max-w-sm mx-auto mb-4">
            No video files found in your permitted Google Drive folders. Make sure your video folders are
            selected in Settings.
          </p>
        </div>
      )}

      {/* Video Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4 sm:gap-6">
        {filteredVideos.map((video) => (
          <FileCard
            key={video.id}
            file={video}
            onClick={onPlayVideo}
            onToggleFavorite={onToggleFavorite}
            onDownload={onDownload}
          />
        ))}
      </div>

      {/* Pagination Load More */}
      {nextPageToken && (
        <div className="flex justify-center pt-6">
          <button
            onClick={() => loadVideos(nextPageToken, true)}
            disabled={loading}
            className="flex items-center gap-2 px-6 py-2.5 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 hover:bg-slate-50 dark:hover:bg-slate-800 text-xs font-semibold text-slate-800 dark:text-slate-200 shadow-sm transition-all"
          >
            {loading ? <Loader2 className="w-4 h-4 animate-spin text-blue-500" /> : null}
            <span>Load More Videos</span>
          </button>
        </div>
      )}
    </div>
  );
};
