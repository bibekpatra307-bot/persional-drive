import React, { useState, useEffect, useMemo } from 'react';
import {
  Image as ImageIcon,
  Search,
  Download,
  Calendar,
  Loader2,
  AlertCircle,
  RefreshCw,
  FolderOpen,
} from 'lucide-react';
import { DriveFileItem } from '../types';
import { api } from '../services/api';

interface PhotosPageProps {
  onOpenLightbox: (photos: DriveFileItem[], initialIndex: number) => void;
  onToggleFavorite?: (file: DriveFileItem) => void;
  onDownload: (file: DriveFileItem) => void;
}

export const PhotosPage: React.FC<PhotosPageProps> = ({
  onOpenLightbox,
  onToggleFavorite,
  onDownload,
}) => {
  const [photos, setPhotos] = useState<DriveFileItem[]>([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [nextPageToken, setNextPageToken] = useState<string | undefined>();
  const [localSearch, setLocalSearch] = useState('');

  const loadPhotos = async (pageToken?: string, append = false) => {
    setLoading(true);
    setError(null);
    try {
      const res = await api.drive.listFiles({
        category: 'photos',
        pageSize: 40,
        pageToken,
        sortBy: 'modifiedTime',
        sortOrder: 'desc',
      });

      if (append) {
        setPhotos((prev) => [...prev, ...res.files]);
      } else {
        setPhotos(res.files);
      }
      setNextPageToken(res.nextPageToken);
    } catch (err: any) {
      setError(err.message || 'Failed to load photos from Google Drive');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadPhotos();
  }, []);

  // Filter photos by search keyword
  const filteredPhotos = useMemo(() => {
    if (!localSearch.trim()) return photos;
    const q = localSearch.toLowerCase();
    return photos.filter((p) => p.name.toLowerCase().includes(q));
  }, [photos, localSearch]);

  // Group photos by year/month for a Google Photos-like timeline
  const groupedPhotos = useMemo(() => {
    const groups: { [key: string]: DriveFileItem[] } = {};
    filteredPhotos.forEach((p) => {
      const date = p.modifiedTime ? new Date(p.modifiedTime) : new Date();
      const key = date.toLocaleDateString(undefined, { year: 'numeric', month: 'long' });
      if (!groups[key]) groups[key] = [];
      groups[key].push(p);
    });
    return groups;
  }, [filteredPhotos]);

  return (
    <div className="space-y-6 animate-in fade-in duration-300">
      {/* Header & Search */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 pb-4 border-b border-slate-200 dark:border-slate-800">
        <div>
          <div className="flex items-center gap-2">
            <div className="p-2 rounded-xl bg-emerald-50 dark:bg-emerald-950/60 text-emerald-600 dark:text-emerald-400">
              <ImageIcon className="w-5 h-5" />
            </div>
            <h1 className="text-xl sm:text-2xl font-bold text-slate-900 dark:text-white">
              Photo Gallery
            </h1>
          </div>
          <p className="text-xs text-slate-500 mt-1">
            Browse high-resolution photos and memories stored in your private Google Drive
          </p>
        </div>

        {/* Search & Refresh */}
        <div className="flex items-center gap-2 w-full sm:w-auto">
          <div className="relative flex-1 sm:w-64">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
            <input
              type="text"
              value={localSearch}
              onChange={(e) => setLocalSearch(e.target.value)}
              placeholder="Filter photos by name..."
              className="w-full h-9 pl-9 pr-3 text-xs rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 text-slate-900 dark:text-white placeholder-slate-400 focus:outline-none focus:border-blue-500"
            />
          </div>

          <button
            onClick={() => loadPhotos()}
            title="Reload photos"
            disabled={loading}
            className="p-2 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 text-slate-600 dark:text-slate-300 hover:text-blue-500 hover:bg-slate-50 dark:hover:bg-slate-800"
          >
            <RefreshCw className={`w-4 h-4 ${loading ? 'animate-spin text-blue-500' : ''}`} />
          </button>
        </div>
      </div>

      {/* Error state */}
      {error && (
        <div className="flex items-center gap-3 p-4 rounded-2xl bg-rose-50 dark:bg-rose-950/40 text-rose-600 dark:text-rose-400 border border-rose-200 dark:border-rose-900 text-xs">
          <AlertCircle className="w-5 h-5 shrink-0" />
          <div className="flex-1 font-medium">{error}</div>
          <button
            onClick={() => loadPhotos()}
            className="px-3 py-1 rounded-lg bg-rose-600 text-white font-semibold hover:bg-rose-700"
          >
            Retry
          </button>
        </div>
      )}

      {/* Loading initial skeleton */}
      {loading && photos.length === 0 && (
        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-3 sm:gap-4">
          {Array.from({ length: 15 }).map((_, i) => (
            <div
              key={i}
              className="aspect-square rounded-2xl bg-slate-200 dark:bg-slate-800/60 animate-pulse"
            />
          ))}
        </div>
      )}

      {/* Empty State */}
      {!loading && filteredPhotos.length === 0 && !error && (
        <div className="text-center py-20 rounded-3xl border border-dashed border-slate-300 dark:border-slate-800 bg-white/50 dark:bg-slate-900/50">
          <div className="w-16 h-16 rounded-2xl bg-emerald-50 dark:bg-emerald-950 text-emerald-500 mx-auto flex items-center justify-center mb-4">
            <ImageIcon className="w-8 h-8" />
          </div>
          <h3 className="font-bold text-slate-900 dark:text-white text-base mb-1">No Photos Found</h3>
          <p className="text-xs text-slate-500 max-w-sm mx-auto mb-4">
            No image files were found in your permitted Google Drive folders. Make sure you have photos
            in your Drive and that the folders are selected in Settings.
          </p>
        </div>
      )}

      {/* Photo Timeline / Grid */}
      {Object.entries(groupedPhotos).map(([timelineKey, items]) => (
        <div key={timelineKey} className="space-y-3">
          <div className="flex items-center gap-2 sticky top-16 z-10 py-1 bg-slate-50/90 dark:bg-slate-950/90 backdrop-blur-xs">
            <Calendar className="w-4 h-4 text-emerald-500" />
            <h2 className="text-xs font-bold uppercase tracking-wider text-slate-700 dark:text-slate-300">
              {timelineKey}
            </h2>
            <span className="text-[11px] text-slate-400 font-mono">({items.length})</span>
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-3 sm:gap-4">
            {items.map((photo) => {
              const globalIndex = filteredPhotos.findIndex((p) => p.id === photo.id);
              const thumbUrl = photo.thumbnailLink
                ? photo.thumbnailLink.replace(/=s\d+/, '=s500')
                : `/api/drive/stream/${photo.id}`;

              return (
                <div
                  key={photo.id}
                  onClick={() => onOpenLightbox(filteredPhotos, globalIndex)}
                  className="group relative aspect-square rounded-2xl overflow-hidden cursor-pointer bg-slate-100 dark:bg-slate-800 border border-slate-200/60 dark:border-slate-800/80 hover:shadow-xl hover:shadow-black/20 hover:scale-[1.02] transition-all"
                >
                  <img
                    src={thumbUrl}
                    alt={photo.name}
                    loading="lazy"
                    className="w-full h-full object-cover"
                  />

                  {/* Gradient shadow on bottom with file name */}
                  <div className="absolute inset-x-0 bottom-0 p-2.5 bg-gradient-to-t from-black/80 via-black/40 to-transparent opacity-0 group-hover:opacity-100 transition-opacity flex flex-col justify-end text-white">
                    <span className="text-xs font-semibold truncate leading-tight">{photo.name}</span>
                    <span className="text-[10px] text-slate-300 opacity-90 mt-0.5">
                      {photo.imageMediaMetadata?.width && `${photo.imageMediaMetadata.width}×${photo.imageMediaMetadata.height}`}
                    </span>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      ))}

      {/* Pagination Load More */}
      {nextPageToken && (
        <div className="flex justify-center pt-6">
          <button
            onClick={() => loadPhotos(nextPageToken, true)}
            disabled={loading}
            className="flex items-center gap-2 px-6 py-2.5 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 hover:bg-slate-50 dark:hover:bg-slate-800 text-xs font-semibold text-slate-800 dark:text-slate-200 shadow-sm transition-all"
          >
            {loading ? <Loader2 className="w-4 h-4 animate-spin text-blue-500" /> : null}
            <span>Load More Photos</span>
          </button>
        </div>
      )}
    </div>
  );
};
