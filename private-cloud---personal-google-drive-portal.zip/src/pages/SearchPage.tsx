import React, { useState, useEffect } from 'react';
import {
  Search,
  Filter,
  Loader2,
  AlertCircle,
  FileQuestion,
  Calendar,
  HardDrive,
  LayoutGrid,
  List,
} from 'lucide-react';
import { DriveFileItem } from '../types';
import { api } from '../services/api';
import { FileCard } from '../components/FileCard';
import { FileRow } from '../components/FileRow';

interface SearchPageProps {
  initialQuery?: string;
  onOpenFile: (file: DriveFileItem) => void;
  onToggleFavorite?: (file: DriveFileItem) => void;
  onDownload: (file: DriveFileItem) => void;
}

export const SearchPage: React.FC<SearchPageProps> = ({
  initialQuery = '',
  onOpenFile,
  onToggleFavorite,
  onDownload,
}) => {
  const [query, setQuery] = useState(initialQuery);
  const [category, setCategory] = useState<string>('all');
  const [results, setResults] = useState<DriveFileItem[]>([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [viewMode, setViewMode] = useState<'grid' | 'table'>('table');
  const [hasSearched, setHasSearched] = useState(false);

  // Sync initial query
  useEffect(() => {
    if (initialQuery) {
      setQuery(initialQuery);
      performSearch(initialQuery, category);
    }
  }, [initialQuery]);

  const performSearch = async (searchTerm: string, cat = category) => {
    if (!searchTerm.trim()) {
      setResults([]);
      setHasSearched(false);
      return;
    }

    setLoading(true);
    setError(null);
    setHasSearched(true);

    try {
      const res = await api.drive.searchFiles({
        q: searchTerm.trim(),
        category: cat === 'all' ? undefined : cat,
        pageSize: 40,
      });
      setResults(res.files);
    } catch (err: any) {
      setError(err.message || 'Search failed');
    } finally {
      setLoading(false);
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    performSearch(query, category);
  };

  const handleCategoryChange = (newCat: string) => {
    setCategory(newCat);
    if (query.trim()) {
      performSearch(query, newCat);
    }
  };

  return (
    <div className="space-y-6 animate-in fade-in duration-300">
      {/* Header & Main Search Input */}
      <div className="space-y-4 pb-4 border-b border-slate-200 dark:border-slate-800">
        <div>
          <h1 className="text-xl sm:text-2xl font-bold text-slate-900 dark:text-white">
            Global File Search
          </h1>
          <p className="text-xs text-slate-500 mt-1">
            Search documents, media, and folders directly across your authorized Google Drive
          </p>
        </div>

        <form onSubmit={handleSubmit} className="flex gap-2">
          <div className="relative flex-1">
            <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-400" />
            <input
              type="text"
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              placeholder="Search by file name, keyword, or extension (e.g. invoice.pdf, vacation, report)..."
              autoFocus
              className="w-full h-12 pl-12 pr-4 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 text-sm text-slate-900 dark:text-white placeholder-slate-400 focus:outline-none focus:border-blue-500 focus:ring-2 focus:ring-blue-500/20 shadow-sm transition-all"
            />
          </div>

          <button
            type="submit"
            disabled={loading}
            className="px-6 h-12 rounded-2xl bg-blue-600 hover:bg-blue-700 text-white font-semibold text-xs sm:text-sm flex items-center justify-center gap-2 shadow-md shadow-blue-500/20 transition-all shrink-0 disabled:opacity-50"
          >
            {loading ? <Loader2 className="w-4 h-4 animate-spin" /> : <Search className="w-4 h-4" />}
            <span>Search</span>
          </button>
        </form>

        {/* Filter Badges & View Switcher */}
        <div className="flex flex-wrap items-center justify-between gap-3 pt-2">
          <div className="flex items-center gap-2 overflow-x-auto pb-1 text-xs">
            <div className="flex items-center gap-1 text-slate-400 mr-1 text-[11px] font-semibold uppercase">
              <Filter className="w-3.5 h-3.5" />
              <span>Filters:</span>
            </div>

            {[
              { id: 'all', label: 'All Types' },
              { id: 'photos', label: 'Photos' },
              { id: 'videos', label: 'Videos' },
              { id: 'documents', label: 'Documents' },
              { id: 'pdf', label: 'PDFs' },
            ].map((cat) => (
              <button
                key={cat.id}
                type="button"
                onClick={() => handleCategoryChange(cat.id)}
                className={`px-3 py-1.5 rounded-xl font-medium transition-colors shrink-0 ${
                  category === cat.id
                    ? 'bg-blue-600 text-white shadow-sm'
                    : 'bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 text-slate-600 dark:text-slate-300 hover:bg-slate-50 dark:hover:bg-slate-800'
                }`}
              >
                {cat.label}
              </button>
            ))}
          </div>

          {results.length > 0 && (
            <div className="flex items-center bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-0.5">
              <button
                onClick={() => setViewMode('table')}
                className={`p-1.5 rounded-lg transition-colors ${
                  viewMode === 'table' ? 'bg-blue-600 text-white' : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                <List className="w-4 h-4" />
              </button>
              <button
                onClick={() => setViewMode('grid')}
                className={`p-1.5 rounded-lg transition-colors ${
                  viewMode === 'grid' ? 'bg-blue-600 text-white' : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                <LayoutGrid className="w-4 h-4" />
              </button>
            </div>
          )}
        </div>
      </div>

      {/* Error state */}
      {error && (
        <div className="flex items-center gap-3 p-4 rounded-2xl bg-rose-50 dark:bg-rose-950/40 text-rose-600 dark:text-rose-400 border border-rose-200 dark:border-rose-900 text-xs">
          <AlertCircle className="w-5 h-5 shrink-0" />
          <div className="flex-1 font-medium">{error}</div>
        </div>
      )}

      {/* Loading state */}
      {loading && (
        <div className="flex flex-col items-center justify-center py-20 text-slate-400 gap-3">
          <Loader2 className="w-8 h-8 animate-spin text-blue-500" />
          <span className="text-xs">Searching Google Drive index...</span>
        </div>
      )}

      {/* Search results */}
      {!loading && hasSearched && results.length === 0 && !error && (
        <div className="text-center py-20 rounded-3xl border border-dashed border-slate-300 dark:border-slate-800 bg-white/50 dark:bg-slate-900/50">
          <div className="w-16 h-16 rounded-2xl bg-slate-100 dark:bg-slate-800 text-slate-400 mx-auto flex items-center justify-center mb-4">
            <FileQuestion className="w-8 h-8" />
          </div>
          <h3 className="font-bold text-slate-900 dark:text-white text-base mb-1">
            No Matching Files Found
          </h3>
          <p className="text-xs text-slate-500 max-w-sm mx-auto">
            We couldn't find any files matching "{query}" in your permitted Google Drive folders. Try a
            different keyword or filter.
          </p>
        </div>
      )}

      {!loading && results.length > 0 && (
        <div className="space-y-4">
          <div className="text-xs text-slate-500 font-mono">
            Found {results.length} result(s) for "{query}"
          </div>

          {viewMode === 'table' ? (
            <div className="rounded-2xl border border-slate-200 dark:border-slate-800 overflow-hidden shadow-sm bg-white dark:bg-slate-900">
              <div className="flex items-center justify-between px-4 py-3 bg-slate-50 dark:bg-slate-950/60 border-b border-slate-200 dark:border-slate-800 text-[11px] font-bold uppercase tracking-wider text-slate-400">
                <span className="flex-1">File Name</span>
                <span className="hidden md:block w-32">Type</span>
                <span className="hidden sm:block w-24 text-right pr-4">Size</span>
                <span className="hidden lg:block w-32 text-right pr-4">Modified</span>
                <span className="w-20 text-right">Actions</span>
              </div>

              <div className="divide-y divide-slate-100 dark:divide-slate-800/60">
                {results.map((file) => (
                  <FileRow
                    key={file.id}
                    file={file}
                    onClick={onOpenFile}
                    onToggleFavorite={onToggleFavorite}
                    onDownload={onDownload}
                  />
                ))}
              </div>
            </div>
          ) : (
            <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-4">
              {results.map((file) => (
                <FileCard
                  key={file.id}
                  file={file}
                  onClick={onOpenFile}
                  onToggleFavorite={onToggleFavorite}
                  onDownload={onDownload}
                />
              ))}
            </div>
          )}
        </div>
      )}

      {/* Search Tips / Initial State */}
      {!hasSearched && !loading && (
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 pt-4">
          <div className="p-5 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800">
            <h4 className="font-semibold text-xs text-slate-900 dark:text-white uppercase tracking-wider mb-2">
              Name Search
            </h4>
            <p className="text-xs text-slate-500 leading-relaxed">
              Type full or partial file names like <code className="text-blue-500">IMG_2026</code> or{' '}
              <code className="text-blue-500">Report</code>.
            </p>
          </div>

          <div className="p-5 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800">
            <h4 className="font-semibold text-xs text-slate-900 dark:text-white uppercase tracking-wider mb-2">
              Category Filtering
            </h4>
            <p className="text-xs text-slate-500 leading-relaxed">
              Use category filters to narrow results strictly to Photos, Videos, or PDF documents.
            </p>
          </div>

          <div className="p-5 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800">
            <h4 className="font-semibold text-xs text-slate-900 dark:text-white uppercase tracking-wider mb-2">
              Instant Cloud Queries
            </h4>
            <p className="text-xs text-slate-500 leading-relaxed">
              Searches are executed on the server using Google Drive queries without downloading thousands
              of files locally.
            </p>
          </div>
        </div>
      )}
    </div>
  );
};
