import React from 'react';
import {
  Image as ImageIcon,
  Film,
  FileText,
  Folder,
  ArrowRight,
  HardDrive,
  Clock,
  Sparkles,
  Search,
  CheckCircle2,
  AlertTriangle,
} from 'lucide-react';
import { CategoryCounts, DriveFileItem, DriveStatus, ViewTab } from '../types';
import { FileCard } from '../components/FileCard';
import { Trash2 } from 'lucide-react';

interface DashboardPageProps {
  counts?: CategoryCounts;
  recentFiles: DriveFileItem[];
  driveStatus: DriveStatus | null;
  onTabChange: (tab: ViewTab) => void;
  onOpenFile: (file: DriveFileItem) => void;
  onToggleFavorite?: (file: DriveFileItem) => void;
  onDownload: (file: DriveFileItem) => void;
  onOpenDisconnectDrive?: () => void;
}

export const DashboardPage: React.FC<DashboardPageProps> = ({
  counts,
  recentFiles,
  driveStatus,
  onTabChange,
  onOpenFile,
  onToggleFavorite,
  onDownload,
  onOpenDisconnectDrive,
}) => {
  const formatBytes = (bytes?: string | number) => {
    if (!bytes) return '0 GB';
    const b = typeof bytes === 'string' ? parseInt(bytes, 10) : bytes;
    if (isNaN(b) || b <= 0) return '0 GB';
    const gb = b / (1024 * 1024 * 1024);
    return `${gb.toFixed(2)} GB`;
  };

  const usageBytes = driveStatus?.storageQuota?.usage
    ? parseInt(driveStatus.storageQuota.usage, 10)
    : 0;
  const limitBytes = driveStatus?.storageQuota?.limit
    ? parseInt(driveStatus.storageQuota.limit, 10)
    : 0;
  const percentUsed =
    limitBytes > 0 ? Math.min(Math.round((usageBytes / limitBytes) * 100), 100) : 0;

  return (
    <div className="space-y-8 animate-in fade-in duration-300">
      {/* Top Welcome / Hero Banner */}
      <div className="relative overflow-hidden rounded-3xl bg-gradient-to-r from-blue-700 via-indigo-600 to-purple-700 p-6 sm:p-8 text-white shadow-xl shadow-blue-500/10">
        <div className="relative z-10 max-w-2xl">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-white/15 backdrop-blur-md text-xs font-medium mb-3">
            <Sparkles className="w-3.5 h-3.5 text-amber-300" />
            <span>Private Cloud Portal Active</span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-extrabold tracking-tight mb-2">
            Welcome to Your Private Cloud
          </h1>
          <p className="text-blue-100 text-xs sm:text-sm leading-relaxed mb-6">
            Securely access, view, stream and download your photos, videos, and documents directly from
            your authorized Google Drive without exposing Google credentials.
          </p>

          <div className="flex flex-wrap items-center gap-3">
            <button
              onClick={() => onTabChange('photos')}
              className="flex items-center gap-2 px-4 py-2.5 rounded-xl bg-white text-blue-700 hover:bg-blue-50 font-semibold text-xs shadow-md transition-all hover:scale-105"
            >
              <ImageIcon className="w-4 h-4" />
              <span>Browse Photos</span>
            </button>
            <button
              onClick={() => onTabChange('videos')}
              className="flex items-center gap-2 px-4 py-2.5 rounded-xl bg-white/20 hover:bg-white/30 text-white font-semibold text-xs backdrop-blur-md transition-all"
            >
              <Film className="w-4 h-4" />
              <span>Stream Videos</span>
            </button>
            <button
              onClick={() => onTabChange('files')}
              className="flex items-center gap-2 px-4 py-2.5 rounded-xl bg-white/20 hover:bg-white/30 text-white font-semibold text-xs backdrop-blur-md transition-all"
            >
              <Folder className="w-4 h-4" />
              <span>File Explorer</span>
            </button>
          </div>
        </div>

        {/* Decorative background shapes */}
        <div className="absolute right-0 top-0 bottom-0 w-1/3 bg-white/5 skew-x-12 pointer-events-none" />
        <div className="absolute -right-10 -bottom-10 w-64 h-64 bg-purple-500/20 rounded-full blur-2xl pointer-events-none" />
      </div>

      {/* Google Drive Status Alert / Management */}
      {!driveStatus?.connected ? (
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 p-5 rounded-2xl bg-amber-50 dark:bg-amber-950/40 border border-amber-200 dark:border-amber-800 text-amber-900 dark:text-amber-200 shadow-sm">
          <div className="flex items-start gap-3">
            <div className="p-2 rounded-xl bg-amber-100 dark:bg-amber-900/60 text-amber-700 dark:text-amber-400 shrink-0">
              <AlertTriangle className="w-5 h-5" />
            </div>
            <div>
              <h4 className="font-bold text-sm">Google Drive Connection Required</h4>
              <p className="text-xs text-amber-800/80 dark:text-amber-300/80 mt-0.5">
                Connect your Google Drive in Settings to view and stream your files through this private
                portal.
              </p>
            </div>
          </div>
          <button
            onClick={() => onTabChange('settings')}
            className="px-4 py-2 rounded-xl bg-amber-600 hover:bg-amber-700 text-white font-semibold text-xs shadow-md transition-colors shrink-0"
          >
            Connect Google Drive
          </button>
        </div>
      ) : (
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 p-4 sm:p-5 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800/80 shadow-sm">
          <div className="flex items-center gap-3.5">
            <div className="w-10 h-10 rounded-xl bg-emerald-50 dark:bg-emerald-950/60 text-emerald-600 dark:text-emerald-400 flex items-center justify-center shrink-0">
              <HardDrive className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="font-bold text-slate-900 dark:text-white text-sm">
                  Google Drive Connected
                </span>
                <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
              </div>
              <p className="text-xs text-slate-500 mt-0.5">
                Authorized as{' '}
                <span className="font-medium text-slate-700 dark:text-slate-300">
                  {driveStatus.email || 'Google User'}
                </span>{' '}
                •{' '}
                {driveStatus.allowedFolderCount > 0
                  ? `${driveStatus.allowedFolderCount} folder(s) selected`
                  : 'All folders accessible'}
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2 w-full sm:w-auto justify-end">
            <button
              onClick={() => onTabChange('settings')}
              className="px-3.5 py-1.5 rounded-xl border border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 text-xs font-semibold transition-colors"
            >
              Manage Folders
            </button>
            <button
              onClick={onOpenDisconnectDrive}
              className="flex items-center gap-1.5 px-3.5 py-1.5 rounded-xl bg-rose-50 dark:bg-rose-950/40 text-rose-600 dark:text-rose-400 border border-rose-200 dark:border-rose-900 hover:bg-rose-100 dark:hover:bg-rose-900/60 text-xs font-semibold transition-colors"
            >
              <Trash2 className="w-3.5 h-3.5" />
              <span>Disconnect</span>
            </button>
          </div>
        </div>
      )}

      {/* Primary Category Cards */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 sm:gap-6">
        {/* Photos Card */}
        <div
          onClick={() => onTabChange('photos')}
          className="group relative p-5 sm:p-6 rounded-2xl border transition-all cursor-pointer bg-white dark:bg-slate-900 border-slate-200/80 dark:border-slate-800/80 hover:border-emerald-500/50 hover:shadow-xl hover:shadow-emerald-500/5 hover:-translate-y-1"
        >
          <div className="flex items-center justify-between mb-4">
            <div className="w-12 h-12 rounded-2xl bg-emerald-50 dark:bg-emerald-950/50 text-emerald-600 dark:text-emerald-400 flex items-center justify-center group-hover:scale-110 transition-transform">
              <ImageIcon className="w-6 h-6" />
            </div>
            <ArrowRight className="w-4 h-4 text-slate-400 group-hover:text-emerald-500 group-hover:translate-x-1 transition-all" />
          </div>
          <h3 className="font-bold text-slate-900 dark:text-white text-base">Photos</h3>
          <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
            {counts?.photos !== undefined ? `${counts.photos} images stored` : 'High-res image gallery'}
          </p>
        </div>

        {/* Videos Card */}
        <div
          onClick={() => onTabChange('videos')}
          className="group relative p-5 sm:p-6 rounded-2xl border transition-all cursor-pointer bg-white dark:bg-slate-900 border-slate-200/80 dark:border-slate-800/80 hover:border-purple-500/50 hover:shadow-xl hover:shadow-purple-500/5 hover:-translate-y-1"
        >
          <div className="flex items-center justify-between mb-4">
            <div className="w-12 h-12 rounded-2xl bg-purple-50 dark:bg-purple-950/50 text-purple-600 dark:text-purple-400 flex items-center justify-center group-hover:scale-110 transition-transform">
              <Film className="w-6 h-6" />
            </div>
            <ArrowRight className="w-4 h-4 text-slate-400 group-hover:text-purple-500 group-hover:translate-x-1 transition-all" />
          </div>
          <h3 className="font-bold text-slate-900 dark:text-white text-base">Videos</h3>
          <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
            {counts?.videos !== undefined ? `${counts.videos} videos available` : 'Direct video streaming'}
          </p>
        </div>

        {/* Documents Card */}
        <div
          onClick={() => onTabChange('documents')}
          className="group relative p-5 sm:p-6 rounded-2xl border transition-all cursor-pointer bg-white dark:bg-slate-900 border-slate-200/80 dark:border-slate-800/80 hover:border-blue-500/50 hover:shadow-xl hover:shadow-blue-500/5 hover:-translate-y-1"
        >
          <div className="flex items-center justify-between mb-4">
            <div className="w-12 h-12 rounded-2xl bg-blue-50 dark:bg-blue-950/50 text-blue-600 dark:text-blue-400 flex items-center justify-center group-hover:scale-110 transition-transform">
              <FileText className="w-6 h-6" />
            </div>
            <ArrowRight className="w-4 h-4 text-slate-400 group-hover:text-blue-500 group-hover:translate-x-1 transition-all" />
          </div>
          <h3 className="font-bold text-slate-900 dark:text-white text-base">Documents</h3>
          <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
            {counts?.documents !== undefined
              ? `${counts.documents} files (PDF, Docs, Sheets)`
              : 'PDF & Office files'}
          </p>
        </div>

        {/* Files Card */}
        <div
          onClick={() => onTabChange('files')}
          className="group relative p-5 sm:p-6 rounded-2xl border transition-all cursor-pointer bg-white dark:bg-slate-900 border-slate-200/80 dark:border-slate-800/80 hover:border-amber-500/50 hover:shadow-xl hover:shadow-amber-500/5 hover:-translate-y-1"
        >
          <div className="flex items-center justify-between mb-4">
            <div className="w-12 h-12 rounded-2xl bg-amber-50 dark:bg-amber-950/50 text-amber-600 dark:text-amber-400 flex items-center justify-center group-hover:scale-110 transition-transform">
              <Folder className="w-6 h-6" />
            </div>
            <ArrowRight className="w-4 h-4 text-slate-400 group-hover:text-amber-500 group-hover:translate-x-1 transition-all" />
          </div>
          <h3 className="font-bold text-slate-900 dark:text-white text-base">File Explorer</h3>
          <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
            Full directory & folder browser
          </p>
        </div>
      </div>

      {/* Storage Quota Overview Bar */}
      {driveStatus?.connected && driveStatus.storageQuota?.usage && (
        <div className="p-6 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800/80 shadow-sm">
          <div className="flex items-center justify-between mb-2">
            <div className="flex items-center gap-2">
              <HardDrive className="w-4 h-4 text-blue-500" />
              <span className="text-xs font-bold uppercase tracking-wider text-slate-700 dark:text-slate-300">
                Google Drive Storage
              </span>
            </div>
            <span className="text-xs font-mono font-medium text-slate-600 dark:text-slate-400">
              {formatBytes(usageBytes)} / {formatBytes(limitBytes)} ({percentUsed}%)
            </span>
          </div>

          <div className="w-full h-2.5 bg-slate-100 dark:bg-slate-800 rounded-full overflow-hidden">
            <div
              className={`h-full transition-all duration-500 ${
                percentUsed > 85 ? 'bg-rose-500' : percentUsed > 70 ? 'bg-amber-500' : 'bg-blue-600'
              }`}
              style={{ width: `${Math.max(percentUsed, 2)}%` }}
            />
          </div>
        </div>
      )}

      {/* Recent Files Section */}
      <div className="space-y-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Clock className="w-5 h-5 text-slate-400" />
            <h2 className="font-bold text-slate-900 dark:text-white text-lg">Recently Viewed</h2>
          </div>
          {recentFiles.length > 0 && (
            <button
              onClick={() => onTabChange('recent')}
              className="text-xs font-medium text-blue-600 dark:text-blue-400 hover:underline"
            >
              View all
            </button>
          )}
        </div>

        {recentFiles.length === 0 ? (
          <div className="p-8 rounded-2xl border border-dashed border-slate-300 dark:border-slate-800 text-center text-slate-500 text-xs">
            No recently opened files yet. Open any photo, video, or document to see it here.
          </div>
        ) : (
          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-4">
            {recentFiles.slice(0, 6).map((f) => (
              <FileCard
                key={f.id}
                file={f}
                onClick={onOpenFile}
                onToggleFavorite={onToggleFavorite}
                onDownload={onDownload}
              />
            ))}
          </div>
        )}
      </div>
    </div>
  );
};
