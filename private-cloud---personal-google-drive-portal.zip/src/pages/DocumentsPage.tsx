import React, { useState, useEffect, useMemo } from 'react';
import {
  FileText,
  Search,
  RefreshCw,
  AlertCircle,
  Loader2,
  FileSpreadsheet,
  FileCode,
  LayoutGrid,
  List,
} from 'lucide-react';
import { DriveFileItem } from '../types';
import { api } from '../services/api';
import { FileCard } from '../components/FileCard';
import { FileRow } from '../components/FileRow';

interface DocumentsPageProps {
  onOpenFile: (file: DriveFileItem) => void;
  onToggleFavorite?: (file: DriveFileItem) => void;
  onDownload: (file: DriveFileItem) => void;
}

export const DocumentsPage: React.FC<DocumentsPageProps> = ({
  onOpenFile,
  onToggleFavorite,
  onDownload,
}) => {
  const [docs, setDocs] = useState<DriveFileItem[]>([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [nextPageToken, setNextPageToken] = useState<string | undefined>();
  const [localSearch, setLocalSearch] = useState('');
  const [viewMode, setViewMode] = useState<'grid' | 'table'>('table');
  const [typeFilter, setTypeFilter] = useState<'all' | 'pdf' | 'office' | 'text'>('all');

  const loadDocs = async (pageToken?: string, append = false) => {
    setLoading(true);
    setError(null);
    try {
      const res = await api.drive.listFiles({
        category: 'documents',
        pageSize: 35,
        pageToken,
        sortBy: 'modifiedTime',
        sortOrder: 'desc',
      });

      if (append) {
        setDocs((prev) => [...prev, ...res.files]);
      } else {
        setDocs(res.files);
      }
      setNextPageToken(res.nextPageToken);
    } catch (err: any) {
      setError(err.message || 'Failed to load documents');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadDocs();
  }, []);

  const filteredDocs = useMemo(() => {
    return docs.filter((d) => {
      const matchesSearch = !localSearch.trim() || d.name.toLowerCase().includes(localSearch.toLowerCase());
      if (!matchesSearch) return false;

      if (typeFilter === 'pdf') return d.mimeType.includes('pdf');
      if (typeFilter === 'office')
        return (
          d.mimeType.includes('document') ||
          d.mimeType.includes('sheet') ||
          d.mimeType.includes('presentation') ||
          d.mimeType.includes('word') ||
          d.mimeType.includes('excel')
        );
      if (typeFilter === 'text')
        return (
          d.mimeType.startsWith('text/') ||
          d.mimeType.includes('json') ||
          d.mimeType.includes('code')
        );

      return true;
    });
  }, [docs, localSearch, typeFilter]);

  return (
    <div className="space-y-6 animate-in fade-in duration-300">
      {/* Header */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 pb-4 border-b border-slate-200 dark:border-slate-800">
        <div>
          <div className="flex items-center gap-2">
            <div className="p-2 rounded-xl bg-blue-50 dark:bg-blue-950/60 text-blue-600 dark:text-blue-400">
              <FileText className="w-5 h-5" />
            </div>
            <h1 className="text-xl sm:text-2xl font-bold text-slate-900 dark:text-white">
              Documents & Files
            </h1>
          </div>
          <p className="text-xs text-slate-500 mt-1">
            Access your PDFs, spreadsheets, presentations, and written documents
          </p>
        </div>

        {/* View Mode & Search */}
        <div className="flex items-center gap-2 w-full sm:w-auto">
          <div className="relative flex-1 sm:w-64">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
            <input
              type="text"
              value={localSearch}
              onChange={(e) => setLocalSearch(e.target.value)}
              placeholder="Search documents..."
              className="w-full h-9 pl-9 pr-3 text-xs rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 text-slate-900 dark:text-white placeholder-slate-400 focus:outline-none focus:border-blue-500"
            />
          </div>

          {/* Toggle Grid/Table view */}
          <div className="flex items-center bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-0.5">
            <button
              onClick={() => setViewMode('table')}
              className={`p-1.5 rounded-lg transition-colors ${
                viewMode === 'table'
                  ? 'bg-blue-600 text-white'
                  : 'text-slate-400 hover:text-slate-700 dark:hover:text-slate-200'
              }`}
            >
              <List className="w-4 h-4" />
            </button>
            <button
              onClick={() => setViewMode('grid')}
              className={`p-1.5 rounded-lg transition-colors ${
                viewMode === 'grid'
                  ? 'bg-blue-600 text-white'
                  : 'text-slate-400 hover:text-slate-700 dark:hover:text-slate-200'
              }`}
            >
              <LayoutGrid className="w-4 h-4" />
            </button>
          </div>

          <button
            onClick={() => loadDocs()}
            disabled={loading}
            className="p-2 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 text-slate-600 dark:text-slate-300 hover:text-blue-500"
          >
            <RefreshCw className={`w-4 h-4 ${loading ? 'animate-spin text-blue-500' : ''}`} />
          </button>
        </div>
      </div>

      {/* Filter Tabs */}
      <div className="flex items-center gap-2 overflow-x-auto pb-1 text-xs">
        {[
          { id: 'all', label: 'All Documents' },
          { id: 'pdf', label: 'PDFs Only' },
          { id: 'office', label: 'Office & Sheets' },
          { id: 'text', label: 'Text & Code' },
        ].map((tab) => (
          <button
            key={tab.id}
            onClick={() => setTypeFilter(tab.id as any)}
            className={`px-3 py-1.5 rounded-xl font-medium transition-colors shrink-0 ${
              typeFilter === tab.id
                ? 'bg-blue-600 text-white shadow-sm'
                : 'bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 text-slate-600 dark:text-slate-300 hover:bg-slate-50 dark:hover:bg-slate-800'
            }`}
          >
            {tab.label}
          </button>
        ))}
      </div>

      {/* Error state */}
      {error && (
        <div className="flex items-center gap-3 p-4 rounded-2xl bg-rose-50 dark:bg-rose-950/40 text-rose-600 dark:text-rose-400 border border-rose-200 dark:border-rose-900 text-xs">
          <AlertCircle className="w-5 h-5 shrink-0" />
          <div className="flex-1 font-medium">{error}</div>
          <button
            onClick={() => loadDocs()}
            className="px-3 py-1 rounded-lg bg-rose-600 text-white font-semibold hover:bg-rose-700"
          >
            Retry
          </button>
        </div>
      )}

      {/* Loading Skeleton */}
      {loading && docs.length === 0 && (
        <div className="space-y-2">
          {Array.from({ length: 6 }).map((_, i) => (
            <div
              key={i}
              className="h-14 rounded-xl bg-slate-200 dark:bg-slate-800/60 animate-pulse"
            />
          ))}
        </div>
      )}

      {/* Empty State */}
      {!loading && filteredDocs.length === 0 && !error && (
        <div className="text-center py-20 rounded-3xl border border-dashed border-slate-300 dark:border-slate-800 bg-white/50 dark:bg-slate-900/50">
          <div className="w-16 h-16 rounded-2xl bg-blue-50 dark:bg-blue-950 text-blue-500 mx-auto flex items-center justify-center mb-4">
            <FileText className="w-8 h-8" />
          </div>
          <h3 className="font-bold text-slate-900 dark:text-white text-base mb-1">
            No Documents Found
          </h3>
          <p className="text-xs text-slate-500 max-w-sm mx-auto mb-4">
            No document files match the selected filter in your permitted folders.
          </p>
        </div>
      )}

      {/* Content Rendering: Table or Grid */}
      {filteredDocs.length > 0 &&
        (viewMode === 'table' ? (
          <div className="rounded-2xl border border-slate-200 dark:border-slate-800 overflow-hidden shadow-sm bg-white dark:bg-slate-900">
            {/* Table Header */}
            <div className="flex items-center justify-between px-4 py-3 bg-slate-50 dark:bg-slate-950/60 border-b border-slate-200 dark:border-slate-800 text-[11px] font-bold uppercase tracking-wider text-slate-400">
              <span className="flex-1">File Name</span>
              <span className="hidden md:block w-32">Type</span>
              <span className="hidden sm:block w-24 text-right pr-4">Size</span>
              <span className="hidden lg:block w-32 text-right pr-4">Modified</span>
              <span className="w-20 text-right">Actions</span>
            </div>

            <div className="divide-y divide-slate-100 dark:divide-slate-800/60">
              {filteredDocs.map((doc) => (
                <FileRow
                  key={doc.id}
                  file={doc}
                  onClick={onOpenFile}
                  onToggleFavorite={onToggleFavorite}
                  onDownload={onDownload}
                />
              ))}
            </div>
          </div>
        ) : (
          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-4">
            {filteredDocs.map((doc) => (
              <FileCard
                key={doc.id}
                file={doc}
                onClick={onOpenFile}
                onToggleFavorite={onToggleFavorite}
                onDownload={onDownload}
              />
            ))}
          </div>
        ))}

      {/* Pagination Load More */}
      {nextPageToken && (
        <div className="flex justify-center pt-6">
          <button
            onClick={() => loadDocs(nextPageToken, true)}
            disabled={loading}
            className="flex items-center gap-2 px-6 py-2.5 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 hover:bg-slate-50 dark:hover:bg-slate-800 text-xs font-semibold text-slate-800 dark:text-slate-200 shadow-sm transition-all"
          >
            {loading ? <Loader2 className="w-4 h-4 animate-spin text-blue-500" /> : null}
            <span>Load More Documents</span>
          </button>
        </div>
      )}
    </div>
  );
};
