import React, { useState, useEffect, useCallback } from 'react';
import { ViewTab, DriveFileItem, DriveStatus, CategoryCounts } from './types';
import { api } from './services/api';

// Components
import { Navbar } from './components/Navbar';
import { Sidebar } from './components/Sidebar';
import { MobileNav } from './components/MobileNav';
import { PhotoLightbox } from './components/PhotoLightbox';
import { VideoPlayerModal } from './components/VideoPlayerModal';
import { FilePreviewModal } from './components/FilePreviewModal';
import { DisconnectDriveModal } from './components/DisconnectDriveModal';

// Pages
import { LoginPage } from './pages/LoginPage';
import { DashboardPage } from './pages/DashboardPage';
import { PhotosPage } from './pages/PhotosPage';
import { VideosPage } from './pages/VideosPage';
import { DocumentsPage } from './pages/DocumentsPage';
import { FileManagerPage } from './pages/FileManagerPage';
import { SearchPage } from './pages/SearchPage';
import { FavoritesPage } from './pages/FavoritesPage';
import { RecentPage } from './pages/RecentPage';
import { SettingsPage } from './pages/SettingsPage';

export default function App() {
  const [isAuthenticated, setIsAuthenticated] = useState<boolean | null>(null);
  const [isInitialized, setIsInitialized] = useState<boolean>(true);
  const [currentTab, setCurrentTab] = useState<ViewTab>('home');
  const [searchQuery, setSearchQuery] = useState('');
  const [activeSearchQuery, setActiveSearchQuery] = useState('');

  // App theme
  const [theme, setTheme] = useState<'dark' | 'light'>(() => {
    if (typeof window !== 'undefined') {
      const saved = localStorage.getItem('pc_theme');
      if (saved === 'light' || saved === 'dark') return saved;
      return window.matchMedia('(prefers-color-scheme: dark)').matches ? 'dark' : 'dark';
    }
    return 'dark';
  });

  // Cloud data
  const [driveStatus, setDriveStatus] = useState<DriveStatus | null>(null);
  const [counts, setCounts] = useState<CategoryCounts | undefined>();
  const [recentFiles, setRecentFiles] = useState<DriveFileItem[]>([]);

  // Modals & Viewers
  const [lightbox, setLightbox] = useState<{
    isOpen: boolean;
    photos: DriveFileItem[];
    currentIndex: number;
  }>({
    isOpen: false,
    photos: [],
    currentIndex: 0,
  });

  const [videoModal, setVideoModal] = useState<{
    isOpen: boolean;
    video: DriveFileItem | null;
  }>({
    isOpen: false,
    video: null,
  });

  const [previewModal, setPreviewModal] = useState<{
    isOpen: boolean;
    file: DriveFileItem | null;
  }>({
    isOpen: false,
    file: null,
  });

  const [isGlobalDisconnectModalOpen, setIsGlobalDisconnectModalOpen] = useState(false);

  // Apply theme to html root
  useEffect(() => {
    if (theme === 'dark') {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
    localStorage.setItem('pc_theme', theme);
  }, [theme]);

  const toggleTheme = () => {
    setTheme((prev) => (prev === 'dark' ? 'light' : 'dark'));
  };

  // Check auth status on launch
  const checkAuth = useCallback(async () => {
    try {
      const status = await api.auth.getStatus();
      setIsAuthenticated(status.isAuthenticated);
      setIsInitialized(status.isInitialized);
      if (status.isAuthenticated) {
        loadAppData();
      }
    } catch {
      setIsAuthenticated(false);
    }
  }, []);

  useEffect(() => {
    checkAuth();

    // Listen to unauthorized signals
    const handleUnauthorized = () => {
      setIsAuthenticated(false);
    };
    window.addEventListener('private-cloud:unauthorized', handleUnauthorized);
    return () => window.removeEventListener('private-cloud:unauthorized', handleUnauthorized);
  }, [checkAuth]);

  // Load cloud data once authenticated
  const loadAppData = async () => {
    try {
      const [status, stats, recent] = await Promise.allSettled([
        api.google.getStatus(),
        api.drive.getStats(),
        api.recent.getAll(10),
      ]);

      if (status.status === 'fulfilled') setDriveStatus(status.value);
      if (stats.status === 'fulfilled') setCounts(stats.value.counts);
      if (recent.status === 'fulfilled') setRecentFiles(recent.value.recent);
    } catch (err) {
      console.error('Failed to load application data:', err);
    }
  };

  const handleLogout = async () => {
    try {
      await api.auth.logout();
    } catch {}
    setIsAuthenticated(false);
    setCurrentTab('home');
  };

  // Open file in appropriate viewer
  const handleOpenFile = (file: DriveFileItem) => {
    // Record in recent
    api.recent.record(file).then(() => {
      setRecentFiles((prev) => [file, ...prev.filter((f) => f.id !== file.id)].slice(0, 10));
    });

    if (file.mimeType.startsWith('image/')) {
      setLightbox({
        isOpen: true,
        photos: [file],
        currentIndex: 0,
      });
    } else if (file.mimeType.startsWith('video/')) {
      setVideoModal({
        isOpen: true,
        video: file,
      });
    } else {
      setPreviewModal({
        isOpen: true,
        file,
      });
    }
  };

  const handleToggleFavorite = async (file: DriveFileItem) => {
    try {
      const res = await api.favorites.toggle(file);
      file.isFavorite = res.isFavorite;
    } catch (err) {
      console.error('Error toggling favorite:', err);
    }
  };

  const handleDownload = (file: DriveFileItem) => {
    const link = document.createElement('a');
    link.href = api.drive.getDownloadUrl(file.id);
    link.setAttribute('download', file.name);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  // Handle global search input
  const handleSearchSubmit = (q: string) => {
    setActiveSearchQuery(q);
    setCurrentTab('search');
  };

  // Loading splash while checking session
  if (isAuthenticated === null) {
    return (
      <div className="min-h-screen w-full flex flex-col items-center justify-center bg-slate-950 text-white select-none">
        <div className="w-12 h-12 rounded-2xl bg-gradient-to-tr from-blue-600 to-indigo-600 flex items-center justify-center shadow-xl shadow-blue-500/20 mb-4 animate-pulse">
          <svg className="w-6 h-6 animate-spin" viewBox="0 0 24 24" fill="none">
            <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" />
            <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z" />
          </svg>
        </div>
        <span className="text-xs uppercase tracking-widest text-slate-400 font-mono">
          Private Cloud
        </span>
      </div>
    );
  }

  // Not logged in -> Show password screen
  if (!isAuthenticated) {
    return (
      <LoginPage
        isInitialized={isInitialized}
        onInitialized={() => setIsInitialized(true)}
        onSuccess={() => {
          setIsAuthenticated(true);
          loadAppData();
        }}
      />
    );
  }

  return (
    <div className="min-h-screen flex flex-col bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-slate-100 transition-colors">
      {/* Top Header */}
      <Navbar
        currentTab={currentTab}
        onTabChange={(tab) => {
          setCurrentTab(tab);
          if (tab !== 'search') setSearchQuery('');
        }}
        searchQuery={searchQuery}
        onSearchChange={setSearchQuery}
        onSearchSubmit={handleSearchSubmit}
        theme={theme}
        onToggleTheme={toggleTheme}
        onLogout={handleLogout}
        driveStatus={driveStatus}
        onRefreshDrive={loadAppData}
        onOpenDisconnectDrive={() => setIsGlobalDisconnectModalOpen(true)}
      />

      <div className="flex-1 flex overflow-hidden">
        {/* Desktop Sidebar */}
        <Sidebar
          currentTab={currentTab}
          onTabChange={setCurrentTab}
          counts={counts}
          onLogout={handleLogout}
          driveConnected={!!driveStatus?.connected}
        />

        {/* Main Content Area */}
        <main className="flex-1 overflow-y-auto p-4 sm:p-6 lg:p-8 pb-24 md:pb-8">
          <div className="max-w-7xl mx-auto">
            {currentTab === 'home' && (
              <DashboardPage
                counts={counts}
                recentFiles={recentFiles}
                driveStatus={driveStatus}
                onTabChange={setCurrentTab}
                onOpenFile={handleOpenFile}
                onToggleFavorite={handleToggleFavorite}
                onDownload={handleDownload}
                onOpenDisconnectDrive={() => setIsGlobalDisconnectModalOpen(true)}
              />
            )}

            {currentTab === 'photos' && (
              <PhotosPage
                onOpenLightbox={(photos, index) =>
                  setLightbox({ isOpen: true, photos, currentIndex: index })
                }
                onToggleFavorite={handleToggleFavorite}
                onDownload={handleDownload}
              />
            )}

            {currentTab === 'videos' && (
              <VideosPage
                onPlayVideo={(video) => setVideoModal({ isOpen: true, video })}
                onToggleFavorite={handleToggleFavorite}
                onDownload={handleDownload}
              />
            )}

            {currentTab === 'documents' && (
              <DocumentsPage
                onOpenFile={handleOpenFile}
                onToggleFavorite={handleToggleFavorite}
                onDownload={handleDownload}
              />
            )}

            {currentTab === 'files' && (
              <FileManagerPage
                onOpenFile={handleOpenFile}
                onToggleFavorite={handleToggleFavorite}
                onDownload={handleDownload}
              />
            )}

            {currentTab === 'search' && (
              <SearchPage
                initialQuery={activeSearchQuery || searchQuery}
                onOpenFile={handleOpenFile}
                onToggleFavorite={handleToggleFavorite}
                onDownload={handleDownload}
              />
            )}

            {currentTab === 'favorites' && (
              <FavoritesPage
                onOpenFile={handleOpenFile}
                onToggleFavorite={handleToggleFavorite}
                onDownload={handleDownload}
              />
            )}

            {currentTab === 'recent' && (
              <RecentPage
                onOpenFile={handleOpenFile}
                onToggleFavorite={handleToggleFavorite}
                onDownload={handleDownload}
              />
            )}

            {currentTab === 'settings' && (
              <SettingsPage
                driveStatus={driveStatus}
                onRefreshDriveStatus={loadAppData}
                onLogout={handleLogout}
                theme={theme}
                onToggleTheme={toggleTheme}
              />
            )}
          </div>
        </main>
      </div>

      {/* Mobile Bottom Navigation */}
      <MobileNav
        currentTab={currentTab}
        onTabChange={setCurrentTab}
        theme={theme}
        onToggleTheme={toggleTheme}
        onLogout={handleLogout}
        driveConnected={!!driveStatus?.connected}
        onOpenDisconnectDrive={() => setIsGlobalDisconnectModalOpen(true)}
      />

      {/* Lightbox Modal for Photos */}
      <PhotoLightbox
        isOpen={lightbox.isOpen}
        photos={lightbox.photos}
        currentIndex={lightbox.currentIndex}
        onClose={() => setLightbox((prev) => ({ ...prev, isOpen: false }))}
        onNavigate={(newIdx) => setLightbox((prev) => ({ ...prev, currentIndex: newIdx }))}
        onToggleFavorite={handleToggleFavorite}
        onDownload={handleDownload}
      />

      {/* Video Player Modal */}
      <VideoPlayerModal
        isOpen={videoModal.isOpen}
        video={videoModal.video}
        onClose={() => setVideoModal({ isOpen: false, video: null })}
        onToggleFavorite={handleToggleFavorite}
        onDownload={handleDownload}
      />

      {/* File Preview Modal */}
      <FilePreviewModal
        isOpen={previewModal.isOpen}
        file={previewModal.file}
        onClose={() => setPreviewModal({ isOpen: false, file: null })}
        onToggleFavorite={handleToggleFavorite}
        onDownload={handleDownload}
      />

      {/* Disconnect Google Drive Modal */}
      <DisconnectDriveModal
        isOpen={isGlobalDisconnectModalOpen}
        onClose={() => setIsGlobalDisconnectModalOpen(false)}
        onDisconnected={loadAppData}
        accountEmail={driveStatus?.email}
      />
    </div>
  );
}
