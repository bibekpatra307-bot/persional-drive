import { initializeApp, getApps } from 'firebase/app';
import { getAuth, signInWithPopup, GoogleAuthProvider, signOut } from 'firebase/auth';
import firebaseConfig from '../../firebase-applet-config.json';

const app = getApps().length === 0 ? initializeApp(firebaseConfig) : getApps()[0];
const auth = getAuth(app);

const provider = new GoogleAuthProvider();
provider.addScope('https://www.googleapis.com/auth/drive.readonly');
provider.setCustomParameters({
  prompt: 'consent',
  access_type: 'offline',
});

/**
 * Initiates official Google OAuth 2.0 flow for website administrator
 */
export async function authorizeAdminGoogleDrive(): Promise<{
  accessToken: string;
  email: string | null;
  displayName: string | null;
}> {
  try {
    const result = await signInWithPopup(auth, provider);
    const credential = GoogleAuthProvider.credentialFromResult(result);

    if (!credential?.accessToken) {
      throw new Error('Google OAuth did not return an access token. Please check permissions.');
    }

    return {
      accessToken: credential.accessToken,
      email: result.user.email,
      displayName: result.user.displayName,
    };
  } catch (error: any) {
    console.error('Google Drive OAuth sign-in error:', error);
    throw error;
  }
}

export async function disconnectAdminGoogleAuth(): Promise<void> {
  await signOut(auth).catch(() => {});
}
