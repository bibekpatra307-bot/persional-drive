import { DriveFileItem, DriveFolderItem, DriveStatus, CategoryCounts, SessionInfo, AuditLog } from '../types';

const AUTH_TOKEN_KEY = 'pc_auth_token';

export function getStoredToken(): string | null {
  if (typeof window === 'undefined') return null;
  return localStorage.getItem(AUTH_TOKEN_KEY);
}

export function setStoredToken(token: string) {
  if (typeof window === 'undefined') return;
  localStorage.setItem(AUTH_TOKEN_KEY, token);
}

export function removeStoredToken() {
  if (typeof window === 'undefined') return;
  localStorage.removeItem(AUTH_TOKEN_KEY);
}

async function request<T>(endpoint: string, options: RequestInit = {}): Promise<T> {
  const token = getStoredToken();
  const headers: Record<string, string> = {
    'Content-Type': 'application/json',
    ...(options.headers as Record<string, string>),
  };

  if (token) {
    headers['Authorization'] = `Bearer ${token}`;
  }

  const res = await fetch(endpoint, {
    ...options,
    credentials: 'include',
    headers,
  });

  if (res.status === 401) {
    // Only dispatch unauthorized if not on the login/setup endpoint itself
    if (!endpoint.includes('/api/auth/login') && !endpoint.includes('/api/auth/setup') && !endpoint.includes('/api/auth/status')) {
      removeStoredToken();
      window.dispatchEvent(new CustomEvent('private-cloud:unauthorized'));
    }
  }

  const data = await res.json().catch(() => ({}));
  if (!res.ok) {
    throw new Error(data.error || `Request failed with status ${res.status}`);
  }
  return data as T;
}

export const api = {
  // Authentication
  auth: {
    getStatus: () => request<{ isAuthenticated: boolean; isInitialized: boolean }>('/api/auth/status'),
    setup: async (password: string) => {
      const data = await request<{ success: boolean; token?: string; message: string }>('/api/auth/setup', {
        method: 'POST',
        body: JSON.stringify({ password }),
      });
      if (data.token) {
        setStoredToken(data.token);
      }
      return data;
    },
    login: async (password: string) => {
      const data = await request<{ success: boolean; token?: string }>('/api/auth/login', {
        method: 'POST',
        body: JSON.stringify({ password }),
      });
      if (data.token) {
        setStoredToken(data.token);
      }
      return data;
    },
    logout: async () => {
      try {
        await request<{ success: boolean }>('/api/auth/logout', {
          method: 'POST',
        });
      } finally {
        removeStoredToken();
      }
      return { success: true };
    },
    getSession: () => request<{ valid: boolean; session: any }>('/api/auth/session'),
  },

  // Google Drive Admin Connection
  google: {
    getStatus: () => request<DriveStatus>('/api/google/status'),
    connect: (accessToken: string, refreshToken?: string, expiresIn?: number) =>
      request<{ success: boolean; message: string; email: string }>('/api/google/connect', {
        method: 'POST',
        body: JSON.stringify({ accessToken, refreshToken, expiresIn }),
      }),
    disconnect: () =>
      request<{ success: boolean }>('/api/google/disconnect', {
        method: 'POST',
      }),
    getFolders: (parentId?: string) =>
      request<{ folders: (DriveFolderItem & { isSelected: boolean })[]; selectedFolders: any[] }>(
        `/api/drive/folders${parentId ? `?parentId=${parentId}` : ''}`
      ),
    selectFolders: (folders: { folder_id: string; folder_name: string }[]) =>
      request<{ success: boolean; message: string }>('/api/drive/folders/select', {
        method: 'POST',
        body: JSON.stringify({ folders }),
      }),
  },

  // Drive Content
  drive: {
    getStats: () =>
      request<{ counts: CategoryCounts; storageQuota?: { limit?: string; usage?: string; usageInDrive?: string } }>(
        '/api/drive/stats'
      ),
    listFiles: (params: {
      category?: string;
      folderId?: string;
      pageSize?: number;
      pageToken?: string;
      sortBy?: string;
      sortOrder?: string;
    }) => {
      const searchParams = new URLSearchParams();
      if (params.category) searchParams.set('category', params.category);
      if (params.folderId) searchParams.set('folderId', params.folderId);
      if (params.pageSize) searchParams.set('pageSize', String(params.pageSize));
      if (params.pageToken) searchParams.set('pageToken', params.pageToken);
      if (params.sortBy) searchParams.set('sortBy', params.sortBy);
      if (params.sortOrder) searchParams.set('sortOrder', params.sortOrder);
      return request<{ files: DriveFileItem[]; nextPageToken?: string }>(`/api/drive/files?${searchParams.toString()}`);
    },
    searchFiles: (params: { q: string; category?: string; pageToken?: string; pageSize?: number }) => {
      const searchParams = new URLSearchParams();
      if (params.q) searchParams.set('q', params.q);
      if (params.category) searchParams.set('category', params.category);
      if (params.pageToken) searchParams.set('pageToken', params.pageToken);
      if (params.pageSize) searchParams.set('pageSize', String(params.pageSize));
      return request<{ files: DriveFileItem[]; nextPageToken?: string }>(`/api/drive/search?${searchParams.toString()}`);
    },
    getFile: (id: string) => request<DriveFileItem>(`/api/drive/file/${id}`),
    getStreamUrl: (id: string) => {
      const token = getStoredToken();
      return `/api/drive/stream/${id}${token ? `?token=${encodeURIComponent(token)}` : ''}`;
    },
    getDownloadUrl: (id: string) => {
      const token = getStoredToken();
      return `/api/drive/download/${id}${token ? `?token=${encodeURIComponent(token)}` : ''}`;
    },
  },

  // Favorites
  favorites: {
    getAll: () => request<{ favorites: DriveFileItem[] }>('/api/favorites'),
    toggle: (file: Partial<DriveFileItem> & { id: string }) =>
      request<{ isFavorite: boolean; message: string }>('/api/favorites', {
        method: 'POST',
        body: JSON.stringify({
          file_id: file.id,
          name: file.name,
          mime_type: file.mimeType,
          thumbnail_link: file.thumbnailLink,
          web_view_link: file.webViewLink,
          size: file.size,
          modified_time: file.modifiedTime,
        }),
      }),
  },

  // Recent
  recent: {
    getAll: (limit = 30) => request<{ recent: DriveFileItem[] }>(`/api/recent?limit=${limit}`),
    record: (file: Partial<DriveFileItem> & { id: string }) =>
      request<{ success: boolean }>('/api/recent', {
        method: 'POST',
        body: JSON.stringify({
          file_id: file.id,
          name: file.name,
          mime_type: file.mimeType,
          thumbnail_link: file.thumbnailLink,
          web_view_link: file.webViewLink,
          size: file.size,
        }),
      }),
  },

  // Settings & Audit
  settings: {
    changePassword: (currentPassword: string, newPassword: string) =>
      request<{ success: boolean; message: string }>('/api/settings/password', {
        method: 'POST',
        body: JSON.stringify({ currentPassword, newPassword }),
      }),
    getSessions: () =>
      request<{ currentSessionId: string; sessions: SessionInfo[] }>('/api/settings/sessions'),
    revokeSession: (sessionId: string) =>
      request<{ success: boolean }>(`/api/settings/sessions/${sessionId}`, {
        method: 'DELETE',
      }),
    getAuditLogs: (limit = 100) => request<{ logs: AuditLog[] }>(`/api/settings/audit?limit=${limit}`),
    getSystemInfo: () =>
      request<{
        database: { type: string; isConnected: boolean; hasPostgresConfigured: boolean };
        environment: Record<string, any>;
      }>('/api/settings/system'),
  },
};
