import React, { useState, useEffect } from 'react';
import { X, Folder, Check, AlertCircle, Loader2 } from 'lucide-react';
import { api } from '../services/api';

interface FolderSelectorModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSaved: () => void;
}

export const FolderSelectorModal: React.FC<FolderSelectorModalProps> = ({
  isOpen,
  onClose,
  onSaved,
}) => {
  const [folders, setFolders] = useState<{ id: string; name: string; isSelected: boolean }[]>([]);
  const [selectedIds, setSelectedIds] = useState<Set<string>>(new Set());
  const [loading, setLoading] = useState(false);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (isOpen) {
      loadFolders();
    }
  }, [isOpen]);

  const loadFolders = async () => {
    setLoading(true);
    setError(null);
    try {
      const data = await api.google.getFolders();
      setFolders(data.folders);
      const initialSelected = new Set(
        data.folders.filter((f) => f.isSelected).map((f) => f.id)
      );
      setSelectedIds(initialSelected);
    } catch (err: any) {
      setError(err.message || 'Unable to load folders from Google Drive');
    } finally {
      setLoading(false);
    }
  };

  const toggleFolder = (id: string) => {
    const next = new Set(selectedIds);
    if (next.has(id)) {
      next.delete(id);
    } else {
      next.add(id);
    }
    setSelectedIds(next);
  };

  const handleSelectAll = () => {
    setSelectedIds(new Set(folders.map((f) => f.id)));
  };

  const handleClearAll = () => {
    setSelectedIds(new Set());
  };

  const handleSave = async () => {
    setSaving(true);
    setError(null);
    try {
      const selectedFolders = folders
        .filter((f) => selectedIds.has(f.id))
        .map((f) => ({ folder_id: f.id, folder_name: f.name }));

      await api.google.selectFolders(selectedFolders);
      onSaved();
      onClose();
    } catch (err: any) {
      setError(err.message || 'Failed to save folder selection');
    } finally {
      setSaving(false);
    }
  };

  if (!isOpen) return null;

  return (
    <div
      className="fixed inset-0 z-50 bg-black/70 flex items-center justify-center backdrop-blur-sm p-4"
      onClick={onClose}
    >
      <div
        onClick={(e) => e.stopPropagation()}
        className="w-full max-w-lg bg-white dark:bg-slate-900 rounded-2xl shadow-2xl border border-slate-200 dark:border-slate-800 overflow-hidden flex flex-col max-h-[85vh]"
      >
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-200 dark:border-slate-800">
          <div className="flex items-center gap-2.5">
            <Folder className="w-5 h-5 text-blue-500" />
            <h3 className="font-bold text-slate-900 dark:text-white text-base">
              Select Visible Folders
            </h3>
          </div>
          <button
            onClick={onClose}
            className="p-1 rounded-lg text-slate-400 hover:text-slate-600 dark:hover:text-slate-200"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Notice */}
        <div className="px-6 py-3 bg-blue-50 dark:bg-blue-950/40 border-b border-blue-100 dark:border-blue-900/60 text-xs text-blue-700 dark:text-blue-300">
          Only files inside the selected folders will be accessible through the private cloud portal. If
          no folders are selected, all files in your drive root remain accessible.
        </div>

        {/* Content list */}
        <div className="flex-1 p-6 overflow-y-auto">
          {loading ? (
            <div className="flex flex-col items-center justify-center py-12 text-slate-400 gap-3">
              <Loader2 className="w-6 h-6 animate-spin text-blue-500" />
              <span className="text-xs">Fetching Google Drive folders...</span>
            </div>
          ) : error ? (
            <div className="flex items-center gap-2 p-3 text-xs rounded-xl bg-rose-50 dark:bg-rose-950/40 text-rose-600 border border-rose-200 dark:border-rose-900">
              <AlertCircle className="w-4 h-4 shrink-0" />
              <span>{error}</span>
            </div>
          ) : folders.length === 0 ? (
            <div className="text-center py-10 text-slate-400 text-xs">
              No top-level folders found in this Google Drive.
            </div>
          ) : (
            <div className="space-y-2">
              <div className="flex items-center justify-between pb-2 text-xs text-slate-500">
                <span>{selectedIds.size} of {folders.length} selected</span>
                <div className="flex gap-3">
                  <button
                    onClick={handleSelectAll}
                    className="text-blue-600 dark:text-blue-400 hover:underline"
                  >
                    Select All
                  </button>
                  <button
                    onClick={handleClearAll}
                    className="text-slate-500 hover:text-slate-800 dark:hover:text-white"
                  >
                    Clear All
                  </button>
                </div>
              </div>

              {folders.map((f) => {
                const isChecked = selectedIds.has(f.id);
                return (
                  <div
                    key={f.id}
                    onClick={() => toggleFolder(f.id)}
                    className={`flex items-center justify-between p-3 rounded-xl border cursor-pointer transition-colors ${
                      isChecked
                        ? 'bg-blue-50/70 dark:bg-blue-950/40 border-blue-300 dark:border-blue-800'
                        : 'bg-white dark:bg-slate-800/40 border-slate-200 dark:border-slate-800 hover:bg-slate-50 dark:hover:bg-slate-800'
                    }`}
                  >
                    <div className="flex items-center gap-3">
                      <Folder
                        className={`w-4 h-4 ${
                          isChecked ? 'text-blue-500 fill-blue-500/20' : 'text-slate-400'
                        }`}
                      />
                      <span className="text-sm font-medium text-slate-800 dark:text-slate-200">
                        {f.name}
                      </span>
                    </div>

                    <div
                      className={`w-5 h-5 rounded-md flex items-center justify-center border transition-colors ${
                        isChecked
                          ? 'bg-blue-600 border-blue-600 text-white'
                          : 'border-slate-300 dark:border-slate-700'
                      }`}
                    >
                      {isChecked && <Check className="w-3.5 h-3.5 stroke-[3]" />}
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="flex items-center justify-end gap-3 px-6 py-4 border-t border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-900/60">
          <button
            onClick={onClose}
            className="px-4 py-2 text-xs font-semibold rounded-xl text-slate-600 dark:text-slate-400 hover:bg-slate-200 dark:hover:bg-slate-800"
          >
            Cancel
          </button>
          <button
            onClick={handleSave}
            disabled={saving || loading}
            className="flex items-center gap-2 px-5 py-2 text-xs font-semibold rounded-xl bg-blue-600 hover:bg-blue-700 text-white shadow-md shadow-blue-500/20 disabled:opacity-50"
          >
            {saving ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : null}
            <span>Save Allowed Folders</span>
          </button>
        </div>
      </div>
    </div>
  );
};
