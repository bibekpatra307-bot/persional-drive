import React from 'react';
import {
  FileText,
  Film,
  Image as ImageIcon,
  Folder,
  FileCode,
  FileSpreadsheet,
  FileArchive,
  Star,
  Download,
  Eye,
  File,
} from 'lucide-react';
import { DriveFileItem } from '../types';

interface FileRowProps {
  file: DriveFileItem;
  onClick: (file: DriveFileItem) => void;
  onToggleFavorite?: (file: DriveFileItem) => void;
  onDownload?: (file: DriveFileItem) => void;
}

export const FileRow: React.FC<FileRowProps> = ({
  file,
  onClick,
  onToggleFavorite,
  onDownload,
}) => {
  const isImage = file.mimeType.startsWith('image/');
  const isVideo = file.mimeType.startsWith('video/');
  const isPdf = file.mimeType.includes('pdf');
  const isSheet = file.mimeType.includes('sheet') || file.mimeType.includes('spreadsheet');
  const isDoc = file.mimeType.includes('document') || file.mimeType.includes('word');
  const isArchive = file.mimeType.includes('zip') || file.mimeType.includes('tar') || file.mimeType.includes('rar');
  const isCode =
    file.mimeType.includes('json') ||
    file.mimeType.includes('javascript') ||
    file.mimeType.includes('typescript') ||
    file.mimeType.includes('html');

  const formatBytes = (bytes?: number) => {
    if (!bytes || bytes === 0) return '--';
    const k = 1024;
    const sizes = ['B', 'KB', 'MB', 'GB', 'TB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(1)) + ' ' + sizes[i];
  };

  const formatDate = (dateStr?: string) => {
    if (!dateStr) return '--';
    try {
      const d = new Date(dateStr);
      return d.toLocaleDateString(undefined, {
        month: 'short',
        day: 'numeric',
        year: 'numeric',
      });
    } catch {
      return '--';
    }
  };

  const getTypeLabel = () => {
    if (file.isFolder) return 'Folder';
    if (isImage) return 'Image';
    if (isVideo) return 'Video';
    if (isPdf) return 'PDF Document';
    if (isSheet) return 'Spreadsheet';
    if (isDoc) return 'Document';
    if (isArchive) return 'Archive';
    if (isCode) return 'Code';
    return 'File';
  };

  const getMimeIcon = () => {
    if (file.isFolder) return <Folder className="w-5 h-5 text-amber-500 fill-amber-500/20" />;
    if (isImage) return <ImageIcon className="w-5 h-5 text-emerald-500" />;
    if (isVideo) return <Film className="w-5 h-5 text-purple-500" />;
    if (isPdf) return <FileText className="w-5 h-5 text-rose-500" />;
    if (isSheet) return <FileSpreadsheet className="w-5 h-5 text-emerald-600" />;
    if (isDoc) return <FileText className="w-5 h-5 text-blue-500" />;
    if (isArchive) return <FileArchive className="w-5 h-5 text-amber-600" />;
    if (isCode) return <FileCode className="w-5 h-5 text-cyan-500" />;
    return <File className="w-5 h-5 text-slate-400" />;
  };

  return (
    <div
      onClick={() => onClick(file)}
      className="group flex items-center justify-between px-4 py-3 border-b transition-colors cursor-pointer bg-white dark:bg-slate-900 border-slate-100 dark:border-slate-800/60 hover:bg-blue-50/50 dark:hover:bg-slate-800/60"
    >
      {/* File Name & Icon */}
      <div className="flex items-center gap-3 min-w-0 flex-1 pr-4">
        <div className="shrink-0">{getMimeIcon()}</div>
        <span
          title={file.name}
          className="text-sm font-medium text-slate-800 dark:text-slate-200 truncate group-hover:text-blue-600 dark:group-hover:text-blue-400"
        >
          {file.name}
        </span>
      </div>

      {/* Type */}
      <div className="hidden md:block w-32 text-xs text-slate-500 dark:text-slate-400 truncate">
        {getTypeLabel()}
      </div>

      {/* Size */}
      <div className="hidden sm:block w-24 text-xs font-mono text-slate-500 dark:text-slate-400 text-right pr-4">
        {formatBytes(file.size)}
      </div>

      {/* Modified Date */}
      <div className="hidden lg:block w-32 text-xs text-slate-500 dark:text-slate-400 text-right pr-4">
        {formatDate(file.modifiedTime)}
      </div>

      {/* Actions */}
      <div className="flex items-center gap-1 shrink-0">
        {onToggleFavorite && !file.isFolder && (
          <button
            onClick={(e) => {
              e.stopPropagation();
              onToggleFavorite(file);
            }}
            title={file.isFavorite ? 'Remove from favorites' : 'Add to favorites'}
            className="p-1.5 rounded-lg text-slate-400 hover:text-amber-500 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
          >
            <Star className={`w-4 h-4 ${file.isFavorite ? 'fill-amber-400 text-amber-500' : ''}`} />
          </button>
        )}

        <button
          onClick={(e) => {
            e.stopPropagation();
            onClick(file);
          }}
          title="View / Open"
          className="p-1.5 rounded-lg text-slate-400 hover:text-blue-500 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
        >
          <Eye className="w-4 h-4" />
        </button>

        {onDownload && !file.isFolder && (
          <button
            onClick={(e) => {
              e.stopPropagation();
              onDownload(file);
            }}
            title="Download file"
            className="p-1.5 rounded-lg text-slate-400 hover:text-blue-500 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
          >
            <Download className="w-4 h-4" />
          </button>
        )}
      </div>
    </div>
  );
};
