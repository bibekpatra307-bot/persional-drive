import React, { useState, useEffect, useCallback } from 'react';
import {
  X,
  ChevronLeft,
  ChevronRight,
  ZoomIn,
  ZoomOut,
  RotateCw,
  Download,
  Calendar,
  HardDrive,
  Maximize2,
  ExternalLink,
  Star,
} from 'lucide-react';
import { DriveFileItem } from '../types';

interface PhotoLightboxProps {
  photos: DriveFileItem[];
  currentIndex: number;
  isOpen: boolean;
  onClose: () => void;
  onNavigate: (index: number) => void;
  onToggleFavorite?: (file: DriveFileItem) => void;
  onDownload: (file: DriveFileItem) => void;
}

export const PhotoLightbox: React.FC<PhotoLightboxProps> = ({
  photos,
  currentIndex,
  isOpen,
  onClose,
  onNavigate,
  onToggleFavorite,
  onDownload,
}) => {
  const [zoom, setZoom] = useState(1);
  const [rotation, setRotation] = useState(0);

  const currentPhoto = photos[currentIndex];

  const handlePrev = useCallback(() => {
    if (currentIndex > 0) {
      setZoom(1);
      setRotation(0);
      onNavigate(currentIndex - 1);
    }
  }, [currentIndex, onNavigate]);

  const handleNext = useCallback(() => {
    if (currentIndex < photos.length - 1) {
      setZoom(1);
      setRotation(0);
      onNavigate(currentIndex + 1);
    }
  }, [currentIndex, photos.length, onNavigate]);

  // Keyboard navigation
  useEffect(() => {
    if (!isOpen) return;

    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') onClose();
      if (e.key === 'ArrowLeft') handlePrev();
      if (e.key === 'ArrowRight') handleNext();
      if (e.key === '+' || e.key === '=') setZoom((z) => Math.min(z + 0.25, 3));
      if (e.key === '-' || e.key === '_') setZoom((z) => Math.max(z - 0.25, 0.5));
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isOpen, onClose, handlePrev, handleNext]);

  // Reset zoom on index change
  useEffect(() => {
    setZoom(1);
    setRotation(0);
  }, [currentIndex]);

  if (!isOpen || !currentPhoto) return null;

  const formatDate = (dateStr?: string) => {
    if (!dateStr) return 'Unknown date';
    try {
      return new Date(dateStr).toLocaleDateString(undefined, {
        month: 'long',
        day: 'numeric',
        year: 'numeric',
      });
    } catch {
      return dateStr;
    }
  };

  const formatBytes = (bytes?: number) => {
    if (!bytes) return '';
    return `${(bytes / (1024 * 1024)).toFixed(2)} MB`;
  };

  // High-res preview image URL: uses Google Drive stream route or high-res thumbnail
  const highResImgUrl = currentPhoto.thumbnailLink
    ? currentPhoto.thumbnailLink.replace(/=s\d+/, '=s2048')
    : `/api/drive/stream/${currentPhoto.id}`;

  return (
    <div className="fixed inset-0 z-50 bg-black/95 flex flex-col justify-between backdrop-blur-md select-none">
      {/* Top Bar */}
      <div className="flex items-center justify-between px-4 sm:px-6 py-4 bg-gradient-to-b from-black/80 to-transparent z-10">
        <div className="flex items-center gap-3 min-w-0">
          <div className="text-white">
            <h3 className="font-semibold text-sm sm:text-base truncate max-w-xs sm:max-w-md">
              {currentPhoto.name}
            </h3>
            <div className="flex items-center gap-3 text-xs text-slate-400 mt-0.5 font-mono">
              <span>
                {currentIndex + 1} of {photos.length}
              </span>
              {currentPhoto.imageMediaMetadata?.width && (
                <span>
                  {currentPhoto.imageMediaMetadata.width} × {currentPhoto.imageMediaMetadata.height}
                </span>
              )}
              {currentPhoto.size && <span>{formatBytes(currentPhoto.size)}</span>}
            </div>
          </div>
        </div>

        {/* Top Controls */}
        <div className="flex items-center gap-2">
          {/* Zoom controls */}
          <div className="hidden sm:flex items-center bg-white/10 rounded-xl p-1 backdrop-blur-md">
            <button
              onClick={() => setZoom((z) => Math.max(z - 0.25, 0.5))}
              className="p-1.5 text-white/80 hover:text-white hover:bg-white/10 rounded-lg transition-colors"
              title="Zoom Out (-)"
            >
              <ZoomOut className="w-4 h-4" />
            </button>
            <span className="text-xs text-white/80 px-2 font-mono">{Math.round(zoom * 100)}%</span>
            <button
              onClick={() => setZoom((z) => Math.min(z + 0.25, 3))}
              className="p-1.5 text-white/80 hover:text-white hover:bg-white/10 rounded-lg transition-colors"
              title="Zoom In (+)"
            >
              <ZoomIn className="w-4 h-4" />
            </button>
          </div>

          <button
            onClick={() => setRotation((r) => (r + 90) % 360)}
            className="p-2 text-white/80 hover:text-white hover:bg-white/10 rounded-xl transition-colors"
            title="Rotate"
          >
            <RotateCw className="w-4 h-4" />
          </button>

          {onToggleFavorite && (
            <button
              onClick={() => onToggleFavorite(currentPhoto)}
              className="p-2 text-white/80 hover:text-amber-400 hover:bg-white/10 rounded-xl transition-colors"
              title="Favorite"
            >
              <Star
                className={`w-4 h-4 ${
                  currentPhoto.isFavorite ? 'fill-amber-400 text-amber-400' : ''
                }`}
              />
            </button>
          )}

          <button
            onClick={() => onDownload(currentPhoto)}
            className="p-2 text-white/80 hover:text-blue-400 hover:bg-white/10 rounded-xl transition-colors"
            title="Download"
          >
            <Download className="w-4 h-4" />
          </button>

          <button
            onClick={onClose}
            className="p-2 text-white/80 hover:text-white hover:bg-white/10 rounded-xl transition-colors ml-2"
            title="Close (Esc)"
          >
            <X className="w-5 h-5" />
          </button>
        </div>
      </div>

      {/* Main Image Area with Previous & Next Arrows */}
      <div className="relative flex-1 flex items-center justify-center overflow-hidden p-4">
        {/* Previous Button */}
        {currentIndex > 0 && (
          <button
            onClick={handlePrev}
            className="absolute left-4 z-20 p-3 rounded-full bg-black/40 text-white/80 hover:text-white hover:bg-black/80 backdrop-blur-md transition-all hover:scale-110"
            title="Previous (Left Arrow)"
          >
            <ChevronLeft className="w-6 h-6" />
          </button>
        )}

        {/* Next Button */}
        {currentIndex < photos.length - 1 && (
          <button
            onClick={handleNext}
            className="absolute right-4 z-20 p-3 rounded-full bg-black/40 text-white/80 hover:text-white hover:bg-black/80 backdrop-blur-md transition-all hover:scale-110"
            title="Next (Right Arrow)"
          >
            <ChevronRight className="w-6 h-6" />
          </button>
        )}

        {/* Display Image */}
        <div
          className="transition-transform duration-150 flex items-center justify-center max-w-full max-h-full"
          style={{
            transform: `scale(${zoom}) rotate(${rotation}deg)`,
            cursor: zoom > 1 ? 'grab' : 'default',
          }}
        >
          <img
            src={highResImgUrl}
            alt={currentPhoto.name}
            className="max-h-[82vh] max-w-[92vw] object-contain rounded-lg shadow-2xl"
          />
        </div>
      </div>

      {/* Bottom Metadata Info Bar */}
      <div className="px-6 py-3 bg-gradient-to-t from-black/80 to-transparent flex items-center justify-between text-xs text-slate-400">
        <div className="flex items-center gap-4">
          <div className="flex items-center gap-1.5">
            <Calendar className="w-3.5 h-3.5 text-blue-400" />
            <span>{formatDate(currentPhoto.modifiedTime)}</span>
          </div>
          <div className="hidden sm:flex items-center gap-1.5">
            <HardDrive className="w-3.5 h-3.5 text-indigo-400" />
            <span>MIME: {currentPhoto.mimeType}</span>
          </div>
        </div>

        <div className="text-[11px] text-slate-500">
          Use ← / → keys to browse • ESC to close • +/- to zoom
        </div>
      </div>
    </div>
  );
};
