import React from 'react';
import {
  FileText,
  Film,
  Image as ImageIcon,
  Folder,
  FileCode,
  FileSpreadsheet,
  FileArchive,
  Star,
  Download,
  Play,
  Eye,
  File,
} from 'lucide-react';
import { DriveFileItem } from '../types';

interface FileCardProps {
  file: DriveFileItem;
  onClick: (file: DriveFileItem) => void;
  onToggleFavorite?: (file: DriveFileItem) => void;
  onDownload?: (file: DriveFileItem) => void;
}

export const FileCard: React.FC<FileCardProps> = ({
  file,
  onClick,
  onToggleFavorite,
  onDownload,
}) => {
  const isImage = file.mimeType.startsWith('image/');
  const isVideo = file.mimeType.startsWith('video/');
  const isPdf = file.mimeType.includes('pdf');
  const isSheet = file.mimeType.includes('sheet') || file.mimeType.includes('spreadsheet');
  const isDoc = file.mimeType.includes('document') || file.mimeType.includes('word');
  const isArchive = file.mimeType.includes('zip') || file.mimeType.includes('tar') || file.mimeType.includes('rar');
  const isCode =
    file.mimeType.includes('json') ||
    file.mimeType.includes('javascript') ||
    file.mimeType.includes('typescript') ||
    file.mimeType.includes('html');

  const formatBytes = (bytes?: number) => {
    if (!bytes || bytes === 0) return '--';
    const k = 1024;
    const sizes = ['B', 'KB', 'MB', 'GB', 'TB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(1)) + ' ' + sizes[i];
  };

  const formatDate = (dateStr?: string) => {
    if (!dateStr) return '';
    try {
      const d = new Date(dateStr);
      return d.toLocaleDateString(undefined, { month: 'short', day: 'numeric', year: 'numeric' });
    } catch {
      return '';
    }
  };

  const getMimeIcon = () => {
    if (file.isFolder) return <Folder className="w-8 h-8 text-amber-500 fill-amber-500/20" />;
    if (isImage) return <ImageIcon className="w-8 h-8 text-emerald-500" />;
    if (isVideo) return <Film className="w-8 h-8 text-purple-500" />;
    if (isPdf) return <FileText className="w-8 h-8 text-rose-500" />;
    if (isSheet) return <FileSpreadsheet className="w-8 h-8 text-emerald-600" />;
    if (isDoc) return <FileText className="w-8 h-8 text-blue-500" />;
    if (isArchive) return <FileArchive className="w-8 h-8 text-amber-600" />;
    if (isCode) return <FileCode className="w-8 h-8 text-cyan-500" />;
    return <File className="w-8 h-8 text-slate-400" />;
  };

  return (
    <div
      onClick={() => onClick(file)}
      className="group relative flex flex-col rounded-2xl border transition-all duration-200 cursor-pointer overflow-hidden bg-white dark:bg-slate-900 border-slate-200/80 dark:border-slate-800/80 hover:border-blue-500/50 hover:shadow-xl hover:shadow-blue-500/5 hover:-translate-y-0.5"
    >
      {/* Top Media / Thumbnail Area */}
      <div className="relative aspect-video w-full bg-slate-100 dark:bg-slate-800/70 flex items-center justify-center overflow-hidden">
        {isImage && file.thumbnailLink ? (
          <img
            src={file.thumbnailLink.replace(/=s\d+/, '=s400')}
            alt={file.name}
            loading="lazy"
            className="w-full h-full object-cover transition-transform duration-300 group-hover:scale-105"
            onError={(e) => {
              // fallback to icon
              (e.target as HTMLElement).style.display = 'none';
            }}
          />
        ) : isVideo && file.thumbnailLink ? (
          <div className="relative w-full h-full">
            <img
              src={file.thumbnailLink.replace(/=s\d+/, '=s400')}
              alt={file.name}
              loading="lazy"
              className="w-full h-full object-cover"
            />
            <div className="absolute inset-0 bg-black/30 flex items-center justify-center group-hover:bg-black/40 transition-colors">
              <div className="w-10 h-10 rounded-full bg-white/90 text-slate-900 flex items-center justify-center shadow-lg group-hover:scale-110 transition-transform">
                <Play className="w-5 h-5 ml-0.5 fill-current" />
              </div>
            </div>
            {file.videoMediaMetadata?.durationMillis && (
              <span className="absolute bottom-2 right-2 px-1.5 py-0.5 rounded text-[10px] font-mono font-medium bg-black/75 text-white backdrop-blur-xs">
                {Math.floor(parseInt(file.videoMediaMetadata.durationMillis, 10) / 1000 / 60)}:
                {String(Math.floor((parseInt(file.videoMediaMetadata.durationMillis, 10) / 1000) % 60)).padStart(2, '0')}
              </span>
            )}
          </div>
        ) : (
          <div className="flex flex-col items-center justify-center p-6 text-center">
            {getMimeIcon()}
            <span className="mt-2 text-[11px] font-semibold text-slate-400 uppercase tracking-wider">
              {file.isFolder ? 'Folder' : file.name.split('.').pop() || 'File'}
            </span>
          </div>
        )}

        {/* Hover Action Overlay */}
        <div className="absolute top-2 right-2 flex items-center gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
          {onToggleFavorite && !file.isFolder && (
            <button
              onClick={(e) => {
                e.stopPropagation();
                onToggleFavorite(file);
              }}
              title={file.isFavorite ? 'Remove from favorites' : 'Add to favorites'}
              className="p-1.5 rounded-lg bg-white/90 dark:bg-slate-800/90 text-slate-700 dark:text-slate-200 hover:text-amber-500 shadow-md backdrop-blur-sm transition-colors"
            >
              <Star
                className={`w-3.5 h-3.5 ${
                  file.isFavorite ? 'fill-amber-400 text-amber-500' : ''
                }`}
              />
            </button>
          )}

          {onDownload && !file.isFolder && (
            <button
              onClick={(e) => {
                e.stopPropagation();
                onDownload(file);
              }}
              title="Download file"
              className="p-1.5 rounded-lg bg-white/90 dark:bg-slate-800/90 text-slate-700 dark:text-slate-200 hover:text-blue-500 shadow-md backdrop-blur-sm transition-colors"
            >
              <Download className="w-3.5 h-3.5" />
            </button>
          )}
        </div>
      </div>

      {/* Card Info Area */}
      <div className="p-3 flex flex-col flex-1 justify-between">
        <h4
          title={file.name}
          className="text-xs sm:text-sm font-semibold text-slate-900 dark:text-white line-clamp-1 mb-1 group-hover:text-blue-600 dark:group-hover:text-blue-400 transition-colors"
        >
          {file.name}
        </h4>

        <div className="flex items-center justify-between text-[11px] text-slate-500 dark:text-slate-400">
          <span>{formatDate(file.modifiedTime)}</span>
          {!file.isFolder && <span className="font-mono">{formatBytes(file.size)}</span>}
        </div>
      </div>
    </div>
  );
};
