import React, { useState, useEffect } from 'react';
import {
  X,
  Download,
  FileText,
  Star,
  ExternalLink,
  Music,
  Code,
  AlertCircle,
} from 'lucide-react';
import { DriveFileItem } from '../types';

interface FilePreviewModalProps {
  file: DriveFileItem | null;
  isOpen: boolean;
  onClose: () => void;
  onToggleFavorite?: (file: DriveFileItem) => void;
  onDownload: (file: DriveFileItem) => void;
}

export const FilePreviewModal: React.FC<FilePreviewModalProps> = ({
  file,
  isOpen,
  onClose,
  onToggleFavorite,
  onDownload,
}) => {
  const [textContent, setTextContent] = useState<string | null>(null);
  const [loadingText, setLoadingText] = useState(false);

  const isPdf = file?.mimeType.includes('pdf');
  const isAudio = file?.mimeType.startsWith('audio/');
  const isText =
    file?.mimeType.startsWith('text/') ||
    file?.mimeType.includes('json') ||
    file?.mimeType.includes('javascript') ||
    file?.mimeType.includes('typescript') ||
    file?.mimeType.includes('markdown');

  // Load text file content if text type
  useEffect(() => {
    if (isOpen && file && isText) {
      setLoadingText(true);
      fetch(`/api/drive/stream/${file.id}`)
        .then((res) => res.text())
        .then((t) => {
          setTextContent(t);
          setLoadingText(false);
        })
        .catch(() => {
          setTextContent('Failed to load text preview');
          setLoadingText(false);
        });
    } else {
      setTextContent(null);
    }
  }, [isOpen, file, isText]);

  // Handle ESC
  useEffect(() => {
    if (!isOpen) return;
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') onClose();
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isOpen, onClose]);

  if (!isOpen || !file) return null;

  const streamUrl = `/api/drive/stream/${file.id}`;

  const formatBytes = (bytes?: number) => {
    if (!bytes) return '--';
    const k = 1024;
    const sizes = ['B', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return `${(bytes / Math.pow(k, i)).toFixed(1)} ${sizes[i]}`;
  };

  return (
    <div
      className="fixed inset-0 z-50 bg-black/80 flex items-center justify-center backdrop-blur-md p-3 sm:p-6"
      onClick={onClose}
    >
      <div
        onClick={(e) => e.stopPropagation()}
        className="relative w-full max-w-4xl bg-white dark:bg-slate-900 rounded-2xl overflow-hidden shadow-2xl border border-slate-200 dark:border-slate-800 flex flex-col h-[85vh]"
      >
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-900/60">
          <div className="flex items-center gap-3 min-w-0">
            <div className="p-2 rounded-xl bg-blue-50 dark:bg-blue-950/60 text-blue-600 dark:text-blue-400">
              {isPdf ? (
                <FileText className="w-5 h-5 text-rose-500" />
              ) : isAudio ? (
                <Music className="w-5 h-5 text-amber-500" />
              ) : isText ? (
                <Code className="w-5 h-5 text-blue-500" />
              ) : (
                <FileText className="w-5 h-5" />
              )}
            </div>
            <div className="min-w-0">
              <h3 className="font-semibold text-slate-900 dark:text-white truncate max-w-sm sm:max-w-md">
                {file.name}
              </h3>
              <p className="text-xs text-slate-500 font-mono">
                {file.mimeType} • {formatBytes(file.size)}
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            {onToggleFavorite && (
              <button
                onClick={() => onToggleFavorite(file)}
                className="p-2 rounded-xl text-slate-500 hover:text-amber-500 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
                title="Favorite"
              >
                <Star className={`w-4 h-4 ${file.isFavorite ? 'fill-amber-400 text-amber-500' : ''}`} />
              </button>
            )}

            <button
              onClick={() => onDownload(file)}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-blue-600 hover:bg-blue-700 text-white text-xs font-medium shadow-md shadow-blue-500/20 transition-all"
            >
              <Download className="w-3.5 h-3.5" />
              <span>Download</span>
            </button>

            <button
              onClick={onClose}
              className="p-2 rounded-xl text-slate-400 hover:text-slate-700 dark:hover:text-white hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors ml-1"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Content Viewer Body */}
        <div className="flex-1 bg-slate-100 dark:bg-slate-950 p-4 sm:p-6 overflow-auto flex items-center justify-center">
          {isPdf ? (
            <iframe
              src={streamUrl}
              title={file.name}
              className="w-full h-full rounded-xl border border-slate-300 dark:border-slate-800 shadow-sm bg-white"
            />
          ) : isAudio ? (
            <div className="flex flex-col items-center justify-center p-8 bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-xl max-w-md w-full text-center">
              <div className="w-20 h-20 rounded-full bg-gradient-to-tr from-amber-500 to-rose-500 text-white flex items-center justify-center shadow-lg mb-6 animate-pulse">
                <Music className="w-10 h-10" />
              </div>
              <h4 className="font-bold text-lg text-slate-900 dark:text-white mb-2">{file.name}</h4>
              <p className="text-xs text-slate-500 mb-6 font-mono">{formatBytes(file.size)}</p>
              <audio controls src={streamUrl} className="w-full" autoPlay />
            </div>
          ) : isText ? (
            <div className="w-full h-full bg-white dark:bg-slate-900 rounded-xl p-4 overflow-auto border border-slate-200 dark:border-slate-800 font-mono text-xs sm:text-sm text-slate-800 dark:text-slate-200">
              {loadingText ? (
                <div className="flex items-center justify-center h-full text-slate-400">
                  Loading preview...
                </div>
              ) : (
                <pre className="whitespace-pre-wrap">{textContent}</pre>
              )}
            </div>
          ) : (
            <div className="text-center p-8 max-w-sm">
              <div className="w-16 h-16 rounded-2xl bg-blue-50 dark:bg-blue-950 text-blue-600 dark:text-blue-400 mx-auto flex items-center justify-center mb-4">
                <FileText className="w-8 h-8" />
              </div>
              <h4 className="font-semibold text-slate-900 dark:text-white text-base mb-2">
                No direct inline preview
              </h4>
              <p className="text-xs text-slate-500 mb-6 leading-relaxed">
                This file format ({file.mimeType}) can be securely downloaded to your device or opened in
                Google Drive.
              </p>
              <button
                onClick={() => onDownload(file)}
                className="w-full flex items-center justify-center gap-2 py-2.5 px-4 rounded-xl bg-blue-600 hover:bg-blue-700 text-white text-sm font-medium shadow-md shadow-blue-500/20"
              >
                <Download className="w-4 h-4" />
                <span>Download File ({formatBytes(file.size)})</span>
              </button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
