import React, { useState } from 'react';
import { AlertTriangle, HardDrive, Loader2, X } from 'lucide-react';
import { api } from '../services/api';
import { disconnectAdminGoogleAuth } from '../services/googleAuth';

interface DisconnectDriveModalProps {
  isOpen: boolean;
  onClose: () => void;
  onDisconnected: () => void;
  accountEmail?: string;
}

export const DisconnectDriveModal: React.FC<DisconnectDriveModalProps> = ({
  isOpen,
  onClose,
  onDisconnected,
  accountEmail,
}) => {
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  if (!isOpen) return null;

  const handleConfirm = async () => {
    setLoading(true);
    setError(null);
    try {
      // 1. Clear server-side connection and tokens
      await api.google.disconnect();
      // 2. Sign out client-side Google Auth session
      await disconnectAdminGoogleAuth();
      // 3. Notify parent to refresh state
      onDisconnected();
      onClose();
    } catch (err: any) {
      setError(err.message || 'Failed to disconnect Google Drive');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div
      className="fixed inset-0 z-50 bg-black/70 flex items-center justify-center backdrop-blur-sm p-4 animate-in fade-in duration-200"
      onClick={onClose}
    >
      <div
        onClick={(e) => e.stopPropagation()}
        className="w-full max-w-md bg-white dark:bg-slate-900 rounded-3xl shadow-2xl border border-slate-200 dark:border-slate-800 overflow-hidden p-6 sm:p-7 space-y-5"
      >
        <div className="flex items-start justify-between">
          <div className="w-12 h-12 rounded-2xl bg-rose-50 dark:bg-rose-950/60 text-rose-600 dark:text-rose-400 flex items-center justify-center shrink-0">
            <AlertTriangle className="w-6 h-6" />
          </div>
          <button
            onClick={onClose}
            className="p-1 rounded-xl text-slate-400 hover:text-slate-600 dark:hover:text-slate-200"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div>
          <h3 className="text-lg font-bold text-slate-900 dark:text-white">
            Disconnect Google Drive?
          </h3>
          <p className="text-xs text-slate-500 dark:text-slate-400 mt-2 leading-relaxed">
            Are you sure you want to disconnect{' '}
            <strong className="text-slate-700 dark:text-slate-200 font-semibold">
              {accountEmail || 'your Google account'}
            </strong>{' '}
            from this private cloud?
          </p>
          <p className="text-xs text-slate-500 dark:text-slate-400 mt-1 leading-relaxed">
            All stored access tokens will be deleted immediately from the server. You can reconnect
            anytime in Settings.
          </p>
        </div>

        {error && (
          <div className="p-3 rounded-xl bg-rose-50 dark:bg-rose-950/40 border border-rose-200 dark:border-rose-900 text-rose-600 text-xs font-medium">
            {error}
          </div>
        )}

        <div className="flex items-center justify-end gap-3 pt-2">
          <button
            onClick={onClose}
            disabled={loading}
            className="px-4 py-2.5 rounded-xl text-xs font-semibold text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
          >
            Cancel
          </button>
          <button
            onClick={handleConfirm}
            disabled={loading}
            className="flex items-center gap-2 px-5 py-2.5 rounded-xl bg-rose-600 hover:bg-rose-700 text-white text-xs font-semibold shadow-md shadow-rose-600/20 transition-all disabled:opacity-50"
          >
            {loading ? <Loader2 className="w-4 h-4 animate-spin" /> : <HardDrive className="w-4 h-4" />}
            <span>Yes, Disconnect Drive</span>
          </button>
        </div>
      </div>
    </div>
  );
};
