import React from 'react';
import {
  Home,
  Image as ImageIcon,
  Film,
  FileText,
  Folder,
  Star,
  Clock,
  Settings,
  LogOut,
  HardDrive,
  Shield,
} from 'lucide-react';
import { ViewTab, CategoryCounts } from '../types';

interface SidebarProps {
  currentTab: ViewTab;
  onTabChange: (tab: ViewTab) => void;
  counts?: CategoryCounts;
  onLogout: () => void;
  driveConnected: boolean;
}

export const Sidebar: React.FC<SidebarProps> = ({
  currentTab,
  onTabChange,
  counts,
  onLogout,
  driveConnected,
}) => {
  const navItems: {
    id: ViewTab;
    label: string;
    icon: React.ComponentType<{ className?: string }>;
    count?: number;
    badgeColor?: string;
  }[] = [
    { id: 'home', label: 'Home', icon: Home },
    { id: 'photos', label: 'Photos', icon: ImageIcon, count: counts?.photos },
    { id: 'videos', label: 'Videos', icon: Film, count: counts?.videos },
    { id: 'documents', label: 'Documents', icon: FileText, count: counts?.documents },
    { id: 'files', label: 'Files', icon: Folder },
    { id: 'favorites', label: 'Favorites', icon: Star },
    { id: 'recent', label: 'Recent', icon: Clock },
  ];

  return (
    <aside className="hidden md:flex flex-col w-64 border-r transition-colors bg-white/70 dark:bg-slate-900/70 backdrop-blur-sm border-slate-200 dark:border-slate-800 p-4 select-none shrink-0">
      {/* Navigation Group */}
      <div className="flex-1 space-y-1">
        <div className="px-3 pb-2 text-[11px] font-semibold uppercase tracking-wider text-slate-400 dark:text-slate-500">
          Navigation
        </div>

        {navItems.map((item) => {
          const Icon = item.icon;
          const isActive = currentTab === item.id;
          return (
            <button
              key={item.id}
              onClick={() => onTabChange(item.id)}
              className={`w-full flex items-center justify-between px-3 py-2.5 rounded-xl text-sm font-medium transition-all ${
                isActive
                  ? 'bg-blue-600 text-white shadow-md shadow-blue-600/20'
                  : 'text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 hover:text-slate-900 dark:hover:text-white'
              }`}
            >
              <div className="flex items-center gap-3">
                <Icon className={`w-4 h-4 ${isActive ? 'text-white' : 'text-slate-400 dark:text-slate-400'}`} />
                <span>{item.label}</span>
              </div>
              {item.count !== undefined && item.count > 0 && (
                <span
                  className={`text-xs px-2 py-0.5 rounded-full font-mono ${
                    isActive
                      ? 'bg-white/20 text-white'
                      : 'bg-slate-100 dark:bg-slate-800 text-slate-500 dark:text-slate-400'
                  }`}
                >
                  {item.count}
                </span>
              )}
            </button>
          );
        })}

        <div className="pt-6 px-3 pb-2 text-[11px] font-semibold uppercase tracking-wider text-slate-400 dark:text-slate-500">
          Preferences
        </div>

        <button
          onClick={() => onTabChange('settings')}
          className={`w-full flex items-center justify-between px-3 py-2.5 rounded-xl text-sm font-medium transition-all ${
            currentTab === 'settings'
              ? 'bg-blue-600 text-white shadow-md shadow-blue-600/20'
              : 'text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 hover:text-slate-900 dark:hover:text-white'
          }`}
        >
          <div className="flex items-center gap-3">
            <Settings
              className={`w-4 h-4 ${
                currentTab === 'settings' ? 'text-white' : 'text-slate-400 dark:text-slate-400'
              }`}
            />
            <span>Settings</span>
          </div>
          {!driveConnected && (
            <span className="w-2 h-2 rounded-full bg-amber-500" title="Google Drive not connected" />
          )}
        </button>

        <button
          onClick={onLogout}
          className="w-full flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm font-medium text-rose-600 dark:text-rose-400 hover:bg-rose-50 dark:hover:bg-rose-950/40 transition-colors"
        >
          <LogOut className="w-4 h-4" />
          <span>Logout</span>
        </button>
      </div>

      {/* Cloud Security Indicator */}
      <div className="pt-4 border-t border-slate-200 dark:border-slate-800">
        <div className="p-3 rounded-xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200/70 dark:border-slate-700/60">
          <div className="flex items-center gap-2 text-xs font-semibold text-slate-700 dark:text-slate-200 mb-1">
            <Shield className="w-3.5 h-3.5 text-blue-500" />
            <span>Private Security</span>
          </div>
          <p className="text-[11px] leading-relaxed text-slate-500 dark:text-slate-400">
            End-to-end server proxy. Google tokens and files are never publicly exposed.
          </p>
        </div>
      </div>
    </aside>
  );
};
