import React, { useState } from 'react';
import {
  Cloud,
  Search,
  Sun,
  Moon,
  LogOut,
  HardDrive,
  ShieldCheck,
  RefreshCw,
  Folder,
  Trash2,
  ChevronDown,
  X,
} from 'lucide-react';
import { DriveStatus, ViewTab } from '../types';

interface NavbarProps {
  currentTab: ViewTab;
  onTabChange: (tab: ViewTab) => void;
  searchQuery: string;
  onSearchChange: (q: string) => void;
  onSearchSubmit: (q: string) => void;
  theme: 'dark' | 'light';
  onToggleTheme: () => void;
  onLogout: () => void;
  driveStatus: DriveStatus | null;
  onRefreshDrive?: () => void;
  onOpenDisconnectDrive?: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({
  currentTab,
  onTabChange,
  searchQuery,
  onSearchChange,
  onSearchSubmit,
  theme,
  onToggleTheme,
  onLogout,
  driveStatus,
  onRefreshDrive,
  onOpenDisconnectDrive,
}) => {
  const [driveMenuOpen, setDriveMenuOpen] = useState(false);

  const handleKeyDown = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === 'Enter') {
      onSearchSubmit(searchQuery);
    }
  };

  const formatBytes = (bytes?: string | number) => {
    if (!bytes) return '0 MB';
    const b = typeof bytes === 'string' ? parseInt(bytes, 10) : bytes;
    if (isNaN(b) || b <= 0) return '0 MB';
    const gb = b / (1024 * 1024 * 1024);
    if (gb >= 1) return `${gb.toFixed(1)} GB`;
    return `${(b / (1024 * 1024)).toFixed(0)} MB`;
  };

  return (
    <header className="sticky top-0 z-30 h-16 border-b transition-colors bg-white/80 dark:bg-slate-900/80 backdrop-blur-md border-slate-200 dark:border-slate-800">
      <div className="flex items-center justify-between h-full px-4 sm:px-6">
        {/* Left: Brand / Title */}
        <div className="flex items-center gap-3">
          <button
            onClick={() => onTabChange('home')}
            className="flex items-center gap-2.5 text-left group focus:outline-none"
          >
            <div className="flex items-center justify-center w-10 h-10 rounded-xl bg-gradient-to-tr from-blue-600 to-indigo-500 text-white shadow-lg shadow-blue-500/20 group-hover:scale-105 transition-transform">
              <Cloud className="w-5 h-5" />
            </div>
            <div>
              <span className="block font-bold tracking-tight text-base sm:text-lg text-slate-900 dark:text-white leading-tight">
                PRIVATE CLOUD
              </span>
              <span className="hidden sm:inline-block text-[11px] font-medium tracking-wide text-blue-600 dark:text-blue-400 uppercase">
                Secure Personal Storage
              </span>
            </div>
          </button>
        </div>

        {/* Center: Global Search Bar */}
        <div className="flex-1 max-w-xl mx-4 sm:mx-8">
          <div className="relative">
            <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => onSearchChange(e.target.value)}
              onKeyDown={handleKeyDown}
              onFocus={() => {
                if (currentTab !== 'search') {
                  onTabChange('search');
                }
              }}
              placeholder="Search files, photos, videos, documents..."
              className="w-full h-10 pl-10 pr-4 text-sm rounded-xl transition-all border outline-none bg-slate-100/80 dark:bg-slate-800/80 border-slate-200/80 dark:border-slate-700/80 text-slate-900 dark:text-white placeholder-slate-400 focus:border-blue-500 focus:bg-white dark:focus:bg-slate-800 focus:ring-2 focus:ring-blue-500/20"
            />
          </div>
        </div>

        {/* Right: Actions, Drive Status, Theme & User */}
        <div className="flex items-center gap-2 sm:gap-3">
          {/* Drive Status Badge & Quick Menu */}
          {driveStatus?.connected ? (
            <div className="relative">
              <button
                onClick={() => setDriveMenuOpen(!driveMenuOpen)}
                className="hidden sm:flex items-center gap-2 px-3 py-1.5 rounded-full text-xs font-medium cursor-pointer border transition-colors bg-emerald-50 dark:bg-emerald-950/40 text-emerald-700 dark:text-emerald-400 border-emerald-200 dark:border-emerald-800/60 hover:bg-emerald-100 dark:hover:bg-emerald-900/50"
              >
                <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
                <span>Drive Connected</span>
                <ChevronDown className="w-3.5 h-3.5 opacity-70" />
              </button>

              {/* Drive Dropdown Menu */}
              {driveMenuOpen && (
                <>
                  <div
                    className="fixed inset-0 z-40"
                    onClick={() => setDriveMenuOpen(false)}
                  />
                  <div className="absolute right-0 mt-2 w-72 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-xl p-4 z-50 animate-in fade-in zoom-in-95 duration-150 space-y-3">
                    <div className="flex items-start justify-between">
                      <div className="flex items-center gap-2">
                        <HardDrive className="w-4 h-4 text-emerald-500" />
                        <span className="text-xs font-bold text-slate-800 dark:text-slate-100">
                          Google Drive Connected
                        </span>
                      </div>
                      <button
                        onClick={() => setDriveMenuOpen(false)}
                        className="text-slate-400 hover:text-slate-600 dark:hover:text-slate-200"
                      >
                        <X className="w-4 h-4" />
                      </button>
                    </div>

                    <div className="p-3 rounded-xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200/70 dark:border-slate-700/60 text-xs">
                      <span className="text-[10px] uppercase font-bold text-slate-400 block mb-0.5">
                        Account
                      </span>
                      <span className="font-semibold text-slate-800 dark:text-slate-200 truncate block">
                        {driveStatus.email || 'Authorized Account'}
                      </span>
                      {driveStatus.storageQuota?.usage && (
                        <span className="text-[11px] text-slate-500 font-mono mt-1 block">
                          Storage Used: {formatBytes(driveStatus.storageQuota.usage)}
                        </span>
                      )}
                    </div>

                    <div className="space-y-1.5 pt-1">
                      <button
                        onClick={() => {
                          setDriveMenuOpen(false);
                          onTabChange('settings');
                        }}
                        className="w-full flex items-center gap-2 px-3 py-2 text-xs font-semibold rounded-xl text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
                      >
                        <Folder className="w-3.5 h-3.5 text-blue-500" />
                        <span>Manage Visible Folders</span>
                      </button>

                      <button
                        onClick={() => {
                          setDriveMenuOpen(false);
                          if (onOpenDisconnectDrive) {
                            onOpenDisconnectDrive();
                          } else {
                            onTabChange('settings');
                          }
                        }}
                        className="w-full flex items-center gap-2 px-3 py-2 text-xs font-semibold rounded-xl text-rose-600 dark:text-rose-400 hover:bg-rose-50 dark:hover:bg-rose-950/50 transition-colors"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                        <span>Disconnect Google Drive</span>
                      </button>
                    </div>
                  </div>
                </>
              )}
            </div>
          ) : (
            <button
              onClick={() => onTabChange('settings')}
              className="hidden sm:flex items-center gap-1.5 px-3 py-1.5 rounded-full text-xs font-semibold border transition-colors bg-amber-50 dark:bg-amber-950/40 text-amber-700 dark:text-amber-400 border-amber-200 dark:border-amber-800 hover:bg-amber-100"
            >
              <HardDrive className="w-3.5 h-3.5" />
              <span>Connect Drive</span>
            </button>
          )}

          {/* Theme Toggle */}
          <button
            onClick={onToggleTheme}
            aria-label="Toggle Theme"
            className="p-2 rounded-xl text-slate-500 hover:text-slate-900 dark:text-slate-400 dark:hover:text-white hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
          >
            {theme === 'dark' ? <Sun className="w-4 h-4 text-amber-400" /> : <Moon className="w-4 h-4 text-indigo-500" />}
          </button>

          {/* Admin badge */}
          <div className="hidden md:flex items-center gap-1.5 px-2.5 py-1 rounded-lg bg-blue-50 dark:bg-blue-950/50 text-blue-700 dark:text-blue-300 text-xs font-medium border border-blue-200 dark:border-blue-900">
            <ShieldCheck className="w-3.5 h-3.5" />
            <span>Admin</span>
          </div>

          {/* Logout */}
          <button
            onClick={onLogout}
            title="Log Out"
            className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium rounded-xl text-rose-600 dark:text-rose-400 hover:bg-rose-50 dark:hover:bg-rose-950/50 transition-colors"
          >
            <LogOut className="w-4 h-4" />
            <span className="hidden sm:inline">Logout</span>
          </button>
        </div>
      </div>
    </header>
  );
};

