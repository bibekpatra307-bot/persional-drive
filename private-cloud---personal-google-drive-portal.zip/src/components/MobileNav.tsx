import React, { useState } from 'react';
import {
  Home,
  Image as ImageIcon,
  Film,
  Folder,
  Menu,
  X,
  FileText,
  Star,
  Clock,
  Settings,
  LogOut,
  Sun,
  Moon,
} from 'lucide-react';
import { ViewTab } from '../types';

interface MobileNavProps {
  currentTab: ViewTab;
  onTabChange: (tab: ViewTab) => void;
  theme: 'dark' | 'light';
  onToggleTheme: () => void;
  onLogout: () => void;
  driveConnected: boolean;
  onOpenDisconnectDrive?: () => void;
}

export const MobileNav: React.FC<MobileNavProps> = ({
  currentTab,
  onTabChange,
  theme,
  onToggleTheme,
  onLogout,
  driveConnected,
  onOpenDisconnectDrive,
}) => {
  const [drawerOpen, setDrawerOpen] = useState(false);

  const mainTabs: { id: ViewTab; label: string; icon: React.ComponentType<{ className?: string }> }[] = [
    { id: 'home', label: 'Home', icon: Home },
    { id: 'photos', label: 'Photos', icon: ImageIcon },
    { id: 'videos', label: 'Videos', icon: Film },
    { id: 'files', label: 'Files', icon: Folder },
  ];

  const handleSelectTab = (tab: ViewTab) => {
    onTabChange(tab);
    setDrawerOpen(false);
  };

  return (
    <>
      {/* Bottom Bar */}
      <nav className="md:hidden fixed bottom-0 left-0 right-0 z-40 h-16 border-t transition-colors bg-white/95 dark:bg-slate-900/95 backdrop-blur-lg border-slate-200 dark:border-slate-800 px-3 flex items-center justify-around">
        {mainTabs.map((t) => {
          const Icon = t.icon;
          const isActive = currentTab === t.id;
          return (
            <button
              key={t.id}
              onClick={() => handleSelectTab(t.id)}
              className={`flex flex-col items-center justify-center w-14 h-12 rounded-xl transition-colors ${
                isActive
                  ? 'text-blue-600 dark:text-blue-400 font-semibold'
                  : 'text-slate-500 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
              }`}
            >
              <Icon className="w-5 h-5 mb-0.5" />
              <span className="text-[10px] tracking-tight">{t.label}</span>
            </button>
          );
        })}

        {/* More Drawer Button */}
        <button
          onClick={() => setDrawerOpen(true)}
          className={`flex flex-col items-center justify-center w-14 h-12 rounded-xl transition-colors ${
            drawerOpen || ['documents', 'favorites', 'recent', 'settings'].includes(currentTab)
              ? 'text-blue-600 dark:text-blue-400 font-semibold'
              : 'text-slate-500 dark:text-slate-400'
          }`}
        >
          <Menu className="w-5 h-5 mb-0.5" />
          <span className="text-[10px] tracking-tight">More</span>
        </button>
      </nav>

      {/* Drawer Overlay */}
      {drawerOpen && (
        <div
          className="fixed inset-0 z-50 bg-black/60 backdrop-blur-sm transition-opacity md:hidden"
          onClick={() => setDrawerOpen(false)}
        >
          <div
            className="absolute bottom-0 left-0 right-0 bg-white dark:bg-slate-900 rounded-t-3xl border-t border-slate-200 dark:border-slate-800 p-6 shadow-2xl animate-in slide-in-from-bottom duration-200"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex items-center justify-between pb-4 border-b border-slate-200 dark:border-slate-800 mb-4">
              <h3 className="font-bold text-slate-900 dark:text-white text-base">Menu & Navigation</h3>
              <button
                onClick={() => setDrawerOpen(false)}
                className="p-1 rounded-full text-slate-400 hover:text-slate-600 dark:hover:text-slate-200"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="grid grid-cols-2 gap-3 mb-6">
              <button
                onClick={() => handleSelectTab('documents')}
                className={`flex items-center gap-3 p-3 rounded-xl border text-sm font-medium transition-colors ${
                  currentTab === 'documents'
                    ? 'bg-blue-50 dark:bg-blue-950/50 border-blue-300 text-blue-600 dark:text-blue-400'
                    : 'bg-slate-50 dark:bg-slate-800/60 border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-300'
                }`}
              >
                <FileText className="w-4 h-4 text-blue-500" />
                <span>Documents</span>
              </button>

              <button
                onClick={() => handleSelectTab('favorites')}
                className={`flex items-center gap-3 p-3 rounded-xl border text-sm font-medium transition-colors ${
                  currentTab === 'favorites'
                    ? 'bg-amber-50 dark:bg-amber-950/50 border-amber-300 text-amber-600 dark:text-amber-400'
                    : 'bg-slate-50 dark:bg-slate-800/60 border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-300'
                }`}
              >
                <Star className="w-4 h-4 text-amber-500" />
                <span>Favorites</span>
              </button>

              <button
                onClick={() => handleSelectTab('recent')}
                className={`flex items-center gap-3 p-3 rounded-xl border text-sm font-medium transition-colors ${
                  currentTab === 'recent'
                    ? 'bg-purple-50 dark:bg-purple-950/50 border-purple-300 text-purple-600 dark:text-purple-400'
                    : 'bg-slate-50 dark:bg-slate-800/60 border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-300'
                }`}
              >
                <Clock className="w-4 h-4 text-purple-500" />
                <span>Recent</span>
              </button>

              <button
                onClick={() => handleSelectTab('settings')}
                className={`flex items-center justify-between p-3 rounded-xl border text-sm font-medium transition-colors ${
                  currentTab === 'settings'
                    ? 'bg-blue-50 dark:bg-blue-950/50 border-blue-300 text-blue-600 dark:text-blue-400'
                    : 'bg-slate-50 dark:bg-slate-800/60 border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-300'
                }`}
              >
                <div className="flex items-center gap-3">
                  <Settings className="w-4 h-4 text-slate-500" />
                  <span>Settings</span>
                </div>
                {!driveConnected && <span className="w-2 h-2 rounded-full bg-amber-500" />}
              </button>
            </div>

            {driveConnected && onOpenDisconnectDrive && (
              <div className="mb-4">
                <button
                  onClick={() => {
                    setDrawerOpen(false);
                    onOpenDisconnectDrive();
                  }}
                  className="w-full flex items-center justify-center gap-2 p-2.5 rounded-xl border border-rose-200 dark:border-rose-900 bg-rose-50 dark:bg-rose-950/40 text-rose-600 dark:text-rose-400 text-xs font-semibold"
                >
                  <span>Disconnect Google Drive</span>
                </button>
              </div>
            )}

            <div className="flex items-center justify-between pt-3 border-t border-slate-200 dark:border-slate-800">
              <button
                onClick={onToggleTheme}
                className="flex items-center gap-2 text-sm text-slate-600 dark:text-slate-300"
              >
                {theme === 'dark' ? <Sun className="w-4 h-4 text-amber-400" /> : <Moon className="w-4 h-4 text-indigo-500" />}
                <span>{theme === 'dark' ? 'Light Theme' : 'Dark Theme'}</span>
              </button>

              <button
                onClick={() => {
                  setDrawerOpen(false);
                  onLogout();
                }}
                className="flex items-center gap-2 text-sm font-semibold text-rose-600 dark:text-rose-400"
              >
                <LogOut className="w-4 h-4" />
                <span>Logout</span>
              </button>
            </div>
          </div>
        </div>
      )}
    </>
  );
};
