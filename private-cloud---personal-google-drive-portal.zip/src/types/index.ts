export interface DriveFileItem {
  id: string;
  name: string;
  mimeType: string;
  size?: number;
  modifiedTime?: string;
  createdTime?: string;
  thumbnailLink?: string;
  webViewLink?: string;
  webContentLink?: string;
  iconLink?: string;
  parents?: string[];
  isFolder: boolean;
  videoMediaMetadata?: {
    width?: number;
    height?: number;
    durationMillis?: string;
  };
  imageMediaMetadata?: {
    width?: number;
    height?: number;
    rotation?: number;
  };
  isFavorite?: boolean;
}

export interface DriveFolderItem {
  id: string;
  name: string;
  isSelected?: boolean;
}

export interface DriveStatus {
  connected: boolean;
  email?: string;
  connectedAt?: string;
  allowedFolderCount: number;
  allowedFolders: { id: string; name: string }[];
  user?: {
    displayName: string;
    emailAddress: string;
    photoLink?: string;
  };
  storageQuota?: {
    limit?: string;
    usage?: string;
    usageInDrive?: string;
  };
}

export interface CategoryCounts {
  photos: number;
  videos: number;
  documents: number;
  folders: number;
  total: number;
}

export interface SessionInfo {
  id: string;
  ip: string;
  user_agent: string;
  created_at: string;
  expires_at: string;
}

export interface AuditLog {
  id: number;
  event: string;
  ip: string;
  details: string;
  created_at: string;
}

export type ViewTab =
  | 'home'
  | 'photos'
  | 'videos'
  | 'documents'
  | 'files'
  | 'favorites'
  | 'recent'
  | 'search'
  | 'settings';
