import crypto from 'node:crypto';
import type { Request, Response, NextFunction } from 'express';
import { db } from './db.js';

const SESSION_COOKIE_NAME = 'pc_session';
const SESSION_DURATION_DAYS = 7;
const MAX_FAILED_ATTEMPTS = 5;
const LOCKOUT_WINDOW_MS = 15 * 60 * 1000; // 15 minutes

interface FailedAttempt {
  count: number;
  lastAttempt: number;
}

const failedAttemptsMap = new Map<string, FailedAttempt>();

export function hashPassword(password: string, existingSalt?: string): { hash: string; salt: string } {
  const salt = existingSalt || crypto.randomBytes(16).toString('hex');
  const derivedKey = crypto.scryptSync(password, salt, 64);
  return {
    hash: derivedKey.toString('hex'),
    salt,
  };
}

export function verifyPassword(password: string, storedHash: string, storedSalt: string): boolean {
  try {
    const derivedKey = crypto.scryptSync(password, storedSalt, 64);
    const keyBuffer = Buffer.from(derivedKey.toString('hex'), 'hex');
    const storedBuffer = Buffer.from(storedHash, 'hex');
    if (keyBuffer.length !== storedBuffer.length) {
      return false;
    }
    return crypto.timingSafeEqual(keyBuffer, storedBuffer);
  } catch (err) {
    console.error('Password verification error:', err);
    return false;
  }
}

export function checkRateLimit(ip: string): { isLimited: boolean; remainingMinutes?: number } {
  const record = failedAttemptsMap.get(ip);
  if (!record) return { isLimited: false };

  const now = Date.now();
  if (now - record.lastAttempt > LOCKOUT_WINDOW_MS) {
    failedAttemptsMap.delete(ip);
    return { isLimited: false };
  }

  if (record.count >= MAX_FAILED_ATTEMPTS) {
    const remainingMs = LOCKOUT_WINDOW_MS - (now - record.lastAttempt);
    return {
      isLimited: true,
      remainingMinutes: Math.ceil(remainingMs / 60000),
    };
  }

  return { isLimited: false };
}

export function recordFailedAttempt(ip: string) {
  const now = Date.now();
  const record = failedAttemptsMap.get(ip) || { count: 0, lastAttempt: now };
  if (now - record.lastAttempt > LOCKOUT_WINDOW_MS) {
    record.count = 1;
  } else {
    record.count += 1;
  }
  record.lastAttempt = now;
  failedAttemptsMap.set(ip, record);
}

export function clearFailedAttempts(ip: string) {
  failedAttemptsMap.delete(ip);
}

// Master password management
const SETTING_MASTER_PASSWORD = 'master_password_config';

export async function isMasterPasswordInitialized(): Promise<boolean> {
  const cfg = await db.getSetting<{ hash: string; salt: string }>(SETTING_MASTER_PASSWORD);
  if (cfg && cfg.hash) return true;
  // If not set yet, we allow default 'CloudPass2026!'
  return true;
}

export async function setMasterPassword(newPassword: string): Promise<void> {
  const { hash, salt } = hashPassword(newPassword);
  await db.setSetting(SETTING_MASTER_PASSWORD, { hash, salt });
}

export async function validateMasterPassword(password: string): Promise<boolean> {
  const cfg = await db.getSetting<{ hash: string; salt: string }>(SETTING_MASTER_PASSWORD);
  if (cfg && cfg.hash && cfg.salt) {
    return verifyPassword(password, cfg.hash, cfg.salt);
  }

  // Check env fallback or default
  const envPass = process.env.MASTER_PASSWORD || 'CloudPass2026!';
  if (password === envPass) {
    // Automatically initialize database with this hash
    await setMasterPassword(envPass);
    return true;
  }

  return false;
}

// Session management
export async function createSession(ip: string, userAgent: string): Promise<string> {
  const sessionId = crypto.randomBytes(32).toString('hex');
  const now = new Date();
  const expiresAt = new Date(now.getTime() + SESSION_DURATION_DAYS * 24 * 60 * 60 * 1000);

  await db.createSession({
    id: sessionId,
    ip,
    user_agent: userAgent,
    created_at: now.toISOString(),
    expires_at: expiresAt.toISOString(),
  });

  return sessionId;
}

export async function validateSessionToken(token: string): Promise<boolean> {
  if (!token) return false;
  const session = await db.getSession(token);
  if (!session) return false;

  const now = new Date();
  const expires = new Date(session.expires_at);
  if (now > expires) {
    await db.deleteSession(token);
    return false;
  }
  return true;
}

export function getClientIp(req: Request): string {
  const forwarded = req.headers['x-forwarded-for'];
  if (typeof forwarded === 'string') {
    return forwarded.split(',')[0].trim();
  }
  return req.ip || req.socket.remoteAddress || '127.0.0.1';
}

export function setSessionCookie(res: Response, token: string) {
  // Use sameSite: 'none' and secure: true so cookies work inside iframes (e.g. AI Studio preview)
  res.cookie(SESSION_COOKIE_NAME, token, {
    httpOnly: true,
    secure: true,
    sameSite: 'none',
    path: '/',
    maxAge: SESSION_DURATION_DAYS * 24 * 60 * 60 * 1000,
  });
}

export function clearSessionCookie(res: Response) {
  res.clearCookie(SESSION_COOKIE_NAME, {
    httpOnly: true,
    secure: true,
    sameSite: 'none',
    path: '/',
  });
}

// Auth Middleware for Express API routes
export async function requireAuth(req: Request, res: Response, next: NextFunction): Promise<void> {
  // Support Authorization header first (most reliable in iframes), then cookie, then query param
  const authHeader = req.headers['authorization'];
  const tokenFromHeader = authHeader?.startsWith('Bearer ') ? authHeader.slice(7) : null;
  const tokenFromCookie = req.cookies?.[SESSION_COOKIE_NAME];
  const tokenFromQuery = typeof req.query.token === 'string' ? req.query.token : null;
  const token = tokenFromHeader || tokenFromCookie || tokenFromQuery;

  if (!token) {
    res.status(401).json({ error: 'Session expired or not authenticated. Please login again.' });
    return;
  }

  const isValid = await validateSessionToken(token);
  if (!isValid) {
    clearSessionCookie(res);
    res.status(401).json({ error: 'Session expired or invalid. Please login again.' });
    return;
  }

  // Attach session info
  (req as any).sessionId = token;
  next();
}
