import { Router, Request, Response } from 'express';
import { Readable } from 'node:stream';
import {
  requireAuth,
  checkRateLimit,
  recordFailedAttempt,
  clearFailedAttempts,
  validateMasterPassword,
  createSession,
  setSessionCookie,
  clearSessionCookie,
  getClientIp,
  isMasterPasswordInitialized,
  setMasterPassword,
} from './auth.js';
import { db } from './db.js';
import { driveService } from './driveService.js';

export const apiRouter = Router();

// ========================================================
// AUTHENTICATION ROUTES
// ========================================================

/**
 * Check auth status and whether master password setup is needed
 */
apiRouter.get('/auth/status', async (req: Request, res: Response) => {
  const authHeader = req.headers.authorization;
  const tokenFromHeader = authHeader?.startsWith('Bearer ') ? authHeader.slice(7) : null;
  const tokenFromCookie = req.cookies?.pc_session;
  const tokenFromQuery = typeof req.query.token === 'string' ? req.query.token : null;
  const token = tokenFromHeader || tokenFromCookie || tokenFromQuery;

  const isInitialized = await isMasterPasswordInitialized();
  let isAuthenticated = false;

  if (token) {
    const session = await db.getSession(token);
    if (session && new Date(session.expires_at) > new Date()) {
      isAuthenticated = true;
    }
  }

  res.json({
    isAuthenticated,
    isInitialized,
    sessionExpiresInDays: 7,
  });
});

/**
 * Initial setup: Set master password on first launch
 */
apiRouter.post('/auth/setup', async (req: Request, res: Response) => {
  const { password } = req.body;
  if (!password || password.length < 8) {
    res.status(400).json({ error: 'Password must be at least 8 characters long.' });
    return;
  }

  await setMasterPassword(password);
  const ip = getClientIp(req);
  const userAgent = req.headers['user-agent'] || 'Unknown';
  const sessionId = await createSession(ip, userAgent);
  setSessionCookie(res, sessionId);
  await db.logAudit('SETUP_MASTER_PASSWORD', ip, 'Initial master password configured');

  res.json({
    success: true,
    token: sessionId,
    message: 'Private Cloud master password configured successfully.',
  });
});

/**
 * Login with Private Cloud Master Password
 */
apiRouter.post('/auth/login', async (req: Request, res: Response) => {
  const ip = getClientIp(req);
  const rateLimit = checkRateLimit(ip);

  if (rateLimit.isLimited) {
    res.status(429).json({
      error: `Too many failed attempts. Please try again in ${rateLimit.remainingMinutes} minutes.`,
    });
    return;
  }

  const { password } = req.body;
  if (!password) {
    res.status(400).json({ error: 'Password is required' });
    return;
  }

  const isValid = await validateMasterPassword(password);
  if (!isValid) {
    recordFailedAttempt(ip);
    await db.logAudit('FAILED_LOGIN', ip, 'Invalid password attempt');
    res.status(401).json({ error: 'Incorrect password' });
    return;
  }

  // Success
  clearFailedAttempts(ip);
  const userAgent = req.headers['user-agent'] || 'Unknown';
  const sessionId = await createSession(ip, userAgent);
  setSessionCookie(res, sessionId);
  await db.logAudit('SUCCESSFUL_LOGIN', ip, `Session established from ${userAgent.slice(0, 50)}`);

  res.json({
    success: true,
    token: sessionId,
    message: 'Authenticated successfully',
  });
});

/**
 * Logout
 */
apiRouter.post('/auth/logout', requireAuth, async (req: Request, res: Response) => {
  const sessionId = (req as any).sessionId;
  const ip = getClientIp(req);
  if (sessionId) {
    await db.deleteSession(sessionId);
  }
  clearSessionCookie(res);
  await db.logAudit('LOGOUT', ip, 'User logged out');
  res.json({ success: true, message: 'Logged out successfully' });
});

/**
 * Validate current session
 */
apiRouter.get('/auth/session', requireAuth, async (req: Request, res: Response) => {
  const sessionId = (req as any).sessionId;
  const session = await db.getSession(sessionId);
  res.json({
    valid: true,
    session,
  });
});

// ========================================================
// GOOGLE DRIVE CONNECTION (Protected)
// ========================================================

/**
 * Check Google Drive status
 */
apiRouter.get('/google/status', requireAuth, async (_req: Request, res: Response) => {
  try {
    const status = await driveService.getStatus();
    const about = status.connected ? await driveService.getAboutInfo() : null;
    res.json({
      ...status,
      user: about?.user,
      storageQuota: about?.storageQuota,
    });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

/**
 * Save Google Drive Authorization Token (from Admin OAuth flow)
 */
apiRouter.post('/google/connect', requireAuth, async (req: Request, res: Response) => {
  const { accessToken, refreshToken, expiresIn } = req.body;
  if (!accessToken) {
    res.status(400).json({ error: 'Access token is required' });
    return;
  }

  const ip = getClientIp(req);
  try {
    // Verify token with Google tokeninfo
    const verifyRes = await fetch(`https://oauth2.googleapis.com/tokeninfo?access_token=${accessToken}`);
    if (!verifyRes.ok) {
      res.status(400).json({ error: 'Invalid Google OAuth access token' });
      return;
    }

    const tokenInfo = await verifyRes.json();
    const email = tokenInfo.email || 'Authorized Administrator';

    // Store in DB
    const tokenExpiry = expiresIn ? Date.now() + expiresIn * 1000 : Date.now() + 3500 * 1000;
    await db.setDriveConnection({
      email,
      access_token: accessToken,
      refresh_token: refreshToken || undefined,
      token_expiry: tokenExpiry,
      connected_at: new Date().toISOString(),
      is_active: true,
    });

    await db.logAudit('GOOGLE_DRIVE_CONNECTED', ip, `Connected Google Drive for ${email}`);
    res.json({ success: true, message: 'Google Drive connected successfully', email });
  } catch (err: any) {
    console.error('Error connecting Google Drive:', err);
    res.status(500).json({ error: 'Failed to verify Google Drive credentials' });
  }
});

/**
 * Disconnect Google Drive
 */
apiRouter.post('/google/disconnect', requireAuth, async (req: Request, res: Response) => {
  const ip = getClientIp(req);
  await db.clearDriveConnection();
  await db.logAudit('GOOGLE_DRIVE_DISCONNECTED', ip, 'Google Drive was disconnected');
  res.json({ success: true, message: 'Google Drive disconnected' });
});

/**
 * List folders for folder selection modal
 */
apiRouter.get('/drive/folders', requireAuth, async (req: Request, res: Response) => {
  try {
    const parentId = typeof req.query.parentId === 'string' ? req.query.parentId : undefined;
    const folders = await driveService.listAllFolders(parentId);
    const selected = await db.getSelectedFolders();
    const selectedIds = new Set(selected.map((s) => s.folder_id));

    const foldersWithState = folders.map((f) => ({
      ...f,
      isSelected: selectedIds.has(f.id),
    }));

    res.json({ folders: foldersWithState, selectedFolders: selected });
  } catch (err: any) {
    res.status(500).json({ error: err.message || 'Unable to list folders' });
  }
});

/**
 * Save selected folders filter
 */
apiRouter.post('/drive/folders/select', requireAuth, async (req: Request, res: Response) => {
  const { folders } = req.body;
  if (!Array.isArray(folders)) {
    res.status(400).json({ error: 'Folders must be an array' });
    return;
  }

  await db.setSelectedFolders(folders);
  const ip = getClientIp(req);
  await db.logAudit('FOLDERS_FILTER_UPDATED', ip, `Updated allowed folders: ${folders.length} folder(s) selected`);
  res.json({ success: true, message: 'Folder access list updated' });
});

// ========================================================
// DRIVE FILES & MEDIA (Protected)
// ========================================================

/**
 * Dashboard stats
 */
apiRouter.get('/drive/stats', requireAuth, async (_req: Request, res: Response) => {
  try {
    const counts = await driveService.getCategoryCounts();
    const about = await driveService.getAboutInfo();
    res.json({
      counts,
      storageQuota: about?.storageQuota,
    });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

/**
 * List files by category, folder, and pagination
 */
apiRouter.get('/drive/files', requireAuth, async (req: Request, res: Response) => {
  try {
    const category = (req.query.category as any) || 'all';
    const folderId = typeof req.query.folderId === 'string' ? req.query.folderId : undefined;
    const pageSize = req.query.pageSize ? parseInt(String(req.query.pageSize), 10) : 30;
    const pageToken = typeof req.query.pageToken === 'string' ? req.query.pageToken : undefined;
    const sortBy = (req.query.sortBy as any) || 'modifiedTime';
    const sortOrder = (req.query.sortOrder as any) || 'desc';

    const result = await driveService.listFiles({
      category,
      folderId,
      pageSize,
      pageToken,
      sortBy,
      sortOrder,
    });

    res.json(result);
  } catch (err: any) {
    res.status(500).json({ error: err.message || 'Unable to load files' });
  }
});

/**
 * Global Search
 */
apiRouter.get('/drive/search', requireAuth, async (req: Request, res: Response) => {
  try {
    const q = typeof req.query.q === 'string' ? req.query.q : '';
    const category = typeof req.query.category === 'string' ? req.query.category : undefined;
    const pageToken = typeof req.query.pageToken === 'string' ? req.query.pageToken : undefined;
    const pageSize = req.query.pageSize ? parseInt(String(req.query.pageSize), 10) : 30;

    const result = await driveService.searchFiles(q, {
      category,
      pageToken,
      pageSize,
    });

    res.json(result);
  } catch (err: any) {
    res.status(500).json({ error: err.message || 'Search failed' });
  }
});

/**
 * Single file metadata
 */
apiRouter.get('/drive/file/:id', requireAuth, async (req: Request, res: Response) => {
  try {
    const file = await driveService.getFile(req.params.id);
    const isFav = await db.isFavorite(req.params.id);
    res.json({ ...file, isFavorite: isFav });
  } catch (err: any) {
    res.status(404).json({ error: err.message || 'File not found' });
  }
});

/**
 * Stream file with HTTP Range support for video & audio seeking
 */
apiRouter.get('/drive/stream/:id', requireAuth, async (req: Request, res: Response) => {
  try {
    const fileId = req.params.id;
    const rangeHeader = req.headers.range;

    const streamResult = await driveService.streamFileContent(fileId, rangeHeader);

    // Set headers
    Object.entries(streamResult.headers).forEach(([k, v]) => {
      res.setHeader(k, v);
    });

    res.status(streamResult.status);

    if (streamResult.stream) {
      // Convert web ReadableStream to Node Readable
      const nodeStream = Readable.fromWeb(streamResult.stream as any);
      nodeStream.pipe(res);
    } else {
      res.end();
    }
  } catch (err: any) {
    console.error('Streaming error:', err);
    res.status(500).send('Unable to stream file');
  }
});

/**
 * Download file attachment
 */
apiRouter.get('/drive/download/:id', requireAuth, async (req: Request, res: Response) => {
  try {
    const fileId = req.params.id;
    const fileMeta = await driveService.getFile(fileId);
    const streamResult = await driveService.streamFileContent(fileId);

    res.setHeader('Content-Disposition', `attachment; filename="${encodeURIComponent(fileMeta.name)}"`);
    if (fileMeta.mimeType) {
      res.setHeader('Content-Type', fileMeta.mimeType);
    }
    if (fileMeta.size) {
      res.setHeader('Content-Length', String(fileMeta.size));
    }

    if (streamResult.stream) {
      const nodeStream = Readable.fromWeb(streamResult.stream as any);
      nodeStream.pipe(res);
      await db.logAudit('FILE_DOWNLOAD', getClientIp(req), `Downloaded file: ${fileMeta.name}`);
    } else {
      res.status(404).send('File empty or unavailable');
    }
  } catch (err: any) {
    res.status(500).send('Unable to download file');
  }
});

// ========================================================
// FAVORITES (Protected)
// ========================================================

apiRouter.get('/favorites', requireAuth, async (_req: Request, res: Response) => {
  try {
    const favorites = await db.getFavorites();
    res.json({ favorites });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

apiRouter.post('/favorites', requireAuth, async (req: Request, res: Response) => {
  try {
    const { file_id, name, mime_type, thumbnail_link, web_view_link, size, modified_time } = req.body;
    if (!file_id) {
      res.status(400).json({ error: 'file_id is required' });
      return;
    }

    const isFav = await db.isFavorite(file_id);
    if (isFav) {
      await db.removeFavorite(file_id);
      res.json({ isFavorite: false, message: 'Removed from favorites' });
    } else {
      await db.addFavorite({
        file_id,
        name: name || 'Untitled',
        mime_type: mime_type || 'application/octet-stream',
        thumbnail_link,
        web_view_link,
        size: Number(size || 0),
        modified_time,
      });
      res.json({ isFavorite: true, message: 'Added to favorites' });
    }
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

// ========================================================
// RECENT FILES (Protected)
// ========================================================

apiRouter.get('/recent', requireAuth, async (req: Request, res: Response) => {
  try {
    const limit = req.query.limit ? parseInt(String(req.query.limit), 10) : 30;
    const recent = await db.getRecentFiles(limit);
    res.json({ recent });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

apiRouter.post('/recent', requireAuth, async (req: Request, res: Response) => {
  try {
    const { file_id, name, mime_type, thumbnail_link, web_view_link, size } = req.body;
    if (!file_id) {
      res.status(400).json({ error: 'file_id is required' });
      return;
    }

    await db.addRecentFile({
      file_id,
      name: name || 'Untitled',
      mime_type: mime_type || 'application/octet-stream',
      thumbnail_link,
      web_view_link,
      size: Number(size || 0),
    });

    res.json({ success: true });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

// ========================================================
// SETTINGS & AUDIT (Protected)
// ========================================================

/**
 * Change Master Password
 */
apiRouter.post('/settings/password', requireAuth, async (req: Request, res: Response) => {
  const { currentPassword, newPassword } = req.body;
  if (!currentPassword || !newPassword) {
    res.status(400).json({ error: 'Current and new passwords are required' });
    return;
  }
  if (newPassword.length < 8) {
    res.status(400).json({ error: 'New password must be at least 8 characters long' });
    return;
  }

  const isValid = await validateMasterPassword(currentPassword);
  if (!isValid) {
    res.status(401).json({ error: 'Current password is incorrect' });
    return;
  }

  await setMasterPassword(newPassword);
  const ip = getClientIp(req);
  await db.logAudit('PASSWORD_CHANGED', ip, 'Master password changed');
  res.json({ success: true, message: 'Master password updated successfully' });
});

/**
 * Active sessions
 */
apiRouter.get('/settings/sessions', requireAuth, async (req: Request, res: Response) => {
  try {
    const currentSessionId = (req as any).sessionId;
    const sessions = await db.getAllSessions();
    res.json({
      currentSessionId,
      sessions,
    });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

/**
 * Revoke specific session
 */
apiRouter.delete('/settings/sessions/:id', requireAuth, async (req: Request, res: Response) => {
  try {
    const sessionIdToRevoke = req.params.id;
    await db.deleteSession(sessionIdToRevoke);
    const ip = getClientIp(req);
    await db.logAudit('SESSION_REVOKED', ip, `Session ${sessionIdToRevoke.slice(0, 8)} revoked`);
    res.json({ success: true, message: 'Session revoked' });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

/**
 * Audit Logs
 */
apiRouter.get('/settings/audit', requireAuth, async (req: Request, res: Response) => {
  try {
    const limit = req.query.limit ? parseInt(String(req.query.limit), 10) : 100;
    const logs = await db.getAuditLogs(limit);
    res.json({ logs });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

/**
 * Database Status & Info
 */
apiRouter.get('/settings/system', requireAuth, async (_req: Request, res: Response) => {
  res.json({
    database: db.getDbStatus(),
    environment: {
      hasGoogleClientId: !!process.env.GOOGLE_CLIENT_ID,
      hasGoogleClientSecret: !!process.env.GOOGLE_CLIENT_SECRET,
      hasGoogleRefreshToken: !!process.env.GOOGLE_REFRESH_TOKEN,
      hasDatabaseUrl: !!process.env.DATABASE_URL,
      nodeVersion: process.version,
    },
  });
});
