import fs from 'node:fs';
import path from 'node:path';
import pg from 'pg';

export interface SettingsRecord {
  key: string;
  value: any;
  updated_at?: string;
}

export interface SessionRecord {
  id: string;
  ip: string;
  user_agent: string;
  created_at: string;
  expires_at: string;
}

export interface DriveConnectionRecord {
  email: string;
  access_token: string;
  refresh_token?: string;
  token_expiry?: number;
  connected_at: string;
  is_active: boolean;
}

export interface DriveFolderRecord {
  folder_id: string;
  folder_name: string;
  is_selected: boolean;
  created_at?: string;
}

export interface FileMetadataRecord {
  file_id: string;
  name: string;
  mime_type: string;
  thumbnail_link?: string;
  web_view_link?: string;
  size?: number;
  modified_time?: string;
  timestamp?: string; // added_at or opened_at
}

export interface AuditLogRecord {
  id?: number;
  event: string;
  ip: string;
  details: string;
  created_at: string;
}

// In-file store structure for local / non-PG mode
interface LocalDataStore {
  settings: Record<string, any>;
  sessions: Record<string, SessionRecord>;
  drive_connection: DriveConnectionRecord | null;
  drive_folders: Record<string, DriveFolderRecord>;
  favorites: Record<string, FileMetadataRecord>;
  recent_files: Record<string, FileMetadataRecord>;
  audit_logs: AuditLogRecord[];
}

const DATA_DIR = path.resolve(process.cwd(), '.data');
const DATA_FILE = path.join(DATA_DIR, 'private_cloud.json');

class DatabaseService {
  private pgPool: pg.Pool | null = null;
  private isPgAvailable = false;
  private localData: LocalDataStore;

  constructor() {
    this.localData = this.loadLocalStore();
    this.initPostgres();
  }

  private loadLocalStore(): LocalDataStore {
    try {
      if (!fs.existsSync(DATA_DIR)) {
        fs.mkdirSync(DATA_DIR, { recursive: true });
      }
      if (fs.existsSync(DATA_FILE)) {
        const raw = fs.readFileSync(DATA_FILE, 'utf-8');
        return JSON.parse(raw);
      }
    } catch (err) {
      console.error('Error loading local data store, initializing fresh:', err);
    }
    return {
      settings: {},
      sessions: {},
      drive_connection: null,
      drive_folders: {},
      favorites: {},
      recent_files: {},
      audit_logs: [],
    };
  }

  private saveLocalStore() {
    try {
      if (!fs.existsSync(DATA_DIR)) {
        fs.mkdirSync(DATA_DIR, { recursive: true });
      }
      const tmpFile = `${DATA_FILE}.tmp`;
      fs.writeFileSync(tmpFile, JSON.stringify(this.localData, null, 2), 'utf-8');
      fs.renameSync(tmpFile, DATA_FILE);
    } catch (err) {
      console.error('Failed to persist local database store:', err);
    }
  }

  private async initPostgres() {
    const dbUrl = process.env.DATABASE_URL;
    if (dbUrl && !dbUrl.includes('localhost:5432/private_cloud')) {
      try {
        const pool = new pg.Pool({
          connectionString: dbUrl,
          ssl: dbUrl.includes('supabase') || dbUrl.includes('sslmode=require') ? { rejectUnauthorized: false } : undefined,
          connectionTimeoutMillis: 5000,
        });

        const client = await pool.connect();
        this.pgPool = pool;
        this.isPgAvailable = true;
        console.log('✓ Connected to PostgreSQL / Supabase database');
        
        // Auto-run basic table creation if missing
        await client.query(`
          CREATE TABLE IF NOT EXISTS settings (key VARCHAR(64) PRIMARY KEY, value JSONB NOT NULL, updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP);
          CREATE TABLE IF NOT EXISTS sessions (id VARCHAR(128) PRIMARY KEY, ip VARCHAR(64), user_agent TEXT, created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP, expires_at TIMESTAMP WITH TIME ZONE NOT NULL);
          CREATE TABLE IF NOT EXISTS drive_connections (id SERIAL PRIMARY KEY, email VARCHAR(255) NOT NULL, access_token TEXT, refresh_token TEXT, token_expiry TIMESTAMP WITH TIME ZONE, connected_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP, is_active BOOLEAN DEFAULT TRUE);
          CREATE TABLE IF NOT EXISTS drive_folders (folder_id VARCHAR(128) PRIMARY KEY, folder_name VARCHAR(255) NOT NULL, is_selected BOOLEAN DEFAULT TRUE, created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP);
          CREATE TABLE IF NOT EXISTS favorites (file_id VARCHAR(128) PRIMARY KEY, name VARCHAR(255) NOT NULL, mime_type VARCHAR(128) NOT NULL, thumbnail_link TEXT, web_view_link TEXT, size BIGINT DEFAULT 0, modified_time TIMESTAMP WITH TIME ZONE, added_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP);
          CREATE TABLE IF NOT EXISTS recent_files (file_id VARCHAR(128) PRIMARY KEY, name VARCHAR(255) NOT NULL, mime_type VARCHAR(128) NOT NULL, thumbnail_link TEXT, web_view_link TEXT, size BIGINT DEFAULT 0, opened_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP);
          CREATE TABLE IF NOT EXISTS audit_logs (id SERIAL PRIMARY KEY, event VARCHAR(64) NOT NULL, ip VARCHAR(64), details TEXT, created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP);
        `);
        client.release();
      } catch (err: any) {
        console.warn('PostgreSQL connection not established or failed. Defaulting to high-integrity local file store. Reason:', err.message);
        this.isPgAvailable = false;
        this.pgPool = null;
      }
    } else {
      console.log('Using robust persistent local storage (.data/private_cloud.json). To switch to PostgreSQL/Supabase, set DATABASE_URL in .env');
    }
  }

  // --- SETTINGS ---
  async getSetting<T = any>(key: string): Promise<T | null> {
    if (this.isPgAvailable && this.pgPool) {
      try {
        const res = await this.pgPool.query('SELECT value FROM settings WHERE key = $1', [key]);
        if (res.rows.length > 0) return res.rows[0].value as T;
        return null;
      } catch (e) {
        // Fallback
      }
    }
    return (this.localData.settings[key] as T) ?? null;
  }

  async setSetting(key: string, value: any): Promise<void> {
    if (this.isPgAvailable && this.pgPool) {
      try {
        await this.pgPool.query(
          'INSERT INTO settings (key, value, updated_at) VALUES ($1, $2, NOW()) ON CONFLICT (key) DO UPDATE SET value = $2, updated_at = NOW()',
          [key, JSON.stringify(value)]
        );
      } catch (e) {
        // Fallback
      }
    }
    this.localData.settings[key] = value;
    this.saveLocalStore();
  }

  // --- SESSIONS ---
  async createSession(session: SessionRecord): Promise<void> {
    if (this.isPgAvailable && this.pgPool) {
      try {
        await this.pgPool.query(
          'INSERT INTO sessions (id, ip, user_agent, created_at, expires_at) VALUES ($1, $2, $3, $4, $5)',
          [session.id, session.ip, session.user_agent, session.created_at, session.expires_at]
        );
      } catch (e) {}
    }
    this.localData.sessions[session.id] = session;
    this.saveLocalStore();
  }

  async getSession(id: string): Promise<SessionRecord | null> {
    if (this.isPgAvailable && this.pgPool) {
      try {
        const res = await this.pgPool.query('SELECT * FROM sessions WHERE id = $1', [id]);
        if (res.rows.length > 0) return res.rows[0] as SessionRecord;
        return null;
      } catch (e) {}
    }
    return this.localData.sessions[id] ?? null;
  }

  async deleteSession(id: string): Promise<void> {
    if (this.isPgAvailable && this.pgPool) {
      try {
        await this.pgPool.query('DELETE FROM sessions WHERE id = $1', [id]);
      } catch (e) {}
    }
    delete this.localData.sessions[id];
    this.saveLocalStore();
  }

  async getAllSessions(): Promise<SessionRecord[]> {
    if (this.isPgAvailable && this.pgPool) {
      try {
        const res = await this.pgPool.query('SELECT * FROM sessions ORDER BY created_at DESC');
        return res.rows as SessionRecord[];
      } catch (e) {}
    }
    return Object.values(this.localData.sessions).sort(
      (a, b) => new Date(b.created_at).getTime() - new Date(a.created_at).getTime()
    );
  }

  // --- DRIVE CONNECTION ---
  async getDriveConnection(): Promise<DriveConnectionRecord | null> {
    if (this.isPgAvailable && this.pgPool) {
      try {
        const res = await this.pgPool.query('SELECT * FROM drive_connections WHERE is_active = TRUE ORDER BY id DESC LIMIT 1');
        if (res.rows.length > 0) {
          const row = res.rows[0];
          return {
            email: row.email,
            access_token: row.access_token,
            refresh_token: row.refresh_token,
            token_expiry: row.token_expiry ? new Date(row.token_expiry).getTime() : undefined,
            connected_at: row.connected_at,
            is_active: row.is_active,
          };
        }
        return null;
      } catch (e) {}
    }
    return this.localData.drive_connection;
  }

  async setDriveConnection(conn: DriveConnectionRecord): Promise<void> {
    if (this.isPgAvailable && this.pgPool) {
      try {
        await this.pgPool.query('UPDATE drive_connections SET is_active = FALSE');
        await this.pgPool.query(
          'INSERT INTO drive_connections (email, access_token, refresh_token, token_expiry, connected_at, is_active) VALUES ($1, $2, $3, $4, $5, TRUE)',
          [
            conn.email,
            conn.access_token,
            conn.refresh_token || null,
            conn.token_expiry ? new Date(conn.token_expiry) : null,
            conn.connected_at,
          ]
        );
      } catch (e) {}
    }
    this.localData.drive_connection = conn;
    this.saveLocalStore();
  }

  async clearDriveConnection(): Promise<void> {
    if (this.isPgAvailable && this.pgPool) {
      try {
        await this.pgPool.query('UPDATE drive_connections SET is_active = FALSE');
      } catch (e) {}
    }
    this.localData.drive_connection = null;
    this.saveLocalStore();
  }

  // --- DRIVE FOLDERS FILTER ---
  async getSelectedFolders(): Promise<DriveFolderRecord[]> {
    if (this.isPgAvailable && this.pgPool) {
      try {
        const res = await this.pgPool.query('SELECT * FROM drive_folders WHERE is_selected = TRUE');
        return res.rows as DriveFolderRecord[];
      } catch (e) {}
    }
    return Object.values(this.localData.drive_folders).filter((f) => f.is_selected);
  }

  async setSelectedFolders(folders: { folder_id: string; folder_name: string }[]): Promise<void> {
    if (this.isPgAvailable && this.pgPool) {
      try {
        await this.pgPool.query('DELETE FROM drive_folders');
        for (const f of folders) {
          await this.pgPool.query(
            'INSERT INTO drive_folders (folder_id, folder_name, is_selected) VALUES ($1, $2, TRUE)',
            [f.folder_id, f.folder_name]
          );
        }
      } catch (e) {}
    }
    this.localData.drive_folders = {};
    for (const f of folders) {
      this.localData.drive_folders[f.folder_id] = {
        folder_id: f.folder_id,
        folder_name: f.folder_name,
        is_selected: true,
        created_at: new Date().toISOString(),
      };
    }
    this.saveLocalStore();
  }

  // --- FAVORITES ---
  async getFavorites(): Promise<FileMetadataRecord[]> {
    if (this.isPgAvailable && this.pgPool) {
      try {
        const res = await this.pgPool.query('SELECT * FROM favorites ORDER BY added_at DESC');
        return res.rows.map((r) => ({
          file_id: r.file_id,
          name: r.name,
          mime_type: r.mime_type,
          thumbnail_link: r.thumbnail_link,
          web_view_link: r.web_view_link,
          size: Number(r.size || 0),
          modified_time: r.modified_time,
          timestamp: r.added_at,
        }));
      } catch (e) {}
    }
    return Object.values(this.localData.favorites).sort(
      (a, b) => new Date(b.timestamp || 0).getTime() - new Date(a.timestamp || 0).getTime()
    );
  }

  async isFavorite(fileId: string): Promise<boolean> {
    if (this.isPgAvailable && this.pgPool) {
      try {
        const res = await this.pgPool.query('SELECT 1 FROM favorites WHERE file_id = $1', [fileId]);
        return res.rows.length > 0;
      } catch (e) {}
    }
    return !!this.localData.favorites[fileId];
  }

  async addFavorite(item: FileMetadataRecord): Promise<void> {
    const timestamp = new Date().toISOString();
    if (this.isPgAvailable && this.pgPool) {
      try {
        await this.pgPool.query(
          `INSERT INTO favorites (file_id, name, mime_type, thumbnail_link, web_view_link, size, modified_time, added_at)
           VALUES ($1, $2, $3, $4, $5, $6, $7, $8)
           ON CONFLICT (file_id) DO NOTHING`,
          [item.file_id, item.name, item.mime_type, item.thumbnail_link || null, item.web_view_link || null, item.size || 0, item.modified_time || null, timestamp]
        );
      } catch (e) {}
    }
    this.localData.favorites[item.file_id] = { ...item, timestamp };
    this.saveLocalStore();
  }

  async removeFavorite(fileId: string): Promise<void> {
    if (this.isPgAvailable && this.pgPool) {
      try {
        await this.pgPool.query('DELETE FROM favorites WHERE file_id = $1', [fileId]);
      } catch (e) {}
    }
    delete this.localData.favorites[fileId];
    this.saveLocalStore();
  }

  // --- RECENT FILES ---
  async getRecentFiles(limit = 30): Promise<FileMetadataRecord[]> {
    if (this.isPgAvailable && this.pgPool) {
      try {
        const res = await this.pgPool.query('SELECT * FROM recent_files ORDER BY opened_at DESC LIMIT $1', [limit]);
        return res.rows.map((r) => ({
          file_id: r.file_id,
          name: r.name,
          mime_type: r.mime_type,
          thumbnail_link: r.thumbnail_link,
          web_view_link: r.web_view_link,
          size: Number(r.size || 0),
          timestamp: r.opened_at,
        }));
      } catch (e) {}
    }
    return Object.values(this.localData.recent_files)
      .sort((a, b) => new Date(b.timestamp || 0).getTime() - new Date(a.timestamp || 0).getTime())
      .slice(0, limit);
  }

  async addRecentFile(item: FileMetadataRecord): Promise<void> {
    const timestamp = new Date().toISOString();
    if (this.isPgAvailable && this.pgPool) {
      try {
        await this.pgPool.query(
          `INSERT INTO recent_files (file_id, name, mime_type, thumbnail_link, web_view_link, size, opened_at)
           VALUES ($1, $2, $3, $4, $5, $6, $7)
           ON CONFLICT (file_id) DO UPDATE SET opened_at = $7, name = $2, thumbnail_link = $4`,
          [item.file_id, item.name, item.mime_type, item.thumbnail_link || null, item.web_view_link || null, item.size || 0, timestamp]
        );
      } catch (e) {}
    }
    this.localData.recent_files[item.file_id] = { ...item, timestamp };
    this.saveLocalStore();
  }

  // --- AUDIT LOGS ---
  async logAudit(event: string, ip: string, details: string): Promise<void> {
    const created_at = new Date().toISOString();
    if (this.isPgAvailable && this.pgPool) {
      try {
        await this.pgPool.query(
          'INSERT INTO audit_logs (event, ip, details, created_at) VALUES ($1, $2, $3, $4)',
          [event, ip, details, created_at]
        );
      } catch (e) {}
    }
    this.localData.audit_logs.unshift({
      id: Date.now() + Math.floor(Math.random() * 1000),
      event,
      ip,
      details,
      created_at,
    });
    // Keep max 200 logs
    if (this.localData.audit_logs.length > 200) {
      this.localData.audit_logs = this.localData.audit_logs.slice(0, 200);
    }
    this.saveLocalStore();
  }

  async getAuditLogs(limit = 100): Promise<AuditLogRecord[]> {
    if (this.isPgAvailable && this.pgPool) {
      try {
        const res = await this.pgPool.query('SELECT * FROM audit_logs ORDER BY created_at DESC LIMIT $1', [limit]);
        return res.rows as AuditLogRecord[];
      } catch (e) {}
    }
    return this.localData.audit_logs.slice(0, limit);
  }

  getDbStatus() {
    return {
      type: this.isPgAvailable ? 'PostgreSQL / Supabase' : 'Local Persistent Database (JSON / Embedded)',
      isConnected: true,
      hasPostgresConfigured: !!process.env.DATABASE_URL,
    };
  }
}

export const db = new DatabaseService();
