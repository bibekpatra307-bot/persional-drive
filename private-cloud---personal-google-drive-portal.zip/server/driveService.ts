import { db } from './db.js';

export interface DriveFileItem {
  id: string;
  name: string;
  mimeType: string;
  size?: number;
  modifiedTime?: string;
  createdTime?: string;
  thumbnailLink?: string;
  webViewLink?: string;
  webContentLink?: string;
  iconLink?: string;
  parents?: string[];
  isFolder: boolean;
  videoMediaMetadata?: {
    width?: number;
    height?: number;
    durationMillis?: string;
  };
  imageMediaMetadata?: {
    width?: number;
    height?: number;
    rotation?: number;
  };
}

export interface ListFilesOptions {
  category?: 'all' | 'photos' | 'videos' | 'documents' | 'files';
  folderId?: string;
  pageSize?: number;
  pageToken?: string;
  searchQuery?: string;
  sortBy?: 'name' | 'modifiedTime' | 'size';
  sortOrder?: 'asc' | 'desc';
}

export class DriveService {
  /**
   * Resolve an active Google Drive access token.
   * Can come from client admin authorization stored in DB, or server env vars.
   */
  async getAccessToken(): Promise<string | null> {
    // 1. Check database connection
    const conn = await db.getDriveConnection();
    if (conn && conn.is_active && conn.access_token) {
      // Check if expired and has refresh token
      if (conn.token_expiry && Date.now() > conn.token_expiry && conn.refresh_token) {
        const refreshed = await this.refreshAccessToken(conn.refresh_token);
        if (refreshed) return refreshed;
      }
      return conn.access_token;
    }

    // 2. Check environment variables
    const envRefresh = process.env.GOOGLE_REFRESH_TOKEN;
    if (envRefresh) {
      const refreshed = await this.refreshAccessToken(envRefresh);
      if (refreshed) return refreshed;
    }

    return null;
  }

  /**
   * Refreshes access token via Google OAuth token endpoint
   */
  private async refreshAccessToken(refreshToken: string): Promise<string | null> {
    const clientId = process.env.GOOGLE_CLIENT_ID;
    const clientSecret = process.env.GOOGLE_CLIENT_SECRET;
    if (!clientId || !clientSecret) return null;

    try {
      const res = await fetch('https://oauth2.googleapis.com/token', {
        method: 'POST',
        headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
        body: new URLSearchParams({
          client_id: clientId,
          client_secret: clientSecret,
          refresh_token: refreshToken,
          grant_type: 'refresh_token',
        }),
      });

      if (!res.ok) {
        console.error('Failed to refresh Google access token:', await res.text());
        return null;
      }

      const data = await res.json();
      const newAccessToken = data.access_token;
      const expiresIn = data.expires_in || 3600;

      // Update in DB
      const current = await db.getDriveConnection();
      if (current) {
        current.access_token = newAccessToken;
        current.token_expiry = Date.now() + expiresIn * 1000;
        await db.setDriveConnection(current);
      }

      return newAccessToken;
    } catch (err) {
      console.error('Error refreshing token:', err);
      return null;
    }
  }

  /**
   * Check connection status
   */
  async getStatus(): Promise<{
    connected: boolean;
    email?: string;
    connectedAt?: string;
    allowedFolderCount: number;
    allowedFolders: { id: string; name: string }[];
  }> {
    const conn = await db.getDriveConnection();
    const allowed = await db.getSelectedFolders();
    const token = await this.getAccessToken();

    return {
      connected: !!token,
      email: conn?.email,
      connectedAt: conn?.connected_at,
      allowedFolderCount: allowed.length,
      allowedFolders: allowed.map((f) => ({ id: f.folder_id, name: f.folder_name })),
    };
  }

  /**
   * Get Storage Quota Information
   */
  async getAboutInfo(): Promise<{
    user?: { displayName: string; emailAddress: string; photoLink?: string };
    storageQuota?: { limit?: string; usage?: string; usageInDrive?: string };
  } | null> {
    const token = await this.getAccessToken();
    if (!token) return null;

    try {
      const res = await fetch('https://www.googleapis.com/drive/v3/about?fields=user,storageQuota', {
        headers: { Authorization: `Bearer ${token}` },
      });
      if (!res.ok) return null;
      return await res.json();
    } catch {
      return null;
    }
  }

  /**
   * List folders for selection in Settings
   */
  async listAllFolders(parentId?: string): Promise<{ id: string; name: string }[]> {
    const token = await this.getAccessToken();
    if (!token) throw new Error('Google Drive is not connected');

    let q = "mimeType = 'application/vnd.google-apps.folder' and trashed = false";
    if (parentId) {
      q += ` and '${parentId}' in parents`;
    }

    const url = new URL('https://www.googleapis.com/drive/v3/files');
    url.searchParams.set('q', q);
    url.searchParams.set('pageSize', '100');
    url.searchParams.set('fields', 'files(id, name)');
    url.searchParams.set('orderBy', 'name');

    const res = await fetch(url.toString(), {
      headers: { Authorization: `Bearer ${token}` },
    });

    if (!res.ok) {
      throw new Error(`Google Drive API error: ${res.statusText}`);
    }

    const data = await res.json();
    return data.files || [];
  }

  /**
   * Build query restrictions based on selected folders
   */
  private async getFolderRestrictionClause(explicitFolderId?: string): Promise<string> {
    if (explicitFolderId) {
      return `'${explicitFolderId}' in parents`;
    }

    const selectedFolders = await db.getSelectedFolders();
    if (selectedFolders.length === 0) {
      // No specific folder filter applied; allow browsing root or all files
      return '';
    }

    // Restrict files whose parent is in the selected list, or match the selected folder themselves
    const parentQueries = selectedFolders.map((f) => `'${f.folder_id}' in parents`).join(' or ');
    return `(${parentQueries})`;
  }

  /**
   * List files by category, folder, and pagination
   */
  async listFiles(options: ListFilesOptions): Promise<{
    files: DriveFileItem[];
    nextPageToken?: string;
  }> {
    const token = await this.getAccessToken();
    if (!token) throw new Error('Google Drive is not connected');

    const conditions: string[] = ['trashed = false'];

    // Category filter
    if (options.category === 'photos') {
      conditions.push("mimeType contains 'image/'");
    } else if (options.category === 'videos') {
      conditions.push("mimeType contains 'video/'");
    } else if (options.category === 'documents') {
      conditions.push(
        "(mimeType contains 'pdf' or mimeType contains 'document' or mimeType contains 'sheet' or mimeType contains 'presentation' or mimeType contains 'text/' or mimeType contains 'spreadsheet')"
      );
    } else if (options.category === 'files') {
      // In file explorer, show both folders and files in current folder
    }

    // Folder constraint
    const folderClause = await this.getFolderRestrictionClause(options.folderId);
    if (folderClause) {
      conditions.push(folderClause);
    }

    // Order by
    let orderBy = 'folder,modifiedTime desc';
    if (options.sortBy === 'name') {
      orderBy = `folder,name ${options.sortOrder || 'asc'}`;
    } else if (options.sortBy === 'size') {
      orderBy = `folder,quotaBytesUsed ${options.sortOrder || 'desc'}`;
    } else if (options.sortBy === 'modifiedTime') {
      orderBy = `folder,modifiedTime ${options.sortOrder || 'desc'}`;
    }

    const url = new URL('https://www.googleapis.com/drive/v3/files');
    url.searchParams.set('q', conditions.join(' and '));
    url.searchParams.set('pageSize', String(options.pageSize || 30));
    url.searchParams.set(
      'fields',
      'nextPageToken, files(id, name, mimeType, size, modifiedTime, createdTime, thumbnailLink, webViewLink, webContentLink, iconLink, parents, videoMediaMetadata, imageMediaMetadata)'
    );
    url.searchParams.set('orderBy', orderBy);

    if (options.pageToken) {
      url.searchParams.set('pageToken', options.pageToken);
    }

    const res = await fetch(url.toString(), {
      headers: { Authorization: `Bearer ${token}` },
    });

    if (!res.ok) {
      const errText = await res.text();
      console.error('Drive API error:', res.status, errText);
      throw new Error(`Google Drive API error (${res.status}): ${errText}`);
    }

    const data = await res.json();
    const rawFiles: any[] = data.files || [];

    const files: DriveFileItem[] = rawFiles.map((f) => ({
      id: f.id,
      name: f.name,
      mimeType: f.mimeType,
      size: f.size ? Number(f.size) : undefined,
      modifiedTime: f.modifiedTime,
      createdTime: f.createdTime,
      thumbnailLink: f.thumbnailLink,
      webViewLink: f.webViewLink,
      webContentLink: f.webContentLink,
      iconLink: f.iconLink,
      parents: f.parents,
      isFolder: f.mimeType === 'application/vnd.google-apps.folder',
      videoMediaMetadata: f.videoMediaMetadata,
      imageMediaMetadata: f.imageMediaMetadata,
    }));

    return {
      files,
      nextPageToken: data.nextPageToken,
    };
  }

  /**
   * Search files by keyword, category, and date
   */
  async searchFiles(
    query: string,
    options: { category?: string; pageSize?: number; pageToken?: string } = {}
  ): Promise<{ files: DriveFileItem[]; nextPageToken?: string }> {
    const token = await this.getAccessToken();
    if (!token) throw new Error('Google Drive is not connected');

    const cleanQuery = query.replace(/'/g, "\\'");
    const conditions: string[] = ['trashed = false'];

    if (cleanQuery.trim()) {
      conditions.push(`name contains '${cleanQuery}'`);
    }

    if (options.category === 'photos') {
      conditions.push("mimeType contains 'image/'");
    } else if (options.category === 'videos') {
      conditions.push("mimeType contains 'video/'");
    } else if (options.category === 'documents') {
      conditions.push(
        "(mimeType contains 'pdf' or mimeType contains 'document' or mimeType contains 'sheet' or mimeType contains 'presentation' or mimeType contains 'text/')"
      );
    } else if (options.category === 'pdf') {
      conditions.push("mimeType contains 'pdf'");
    }

    const folderClause = await this.getFolderRestrictionClause();
    if (folderClause) {
      conditions.push(folderClause);
    }

    const url = new URL('https://www.googleapis.com/drive/v3/files');
    url.searchParams.set('q', conditions.join(' and '));
    url.searchParams.set('pageSize', String(options.pageSize || 30));
    url.searchParams.set(
      'fields',
      'nextPageToken, files(id, name, mimeType, size, modifiedTime, createdTime, thumbnailLink, webViewLink, webContentLink, iconLink, parents, videoMediaMetadata, imageMediaMetadata)'
    );
    url.searchParams.set('orderBy', 'folder,modifiedTime desc');

    if (options.pageToken) {
      url.searchParams.set('pageToken', options.pageToken);
    }

    const res = await fetch(url.toString(), {
      headers: { Authorization: `Bearer ${token}` },
    });

    if (!res.ok) {
      const errText = await res.text();
      throw new Error(`Search failed: ${errText}`);
    }

    const data = await res.json();
    const rawFiles: any[] = data.files || [];

    return {
      files: rawFiles.map((f) => ({
        id: f.id,
        name: f.name,
        mimeType: f.mimeType,
        size: f.size ? Number(f.size) : undefined,
        modifiedTime: f.modifiedTime,
        createdTime: f.createdTime,
        thumbnailLink: f.thumbnailLink,
        webViewLink: f.webViewLink,
        webContentLink: f.webContentLink,
        iconLink: f.iconLink,
        parents: f.parents,
        isFolder: f.mimeType === 'application/vnd.google-apps.folder',
        videoMediaMetadata: f.videoMediaMetadata,
        imageMediaMetadata: f.imageMediaMetadata,
      })),
      nextPageToken: data.nextPageToken,
    };
  }

  /**
   * Get single file metadata
   */
  async getFile(fileId: string): Promise<DriveFileItem> {
    const token = await this.getAccessToken();
    if (!token) throw new Error('Google Drive is not connected');

    const url = `https://www.googleapis.com/drive/v3/files/${fileId}?fields=id,name,mimeType,size,modifiedTime,createdTime,thumbnailLink,webViewLink,webContentLink,iconLink,parents,videoMediaMetadata,imageMediaMetadata`;
    const res = await fetch(url, {
      headers: { Authorization: `Bearer ${token}` },
    });

    if (!res.ok) {
      throw new Error(`File not found or access denied (${res.status})`);
    }

    const f = await res.json();
    return {
      id: f.id,
      name: f.name,
      mimeType: f.mimeType,
      size: f.size ? Number(f.size) : undefined,
      modifiedTime: f.modifiedTime,
      createdTime: f.createdTime,
      thumbnailLink: f.thumbnailLink,
      webViewLink: f.webViewLink,
      webContentLink: f.webContentLink,
      iconLink: f.iconLink,
      parents: f.parents,
      isFolder: f.mimeType === 'application/vnd.google-apps.folder',
      videoMediaMetadata: f.videoMediaMetadata,
      imageMediaMetadata: f.imageMediaMetadata,
    };
  }

  /**
   * Stream file content with HTTP Range support for video seeking
   */
  async streamFileContent(
    fileId: string,
    rangeHeader?: string
  ): Promise<{
    status: number;
    headers: Record<string, string>;
    stream: ReadableStream<Uint8Array> | null;
  }> {
    const token = await this.getAccessToken();
    if (!token) throw new Error('Google Drive is not connected');

    const headers: Record<string, string> = {
      Authorization: `Bearer ${token}`,
    };

    if (rangeHeader) {
      headers['Range'] = rangeHeader;
    }

    const url = `https://www.googleapis.com/drive/v3/files/${fileId}?alt=media`;
    const res = await fetch(url, { headers });

    const responseHeaders: Record<string, string> = {};
    const passHeaders = [
      'content-type',
      'content-length',
      'content-range',
      'accept-ranges',
      'cache-control',
      'last-modified',
    ];

    passHeaders.forEach((h) => {
      const val = res.headers.get(h);
      if (val) responseHeaders[h] = val;
    });

    if (!responseHeaders['accept-ranges']) {
      responseHeaders['accept-ranges'] = 'bytes';
    }

    return {
      status: res.status,
      headers: responseHeaders,
      stream: res.body,
    };
  }

  /**
   * Get Category Counts (Photos, Videos, Documents, Total)
   */
  async getCategoryCounts(): Promise<{
    photos: number;
    videos: number;
    documents: number;
    folders: number;
    total: number;
  }> {
    const token = await this.getAccessToken();
    if (!token) return { photos: 0, videos: 0, documents: 0, folders: 0, total: 0 };

    try {
      const folderClause = await this.getFolderRestrictionClause();
      const baseClause = folderClause ? `trashed = false and ${folderClause}` : 'trashed = false';

      const fetchCount = async (additionalQ: string): Promise<number> => {
        const q = `${baseClause} and ${additionalQ}`;
        const url = `https://www.googleapis.com/drive/v3/files?q=${encodeURIComponent(q)}&pageSize=100&fields=files(id)`;
        const res = await fetch(url, { headers: { Authorization: `Bearer ${token}` } });
        if (!res.ok) return 0;
        const data = await res.json();
        return (data.files || []).length;
      };

      const [photos, videos, documents, folders] = await Promise.all([
        fetchCount("mimeType contains 'image/'"),
        fetchCount("mimeType contains 'video/'"),
        fetchCount("(mimeType contains 'pdf' or mimeType contains 'document' or mimeType contains 'sheet' or mimeType contains 'presentation')"),
        fetchCount("mimeType = 'application/vnd.google-apps.folder'"),
      ]);

      return {
        photos,
        videos,
        documents,
        folders,
        total: photos + videos + documents,
      };
    } catch {
      return { photos: 0, videos: 0, documents: 0, folders: 0, total: 0 };
    }
  }
}

export const driveService = new DriveService();
